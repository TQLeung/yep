import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

// 返回modules下所有js文件
const modulesFiles = require.context('./modules', true, /\.js$/)
const modules = modulesFiles.keys().reduce((modules, modulePath) => {
	const modulesName = modulePath.replace(/^\.\/(.*)\.\w+$/, '$1')
	const value = modulesFiles(modulePath)
	modules[modulesName] = value.default
	return modules
}, {})

export default new Vuex.Store({
	modules
})