export default {
	namespaced: true,
	state: {
		deviceDetailData:{}, // 设备调料养护信息
	},
	getter: {
		getFood(state){
			return state.foodInfos
		}
	},
	mutations: {
		// 存储已选菜谱
		setDeviceDetailData(state, data) {
			state.deviceDetailData = data
		},
		
	},
	actions: {
		
	}
}