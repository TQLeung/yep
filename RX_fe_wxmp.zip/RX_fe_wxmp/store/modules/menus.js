export default {
	namespaced: true,
	state: {
		menusListContent: [], // 菜谱列表
		customer:{},//选择的客户
		foodInfos:{},//选择得食材信息
		menuInfo:{},
		index:'0',
		allMenus:[]
	},
	getter: {
		getFood(state){
			return state.foodInfos
		}
	},
	mutations: {
		setAllMenus(state, menus) {
			state.allMenus = menus
			// console.log(state.allMenus,'state.allMenusstate.allMenus')
		},
		// 存储已选菜谱
		setMenusListContent(state, menusList) {
			console.log(state, menusList)
			// menusList.forEach((item)=>{
			// 	if(state.menusListContent.indexOf(item)==-1){
			// 		state.menusListContent.push(item)
			// 	}
			// })
			console.log(menusList,'menusListmenusListwwwww2224ewe')
		},
		// 存储已选菜谱
		setMenuInfo(state, info) {
			state.menuInfo = info
		},
		// 存储已选索引
		setMenuIndex(state, index) {
			state.index = index
			// console.log(index,'新增存储的菜谱索引111')
		},
		// 存储已选择的客户
		setCustomer(state,info){
			state.customer = info
		},
		// 存储已选择的食材
		setFood(state,info){
			state.foodInfos = info
		}
	},
	actions: {
		
	}
}