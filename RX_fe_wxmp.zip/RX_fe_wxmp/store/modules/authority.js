export default {
	namespaced: true,
	state: {
		// 全局权限表
		authority: {
			rootMenu: false, // 菜谱权限
			currentTab:0
		}
	},
	mutations: {
		// 更新RootMenu状态
		updateRootMenu(state, bol) {
			state.authority.rootMenu = bol
		},
		changeTab(state,val){
			// console.log('执行更新', val)
			state.authority.currentTab = val
		}
	},
	getter: {
		
	},
	actions: {
		
	}
}