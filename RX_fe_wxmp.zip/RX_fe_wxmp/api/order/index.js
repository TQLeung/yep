import ajax from '@/uilts/ajax/index.js'

// 订单列表请求接口
const order = {
	// 获取订单列表信息
	getOrder: (page) => ajax.get(`/app/api/v1/user/order?page=${page}`),
	// 获取订单详情
	getOrderDetail: (id) => ajax.get(`/app/api/v1/user/order/${id}`),
	// 获取佣金方案
	getCommissionPlan: () => ajax.get(`/app/api/v1/commission-plan`),
	// 创建订单
	createOrder: (data) => ajax.post(`/app/api/v1/user/order`,data),
	// 获取支付信息
	getPayInfo: (id,openid) => ajax.get(`/app/api/v1/user/order/${id}/payment?openid=${openid}`),
}

export default order