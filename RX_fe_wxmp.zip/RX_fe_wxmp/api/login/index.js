import ajax from '@/uilts/ajax/index.js'

// 首页请求接口
const login = {
	// 获取token信息
	toLogin: (data) => ajax.POST(`/mam/auth/login_mini`,data),
	// 获取openid 
	// getOpenId:(code)=>ajax.GET(`/app/api/v1/code2session?js_code=${code}`),
	// 修改密码
	changePassword:(data)=>ajax.POST(`/mam/auth/psw_modify`,data)
}

export default login