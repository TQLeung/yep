import ajax from '@/uilts/ajax/index.js'

// 设备列表请求接口
const home = {
	// 获取设备列表信息
	getDevice: (page) => ajax.get(`/app/api/v1/user/device/journal?page=${page}`),
	getNewDevice: (id,page) => ajax.get(`/mam/device/list/${id}?page_index=${page}&all=true`),
	getDeviceByStatus: (val) => ajax.get(`/app/api/v1/user/device/journal?status=${val}`),
	getDeviceById: (id) => ajax.get(`/app/api/v1/user/device/journal/${id}`),
	getDeviceByStatus: (val) => ajax.get(`/app/api/v1/user/device?status=${val}`),
	getDeviceTotal:()=> ajax.get(`/app/api/v1/user/device/stat`),
	getCookedByCode: (code) => ajax.get(`/app/api/v1/user/device/${code}/iot/cooked`),
	// 获取设备的运行状态
	getStatusByCode:(code)=>ajax.get(`/app/api/v1/user/device/:${code}/iot/state`),
	// 获取烹饪菜品数据
	getMenuCategoryData:(user_id,period)=> ajax.get(`/mam/report/rank_rc_user/${user_id}/${period}`),
	// 商户下运营数据
	getUserData:(user_id,period)=> ajax.get(`/mam/report/summary_user/${user_id}/${period}`),
	// 商户下食物用量数据
	getUserFoodData:(user_id,period)=> ajax.get(`/mam/report/rank_food_user/${user_id}/${period}`),
	// 商户下调料用量数据
	getUserFlavourData:(user_id,period)=> ajax.get(`/mam/report/rank_flavour_user/${user_id}/${period}?page_size=5`),
	// 商户下烹饪时段数据
	getUserCookCopiesData:(user_id,period)=> ajax.get(`/mam/report/cook_copies_user/${user_id}/${period}`),
	// 门店下运营数据
	getStoreData:(store_id,period)=> ajax.get(`/mam/report/summary_store/${store_id}/${period}`),
	// 门店下食物用量数据
	getStoreFoodData:(store_id,period)=> ajax.get(`/mam/report/rank_food_store/${store_id}/${period}`),
	//门店下调料用量数据
	getStoreFlavourData:(store_id,period)=> ajax.get(`/mam/report/rank_flavour_store/${store_id}/${period}?page_size=5`),
	// 获取门店烹饪菜品数据
	getStoreMenuCategoryData:(store_id,period)=> ajax.get(`/mam/report/rank_rc_store/${store_id}/${period}`),
	// 门店下烹饪时段数据
	getStoreCookCopiesData:(store_id,period)=> ajax.get(`/mam/report/cook_copies_store/${store_id}/${period}`),
	// 商户下设备列表
	getUserDeviceData:(page,user_id)=> ajax.get(`/mam/report/device_list_user/${user_id}?page_index=${page}`),
	// 门店下设备列表
	getStoreDeviceData:(page,store_id)=> ajax.get(`/mam/report/device_list_store/${store_id}?page_index=${page}`),
	// 获取商户下设备得泵、养锅数据
	getDeviceDetail:(page,user_id)=> ajax.get(`/mam/report/device_list_user_detail/${user_id}?page_index=${page}&all=true`),
	// 获取门店下设备得泵、养锅数据
	getStoreDeviceDetail:(page,store_id)=> ajax.get(`/mam/report/device_list_store_detail/${store_id}?page_index=${page}&all=true`),
	// 获取商户下面得菜品排行数据
	getUserCategoryRank:(user_id,period,datetime,data,page)=> ajax.get(`/mam/report/rank_rc_user_detail/${user_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	// 获取门店下面得菜品排行数据
	getStoreCategoryRank:(store_id,period,datetime,data,page)=> ajax.get(`/mam/report/rank_rc_store_detail/${store_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	// 获取商户下面得食材用量数据
	getUserFoodRank:(user_id,period,datetime,data,page)=> ajax.get(`/mam/report/rank_food_user_detail/${user_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	// 获取门店下面得食材用量数据
	getStoreFoodRank:(store_id,period,datetime,data,page)=> ajax.get(`/mam/report/rank_food_store_detail/${store_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	// 获取商户下面得调料用量数据
	getUserFlavourRank:(user_id,period,datetime,data,page)=> ajax.get(`/mam/report/rank_flavour_user_detail/${user_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	// 获取门店下面得调料用量数据
	getStoreFlavourRank:(store_id,period,datetime,data,page)=> ajax.get(`/mam/report/rank_flavour_store_detail/${store_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	//获取商户/门店烹饪次数、烹饪时长、能耗电量相关数据
	getUserSummary:(user_id,period=4,datetime,data,page=1)=> ajax.get(`/mam/report/summary_user_detail/${user_id}/${period}/${datetime}?page_index=${page}`,data),
	getStoreSummary:(user_id,period,datetime,data,page=1)=> ajax.get(`/mam/report/summary_store_detail/${user_id}/${period}/${datetime}?page_index=${page}`,data),
	//获取商户/门店烹饪次数的设备列表
	getUserTimeDevice:(user_id,period=4,datetime,data,page=1)=> ajax.get(`/mam/report/summary_user_detail_device_list_ob_time/${user_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	getStoreTimeDevice:(store_id,period,datetime,data,page=1)=> ajax.get(`/mam/report/summary_store_detail_device_list_ob_time/${store_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	//获取商户/门店烹饪时长的设备列表
	getUserRTimeDevice:(user_id,period=4,datetime,data,page=1)=> ajax.get(`/mam/report/summary_user_detail_device_list_ob_rtime/${user_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	getStoreRTimeDevice:(store_id,period,datetime,data,page=1)=> ajax.get(`/mam/report/summary_store_detail_device_list_ob_rtime/${store_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	//获取商户/门店能源电耗的设备列表
	getUserEnergyDevice:(user_id,period=4,datetime,data,page=1)=> ajax.get(`/mam/report/summary_user_detail_device_list_ob_energy/${user_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	getStoreEnergyDevice:(store_id,period,datetime,data,page=1)=> ajax.get(`/mam/report/summary_store_detail_device_list_ob_energy/${store_id}/${period}/${datetime}?page_index=${page}&all=true`,data),
	
}

export default home