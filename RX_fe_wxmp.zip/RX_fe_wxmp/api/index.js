import login from '@/api/login/index.js' // 登陆接口
import home from '@/api/home/index.js' // 首页设备列表接口
import order from '@/api/order/index.js' // 订单列表接口
import menus from '@/api/menus/index.js' // 菜谱接口
export default {
	login,home,order,menus
}