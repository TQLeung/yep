import ajax from '@/uilts/ajax/index.js'

// 菜谱的请求接口
const menus = {
	// 获取菜谱详情页信息
	scListEdit: (scList) => ajax.post(`/mam/recipe/recipe_sc_edit`, scList),
	getMenuDetail: (id) => ajax.get(`/mam/recipe/item/${id}`),
	getDetailMenu:(uid,recipe_category_id,recipe_num,pending_num,pending_and_standard_num='')=>ajax.get(`/mam/recipe/recipe_sc/${uid}?all=true&status_level=20&recipe_category_id=${recipe_category_id}&recipe_num=${recipe_num}&pending_num=${pending_num}&pending_and_standard_num=${pending_and_standard_num}`),
	getRelMenu:(id,name,recipe_num,pending_num,confine_tag)=>ajax.get(`/mam/recipe/recipe_sc/${id}?all=true&status_level=20&name_like=${name}&recipe_num=${recipe_num}&pending_num=${pending_num}&confine_tag=${confine_tag}`),
	getVarietyList:(page,uid,name='',recipe_num='',pending_num='',all=true,confine_num='')=>ajax.get(`/mam/recipe/category/${uid}?page_index=${page}&all=${all}&name_like=${name}&recipe_num=${recipe_num}&pending_num=${pending_num}&status_level=20&confine_num=${confine_num}`),
	getMenuList:(id,name,recipe_num,pending_num)=>ajax.get(`/mam/recipe/list/${id}?all=true&status_notin=研发中-在机,研发中-已删除&name_like=${name}&recipe_num=${recipe_num}&pending_num=${pending_num}`),
	getVarietyDetail:(userId,varietyId,spec,copies)=>ajax.get(`/mam/recipe/list/${userId}&recipe_category_id=${varietyId}&status_notin=研发中-在机,研发中-已删除&spec=${spec}&copies=${copies}&status_in=审核采用&all=true`),
	getFileList:(userId,varietyId,spec,copies)=>ajax.get(`/mam/recipe/list/${userId}&recipe_category_id=${varietyId}&status_notin=研发中-在机,研发中-已删除&spec=${spec}&copies=${copies}`),
	getUseFile:(userId,varietyId,spec,copies)=>ajax.get(`/mam/recipe/list/${userId}&recipe_category_id=${varietyId}&status_notin=研发中-在机,研发中-已删除&spec=${spec}&copies=${copies}&status_in=审核采用&all=true`),
	auditFile:(data)=>ajax.post('/mam/recipe/approval',data),
	getRecord:(id) => ajax.get(`/mam/recipe/approval_log?recipe_sc_id=${id}`),
	downMenu:(id,sn)=>ajax.post(`/mam/recipe/send_to_device/${id}/${sn}`),
	getTotal:(id) => ajax.get(`/mam/recipe/category_statistics/${id}?status_level=20`),
	getMenuTotal:(id) => ajax.get(`/mam/recipe/list_sc_statistics/${id}?status_notin="研发中-在机,研发中-已删除"`),
	getDownLog:(params)=> ajax.get(`/mam/recipe/download_log`,params),
	getRecipeSubdata: (id, userid) => ajax.get(`/mam/recipe/recipe_sc/${userid}?recipe_category_id=${id}&recipe_num=1&status_level=20`),
	// 获取组织架构树
	getTree:() => ajax.get(`/mam/org/tree`),
	// 获取菜谱文件料盒信息
	getBoxes:(recipe_id)=>ajax.get(`/mam/recipe/food_boxes/${recipe_id}`),
	// 获取食材库
	getFoods:(user_id,page,size=10,name_like='',all=false)=>ajax.get(`/mam/recipe/food/${user_id}&page_size=${size}&page_index=${page}&name_like=${name_like}&all=${all}`),
	// 获取调料
	getFlavours:(user_id,page,size=10,name_like='',all=false)=>ajax.get(`/mam/recipe/flavour/${user_id}&page_size=${size}&page_index=${page}&name_like=${name_like}&all=${all}`),
	// 新增材料食材
	addFood:(data)=>ajax.put(`/mam/recipe/food_new`,data),
	// 新增调料
	addFlavour:(data)=>ajax.post(`/mam/recipe/flavour_new`,data),
	// 新增食材
	addBoxesFood:(data,recipe_id,step_id)=>ajax.post(`/mam/recipe/food_box_food_add/${recipe_id}/${step_id}`,data),
	// 编辑食材
	updateBoxesFood:(data,recipe_id,step_id)=>ajax.put(`/mam/recipe/food_box_food_update/${recipe_id}/${step_id}`,data),
	// 删除食材
	deleteBoxesFood:(data,recipe_id,step_id)=>ajax.delete(`/mam/recipe/food_box_food_delete/${recipe_id}/${step_id}`,data),
	addFoodPicture:(data)=>ajax.post(`/mam/enclosure/upload`,data),
	// 查询图片
	getFoodPicture:(path) => ajax.get(`/enclosure/${path}`,{responseType:'arraybuffer'}),
	// 获取菜谱数量
	getMenuTotal:(id) => ajax.get(`/mam/recipe/recipe_sc/${id}?recipe_num=1`),

}
export default menus