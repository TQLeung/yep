// 错误信息
let MyError =  {
	systemError: function(code) {
		// 服务器错误
		if (code == 500) {
			uni.showToast({
				title: '服务器错误',
				icon: 'error',
				duration: 1500,
				success: (res) => {
					console.log('页面跳转')
					setTimeout(() => {
						uni.reLaunch({
							url: '/pages/index/index'
						})
					}, 1500)
				}
			})
		}
		
		// 用户身份授权失败
		if (code == 401) {
			uni.removeStorageSync('token')
			uni.showToast({
				title: '登录失败，身份已过期',
				icon: 'error',
				duration: 1500,
				success: (res) => {
					// console.log('页面跳转')
					setTimeout(() => {
						uni.navigateTo({
							url:'/pages/login/login'
						})
					}, 1500)
				}
			})
		}
	}
}

// 导出错误信息
export default MyError