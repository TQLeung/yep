import Vue from 'vue'
// 二次封装ajax请求
// const baseUrl = 'https://api.renxin-robot.com'
// const baseUrl = 'https://rr.renxin-robot.com' 
// const baseUrl = 'https://baichaole.acewill.net' 
// const baseUrl="https://x.renxin-robot.com"
// const baseUrl = 'https://admin.renxin-robot.com'
// https://api.renxin-robot.com/api/v1/login
// const baseUrl = 'http://119.23.110.171/app'
// const baseUrl = 'http://192.168.222.145'
const baseUrl = 'http://120.79.228.2'
const requestingInfo = {}
import totls from '@/uilts/tools/index.js'
// 发送请求hahaha
const http = requestingInfo => {
	// 添加token信息
	// console.log('请求参数', requestingInfo)
	return new Promise((resolve, reject) => {
		
		uni.request({
			...requestingInfo,
			header: {
				"Content-Type": 'application/json;charset=UTF-8',
				"x-renxin-token": `${totls.getToken()}`
			},
			success: res => {
				// console.log("响应结果", res)
				// console.log("响应结果",res)
				resolve(res.data)
			},
			fail: error => {
				// console.log("请求失败", error)
				// console.log()
				reject(error)
			}
		})
	})
}

// 封装请求方法
const ajax = {
	get(url, data) {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'GET',
			data: data || ''
		})
		return http(requestingInfo)
	},
	GET: (url, data) => {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'GET',
			data: data || ''
		})
		return http(requestingInfo)
	},
	post(url, data) {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'POST',
			data: data || ''
		})
		return http(requestingInfo)
	},
	POST(url, data) {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'POST',
			data: data || ''
		})
		return http(requestingInfo)
	},
	put(url, data) {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'PUT',
			data: data || ''
		})
		return http(requestingInfo)
	},
	PUT(url, data) {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'PUT',
			data: data || ''
		})
		return http(requestingInfo)
	},
	delete(url, data) {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'DELETE',
			data: data || ''
		})
		return http(requestingInfo)
	},
	DELETE(url, data) {
		Object.assign(requestingInfo, {
			url: baseUrl + url,
			method: 'DELETE',
			data: data || ''
		})
		return http(requestingInfo)
	}
}


// 拦截请求
uni.addInterceptor('request', {
	// 请求拦截器
	invoke: (args) => {
		// console.log("请求拦截器", args)
	}, 
	// 请求成功后触发
	success: (args) => {
		const { statusCode } = args
		// if(statusCode==401){
		// 	uni.navigateTo({
		// 		url:'/pages/login/login'
		// 	})
		// }
		// console.log('请求成功',Vue.prototype.MyError)
		// 调用 vue 获取异常状态码
		Vue.prototype.MyError.systemError(statusCode)
	}
})

export default ajax