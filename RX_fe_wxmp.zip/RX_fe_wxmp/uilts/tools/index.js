import WXBizDataCrypt from '@/uilts/thirdParty/Node/WXBizDataCrypt.js' // 解密手机号

export default {
	// 发请求向服务器获取token信息
	getServerTokenInfo() {
		uni.login({
			provider: 'weixin',
			success: res => {
				console.log('获取token', res)
			}
		})
	},
	// 获取本地token信息
	getToken: () => uni.getStorageSync('token'),
	
	// 设置token信息
	setToken: (tokenValue) => {
		uni.setStorageSync('token', tokenValue)
	},
	// 删除token信息
	deleteToken:()=>{
		uni.removeStorageSync('token')
		
	},
	// 授权手机号
	authorizationPhone: (event, js_code) => {
		// 返回应该Promise对象
		return new Promise((resolve, reject) => {
			var { encryptedData, iv } = event.detail
			var APPID = 'wxae984359fffe45b3' // 微信小程序 appid
			var SECRET = '0c4f492be9577246d3cd271f089157d4' // 微信小程序 密钥
			var grant_type = 'authorization_code'
			
			uni.request({
				url: 'https://api.weixin.qq.com/sns/jscode2session',
				method:'GET',
				data: { appId: APPID, secret: SECRET, js_code, grant_type },
				success: (res) => {
					var sessionKey = res.data.session_key;
					var appId = APPID
					
					// 解密手机号
					var pc = new WXBizDataCrypt(appId, sessionKey)
					var data = pc.decryptData(encryptedData, iv)
					// 存储用户手机号到 localStorage
					uni.setStorageSync('phone', data.phoneNumber)
					resolve({code: 200, msg: 'ok', data: data.phoneNumber})
				},fail: (error) => {
					console.log('手机号码授权失败', error)
					reject({ code: 500, msg: error })
				}
			})
		})
	},
	
	// 根据月份获取每个月的天数
	getDays(year, month) {
		let days = [31,28,31,30,31,30,31,31,30,31,30,31]
		// 判断是闰年还是平年 闰年2月份天数为29天 平年28天
		if ((year % 4 ===0) && (year % 100 !==0 || year % 400 === 0)) {
			days[1] = 29
		}
		return days[month]
	},
	
	// 根据时间戳计算出剩余天数 小时 分钟 秒
	daysRemaining(timestamp) {
		let time = {
			day: 0,
			hour: 0,
			minute: 0,
			second: 0
		}
		
		time.day = Math.floor(timestamp / (24 * 3600 * 1000))
		let leave1 = timestamp % (24 * 3600 * 1000)
		time.hour = Math.floor(leave1 / (3600 * 1000))
		let leave2 = leave1 % (3600 * 1000)
		time.minute = Math.floor(leave2 / (60 * 1000))
		let leave3 = leave2 % (60 * 1000)
		time.second = Math.round(leave3 / 1000)
		
		return time
	}
}