export default{
	data(){
		return {}
	},
	// 发送给朋友
	onShareAppMessage(){},
	// 分享到朋友圈
	onShareTimeline(){}
}