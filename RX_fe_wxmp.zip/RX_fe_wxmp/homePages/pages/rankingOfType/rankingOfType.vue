<template>
	<view class="pageContainer">
		<view class="timeQueryTab">
			<view :class="{tab:true,activeTab:tabIndex=='2'}" @click="changeTimeTab('2')">日</view>
			<view :class="{tab:true,activeTab:tabIndex=='3'}" @click="changeTimeTab('3')">周</view>
			<view :class="{tab:true,activeTab:tabIndex=='4'}" @click="changeTimeTab('4')">月</view>
			<view :class="{tab:true,activeTab:tabIndex=='5'}" @click="changeTimeTab('5')">年</view>
			<view :class="{tab:true,activeTab:tabIndex=='6'}" @click="chooseDate">自定义</view>
		</view>
		<view class="dateTab" v-if="tabIndex=='2'">
			<view class="preDay" @click="changeDay('pre')">前一天</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{currentDate}}</view>
			<view class="nextDay" @click="changeDay('next')" v-if="currentDate!=today">后一天</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);" v-else>后一天</view>
		</view>
		<view class="dateTab" v-if="tabIndex=='3'">
			<view class="preDay" @click="changeWeek('pre')">前一周</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{currentWeekStart}} 至 {{currentWeekEnd}}</view>
			<view class="nextDay" @click="changeWeek('next')" v-if="currentWeekEnd!=today">后一周</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);" v-else>后一周</view>
		</view>
		<view class="dateTab" v-if="tabIndex=='4'">
			<view class="preDay" @click="changeMonth('pre')">前一月</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{startMonthDate}} 至 {{endMonthDate}}
			</view>
			<view class="nextDay" @click="changeMonth('next')" v-if="endMonthDate!=today">后一月</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);" v-else>后一月</view>
		</view>
		<view class="dateTab" v-if="tabIndex=='5'">
			<view class="preDay" style="color: rgba(150, 151, 153, 1);">前一年</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">2024-01-01 至 {{currentDate}}</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);">后一年</view>
		</view>
		<view class="dateTab" v-else-if="tabIndex=='6'">
			<view class="preDay"></view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{startDate}} 至 {{endDate}}</view>
			<view class="nextDay"></view>
		</view>
		<view class="pageContent">
			<view class="showData" v-if="pageTitle=='菜品烹饪'">
				<view class="dataLeft">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;">烹饪次数</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="categoryData.cur">{{categoryData.cur.c}}</text>
								<text v-else>0</text>
							</view>
							<view style="width: 50%;">
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="categoryData.QOQ.cq==0.0">{{categoryData.QOQ.cq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="categoryData.QOQ.cq>0.0">{{categoryData.QOQ.cq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="categoryData.QOQ.cq<0.0">{{categoryData.QOQ.cq}}%</text>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
							<view style="width: 50%;">次</view>
							<view style="width: 50%;">比昨日
								<text v-if="categoryData.QOQ.cq>0.0">上升</text>
								<text v-else-if="categoryData.QOQ.cq<0.0">下降</text>
								<text v-else>持平</text>
							</view>
						</view>
					</view>
				</view>
				<view class="dataRight">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;">烹饪重量</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="categoryData.cur">
									<text
										v-if="categoryData.cur.last_spec_total">{{categoryData.cur.last_spec_total}}</text>
									<text v-else>0</text>
								</text>
							</view>
							<view style="width: 50%;" v-if="categoryData.QOQ.wq">
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="categoryData.QOQ.wq==0.0">{{categoryData.QOQ.wq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="categoryData.QOQ.wq>0.0">{{categoryData.QOQ.wq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="categoryData.QOQ.wq<0.0">{{categoryData.QOQ.wq}}%</text>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
							<view style="width: 50%;">
								<text>{{categoryData.cur.unit}}</text>
							</view>
							<view style="width: 50%;" v-if="categoryData.QOQ.wq">比昨日
								<text v-if="categoryData.QOQ.wq>0.0">上升</text>
								<text v-else-if="categoryData.QOQ.wq<0.0">下降</text>
								<text v-else>持平</text>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="showData" v-else-if="pageTitle=='食材用量'">
				<view class="dataLeft">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;">食材总量</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="categoryData.cur">
									<text
										v-if="categoryData.cur.last_spec_total">{{categoryData.cur.last_spec_total}}</text>
									<text v-else>0</text>
								</text>
							</view>
							<view style="width: 50%;">
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="categoryData.QOQ.cq==0.0">{{categoryData.QOQ.cq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="categoryData.QOQ.cq>0.0">{{categoryData.QOQ.cq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="categoryData.QOQ.cq<0.0">{{categoryData.QOQ.cq}}%</text>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
							<view style="width: 50%;">千克</view>
							<view style="width: 50%;">比昨日
								<text v-if="categoryData.QOQ.cq>0.0">上升</text>
								<text v-else-if="categoryData.QOQ.cq<0.0">下降</text>
								<text v-else>持平</text>
							</view>
						</view>
					</view>
				</view>
				<view class="dataRight">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;">损耗量</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="categoryData.cur">
									<text v-if="categoryData.cur.last_loss">{{categoryData.cur.last_loss}}</text>
									<text v-else>0</text>
								</text>
							</view>
							<view style="width: 50%;" v-if="categoryData.QOQ.wq">
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="categoryData.QOQ.wq==0.0">{{categoryData.QOQ.wq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="categoryData.QOQ.wq>0.0">{{categoryData.QOQ.wq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="categoryData.QOQ.wq<0.0">{{categoryData.QOQ.wq}}%</text>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;" v-if="categoryData.QOQ.wq">
							<view style="width: 50%;">千克</view>
							<view style="width: 50%;">比昨日
								<text v-if="categoryData.QOQ.wq>0.0">上升</text>
								<text v-else-if="categoryData.QOQ.wq<0.0">下降</text>
								<text v-else>持平</text>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="showData" v-else-if="pageTitle=='调料用量'">
				<view class="dataLeft">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;">调料用量</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="categoryData.cur">
									<text
										v-if="categoryData.cur.last_spec_total">{{categoryData.cur.last_spec_total}}</text>
									<text v-else>0</text>
								</text>
							</view>
							<view style="width: 50%;">
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="categoryData.QOQ.cq==0.0">{{categoryData.QOQ.cq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="categoryData.QOQ.cq>0.0">{{categoryData.QOQ.cq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="categoryData.QOQ.cq<0.0">{{categoryData.QOQ.cq}}%</text>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
							<view style="width: 50%;">千克</view>
							<view style="width: 50%;">比昨日
								<text v-if="categoryData.QOQ.cq>0.0">上升</text>
								<text v-else-if="categoryData.QOQ.cq<0.0">下降</text>
								<text v-else>持平</text>
							</view>
						</view>
					</view>
				</view>
				<view class="dataRight">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;">损耗量</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="categoryData.cur">
									<text v-if="categoryData.cur.last_loss">{{categoryData.cur.last_loss}}</text>
									<text v-else>0</text>
								</text>
							</view>
							<view style="width: 50%;" v-if="categoryData.QOQ.wq">
								<!-- <image v-if="Number(categoryData.QOQ.wq)>0"
									style="width: 16upx;height: 20upx;margin-right: 16upx;"
									src="../../static/image/goUp.png" mode=""></image>
								<image v-if="Number(categoryData.QOQ.wq)<0"
									style="width: 16upx;height: 20upx;margin-right: 16upx;"
									src="../../static/image/comeDown.png" mode=""></image> -->
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="categoryData.QOQ.wq==0.0">{{categoryData.QOQ.wq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="categoryData.QOQ.wq>0.0">{{categoryData.QOQ.wq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="categoryData.QOQ.wq<0.0">{{categoryData.QOQ.wq}}%</text>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;" v-if="categoryData.QOQ.wq">
							<view style="width: 50%;">千克</view>
							<view style="width: 50%;">比昨日
								<text v-if="categoryData.QOQ.wq>0.0">上升</text>
								<text v-else-if="categoryData.QOQ.wq<0.0">下降</text>
								<text v-else>持平</text>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="categoryDetail" v-if="dataTotal">
				<!-- <scroll-view v-if="true" scroll-top="0" scroll-y="true" class="scroll-Y list" @scrolltolower="lower"> -->
				<view class="category" v-for="item,index in categoryData.data" :key="index">
					<view class="categoryLeft">
						<view class="categoryIndex" v-if="index+1==1" style="background-color:rgba(255, 125, 0, 1);">
							{{index+1}}
						</view>
						<view class="categoryIndex" v-else-if="index+1==2"
							style="background-color:rgba(255, 207, 139, 1);">{{index+1}}</view>
						<view class="categoryIndex" v-else-if="index+1==3"
							style="background-color:rgba(255, 228, 186, 1);">{{index+1}}</view>
						<view class="categoryIndex" v-else
							style="background-color:rgba(255, 247, 232, 1);color: rgba(150, 151, 153, 1);">{{index+1}}
						</view>
						<view class="categoryLogo" v-if="pageTitle=='菜品烹饪'">{{item.recipe_category_name.slice(0,5)}}
						</view>
						<view class="categoryLogo" v-else-if="pageTitle=='食材用量'">{{item.name.slice(0,5)}}</view>
						<view class="categoryLogo" v-else-if="pageTitle=='调料用量'">{{item.name.slice(0,5)}}</view>
					</view>
					<view class="categoryRight">
						<view style="font-size: 18px;color: rgba(0, 0, 0, 1);margin-bottom: 26upx;"
							v-if="pageTitle=='菜品烹饪'">
							<text v-if="item.recipe_category_name.length<7">{{item.recipe_category_name}}</text>
							<text v-else>{{item.recipe_category_name.slice(0,6)}}...</text>
						</view>
						<view style="font-size: 18px;color: rgba(0, 0, 0, 1);margin-bottom: 26upx;"
							v-else-if="pageTitle=='食材用量'">
							<text v-if="item.name.length<7">{{item.name}}</text>
							<text v-else>{{item.name.slice(0,6)}}...</text>
						</view>
						<view style="font-size: 18px;color: rgba(0, 0, 0, 1);margin-bottom: 26upx;"
							v-else-if="pageTitle=='调料用量'">
							<text v-if="item.name.length<7">{{item.name}}</text>
							<text v-else>{{item.name.slice(0,6)}}...</text>
						</view>
						<view v-if="pageTitle=='菜品烹饪'" style="color:rgba(166, 166, 166, 1);margin-bottom: 22upx;">
							<text v-if="item.info">[{{item.info}}]</text>
						</view>
						<view v-else-if="pageTitle=='食材用量'" style="margin-bottom: 22upx;">
							<text v-if="item.itemq">
								<text style="color: rgba(150, 151, 153, 1);" v-if="item.itemq==0.0">{{item.itemq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);" v-if="item.itemq>0.0">{{item.itemq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);" v-if="item.itemq<0.0">{{item.itemq}}%</text>
							</text>
							<text style="color: rgba(150, 151, 153, 1);" v-else>0.0%</text>
						</view>
						<view v-else-if="pageTitle=='调料用量'" style="margin-bottom: 22upx;">
							<text v-if="item.itemq">
								<text style="color: rgba(150, 151, 153, 1);" v-if="item.itemq==0.0">{{item.itemq}}%</text>
								<text style="color: rgba(255, 125, 0, 1);" v-if="item.itemq>0.0">{{item.itemq}}%</text>
								<text style="color: rgba(0, 180, 42, 1);" v-if="item.itemq<0.0">{{item.itemq}}%</text>
							</text>
							<text style="color: rgba(150, 151, 153, 1);" v-else>0.0%</text>
						</view>
						<view style="color:rgba(166, 166, 166, 1)" v-if="pageTitle=='菜品烹饪'">次数：{{item.c}}</view>
						<view style="color:rgba(166, 166, 166, 1)" v-else-if="pageTitle=='食材用量'">重量：{{item.c}}kg</view>
						<view style="color:rgba(166, 166, 166, 1)" v-else-if="pageTitle=='调料用量'">重量：{{item.c}}kg</view>
					</view>
				</view>
				<!-- </scroll-view> -->
			</view>
			<view v-else class="emptyContent" style="text-align: center;margin-top: 120upx;">
				<image style="width: 150px;height: 126px;" src="../../../static/image/menuEmpty.png" mode=""></image>
				<view style="font-size: 12px;margin-top:24px;color: rgba(166, 166, 166, 1);">
					暂无数据
				</view>
			</view>
			<date-range mode="date" :showMutibleDate="showMutibleDate" :startDate="startDate" :endDate="endDate"
				@onSelected="dateSelected">
			</date-range>

		</view>
	</view>
</template>

<script>
	import moment from "moment"
	import dateRange from '@/homePages/components/zxp-datepickerRange/zxp-datepickerRange.vue'
	export default {
		components: {
			dateRange
		},
		data() {
			return {
				currentMonth: new Date(), // 当前日期
				startMonthDate: '', // 开始日期
				endMonthDate: '' ,// 结束日期
				today: '',
				endDate: moment().format('YYYY-MM-DD'), // 默认结束时间 YYYY/MM/DD
				startDate: moment().format('YYYY-MM-DD'), // 默认开始时间 YYYY/MM/DD
				showMutibleDate: false,
				// 本周的开始时间
				currentWeekStart: '',
				currentWeekEnd: '',
				currentMonthStart: '',
				currentMonthEnd: '',
				dateValue: '',
				timeValue: '',
				tabIndex: '2',
				pageTitle: '',
				label: '',
				org_business_id: '',
				currentDate: '',
				// 菜品数据
				categoryData: [],
				nowDate: "",
				fullYear: "",
				month: "",
				endOfMonth: "",
				endDate: "",
				startDate: "",
				dataTotal: 0,
				page: 1
			}
		},
		methods: {
			setPageTitle(title) {
				uni.setNavigationBarTitle({
					title: title
				});
			},
			changeTimeTab(value) {
				this.tabIndex = value
				this.page = 1
				this.categoryData = []
				this.currentDate = new Date().toISOString().slice(0, 10)
				this.today = new Date().toISOString().slice(0, 10)
				this.nowDate = new Date();
				if (value == '4') {
					var monthDate = this.getMonthRange(new Date(this.currentDate))
					this.currentMonthStart = moment(monthDate.start).format('YYYY-MM-DD')
					if (new Date(monthDate.end).getTime() > new Date(this.currentDate).getTime()) {
						this.currentMonthEnd = this.currentDate
					} else {
						this.currentMonthEnd = monthDate.end
					}
					this.getCategoryRankData(this.currentMonthStart, this.page)
				} else if (value == '3') {
					this.getCategoryRankData(this.currentWeekStart, this.page)
				} else if (value == '2') {
					this.getCategoryRankData(this.currentDate, this.page)
				} else if (value == '5') {
					this.getCategoryRankData(this.currentDate, this.page)
				} else if (value == '6') {
					this.getCategoryRankData(this.currentDate, this.page)
				}
			},
			// 处理小数取值
			formatDecimal(num, decimal) { //num 传入小数, decimal 保留几位小数
				var _num = num.toString()
				var index = _num.indexOf('.')
				if (index !== -1) {
					_num = _num.substring(0, decimal + index + 1)
				} else {
					_num = _num.substring(0)
				}
				return parseFloat(_num).toFixed(decimal)
			},
			// 获取商户、门店下菜品排行数据
			async getCategoryRankData(date, page, data) {
				uni.showLoading({
					title: '加载中'
				})
				if (this.pageTitle == '菜品烹饪') {
					let res
					let cq
					let wq
					if (this.label == '商户') {
						res = await this.API.home.getUserCategoryRank(this.org_business_id, this.tabIndex, date, data,
							page)
					} else {
						res = await this.API.home.getStoreCategoryRank(this.org_business_id, this.tabIndex, date, data,
							page)
					}
					uni.hideLoading()
					this.categoryData = res
					this.dataTotal = res.paging.total_records
					if (res.per != null &&res.per.c != null&& res.per.c != 0) {
						cq = ((res.cur.c - res.per.c) / res.per.c) * 100
						cq = this.formatDecimal(cq, 1)
					} else {
						cq = '0.0'
					}
					if (res.per != null &&res.per.spec_total != null&& res.per.spec_total != 0) {
						wq = ((res.cur.spec_total - res.per.spec_total) / res.per.spec_total) * 100
						wq = this.formatDecimal(wq, 1)
					} else {
						wq = '0.0'
					}
					this.categoryData.QOQ = {
						'cq': cq,
						'wq': wq
					}
					if (this.categoryData.cur.spec_total < 1000) {
						this.categoryData.cur.last_spec_total = this.formatDecimal(this.categoryData.cur.spec_total,
							1)
						this.categoryData.cur.unit = '克'
					} else {
						this.categoryData.cur.last_spec_total = this.formatDecimal(this.categoryData.cur.spec_total /
							1000,
							1)
						this.categoryData.cur.unit = '千克'
					}
				} else if (this.pageTitle == '食材用量' || this.pageTitle == '调料用量') {
					// console.log('调料用量')
					let res
					let cq
					let wq
					if (this.pageTitle == '食材用量') {
						if (this.label == '商户') {
							res = await this.API.home.getUserFoodRank(this.org_business_id, this.tabIndex, date, data,
								page)
						} else {
							res = await this.API.home.getStoreFoodRank(this.org_business_id, this.tabIndex, date, data,
								page)
						}
					} else {
						if (this.label == '商户') {
							res = await this.API.home.getUserFlavourRank(this.org_business_id, this.tabIndex, date,
								data, page)
						} else {
							res = await this.API.home.getStoreFlavourRank(this.org_business_id, this.tabIndex, date,
								data, page)
						}
					}
					this.categoryData = res
					this.dataTotal = res.paging.total_records
					if (this.dataTotal) {
						this.categoryData.data = this.categoryData.data.map((item) => {
							let itemq
							if(item.per){
								if (item.per != 0 || item.per != 0.0000) {
									itemq = ((item.c - item.per) / item.per) * 100
									itemq = this.formatDecimal(itemq, 1)
								} else {
									itemq = '0.0'
								}
							}else{
								itemq = '0.0'
							}
							
							return {
								...item,
								itemq: itemq,
								c: this.formatDecimal(item.c, 1)
							}
						})
					}
					if(res.per != null&& res.per.total != null){
						if (res.per.total != 0 || res.per.total != 0.0000) {
							cq = ((res.cur.total - res.per.total) / res.per.total) * 100
							cq = this.formatDecimal(cq, 1)
						} else {
							cq = '0.0'
						}
					}else{
						cq = '0.0'
					}
					if(res.per != null && res.per.loss != null ){
						if (res.per.loss != 0 || res.per.loss != 0.0000) {
							wq = ((res.cur.loss - res.per.loss) / res.per.loss) * 100
							wq = this.formatDecimal(wq, 1)
						} else {
							wq = '0.0'
						}
					}else{
						wq = '0.0'
					}
					
					this.categoryData.QOQ = {
						'cq': cq,
						'wq': wq
					}
					console.log(this.categoryData,'this.categoryData')
					this.categoryData.cur.last_spec_total = this.formatDecimal(this.categoryData.cur.total,
						1)
					
					this.categoryData.cur.last_loss = this.formatDecimal(this.categoryData.cur.loss,
						1)
					uni.hideLoading()

				}
			},
			
			chooseDate() {
				this.showMutibleDate = !this.showMutibleDate
				this.tabIndex = '6'
			},
			// 自定义选择时间
			dateSelected(e) {
				if (e) {
					let start = e.start
					let end = e.end
					this.start = moment(start).format('YYYY-MM-DD');
					this.end = moment(end).format('YYYY-MM-DD');
					this.startDate = start,
						this.endDate = end
				}
				this.getCategoryRankData(this.startDate, this.page,{
					begin_date: this.startDate,
					end_date: this.endDate
				})
				// console.log(e, 'e')
				// console.log(this.startDate, 'this.startDate')
				// console.log(this.endDate, 'this.endDate')
				this.showMutibleDate = false
			},
			// 获取本月的第一天
			getMonthRange(today) {
				const year = today.getFullYear();
				const month = today.getMonth();
				const day = today.getDate();
				const startDate = new Date(year, month, 2); // 本月的第一天
				const endDate = new Date(year, month + 1, 0); // 本月的最后一天
				return {
					start: startDate.toISOString().split('T')[0],
					end: endDate.toISOString().split('T')[0],
				};
			},
			getTimeandWeek() {
				var weekDay = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期天'];
				var now = new Date();
				// 获取本周的第一天（星期一）
				var firstDay = new Date(now.setDate(now.getDate() - now.getDay() + (now.getDay() === 0 ? -6 : 1)));
				// 存储本周的日期
				var weekDates = [];
				// 循环获取本周的所有日期
				for (var i = 0; i < 7; i++) {
					var tempDate = new Date(firstDay);
					tempDate.setDate(firstDay.getDate() + i);
					var year = tempDate.getFullYear();
					var month = tempDate.getMonth() + 1;
					var day = tempDate.getDate();
					weekDates.push({
						week: weekDay[i],
						date: year + '-' + (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') + day
					});
				}
				this.currentWeekStart = weekDates[0].date
				var weekDateEnd = weekDates[6].date
				if (new Date(weekDateEnd).getTime() > new Date(this.currentDate).getTime()) {
					this.currentWeekEnd = this.currentDate
				} else {
					this.currentWeekEnd = weekDates[6].date
				}
			},
			// 格式化日期为YYYY-MM-DD
			formatDate(date) {
				let year = date.getFullYear();
				let month = (date.getMonth() + 1).toString().padStart(2, '0');
				let day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			// 获取前一天后一天
			changeDay(value) {
				var currentDay = new Date(this.currentDate)
				if (value == 'pre') {
					let yesterday = new Date(currentDay);
					yesterday.setDate(yesterday.getDate() - 1);
					this.currentDate = this.formatDate(yesterday)
				} else {
					if (this.currentDate == this.today) return
					let tomorrow = new Date(this.currentDate);
					tomorrow.setDate(tomorrow.getDate() + 1);
					this.currentDate = this.formatDate(tomorrow)
				}
				this.page = 1
				this.getCategoryRankData(this.currentDate, this.page)
			},
			// 获取上一周的日期范围
			getLastWeekRange() {
				const today = new Date(this.currentWeekStart);
				const lastWeekStart = new Date(today);
				lastWeekStart.setDate(today.getDate() - 7);
				const lastWeekEnd = new Date(today);
				lastWeekEnd.setDate(today.getDate() - 1);
				return {
					start: lastWeekStart,
					end: lastWeekEnd
				};
			},
			// 获取下一周的日期范围
			getNextWeekRange() {
				const today = new Date(this.currentWeekStart);
				const nextWeekStart = new Date(today);
				nextWeekStart.setDate(today.getDate() + 7);
				const nextWeekEnd = new Date(today);
				nextWeekEnd.setDate(today.getDate() + 13);
				return {
					start: nextWeekStart,
					end: nextWeekEnd
				};
			},
			getFullDate(targetDate) {
				var D, y, m, d;
				if (targetDate) {
					D = new Date(targetDate);
					y = D.getFullYear();
					m = D.getMonth() + 1;
					d = D.getDate();
				} else {
					y = fullYear;
					m = month;
					d = date;
				}
				m = m > 9 ? m : '0' + m;
				d = d > 9 ? d : '0' + d;
				return y + '-' + m + '-' + d;
			},

			// 获取上个月、下个月
			last() {
				this.nowDate.setMonth(this.nowDate.getMonth() - 1);
				this.startDate = this.nowDate.getFullYear() + "-" + (this.nowDate.getMonth() + 1) + "-" + this.nowDate
					.getDate()
				this.endDate = this.getFullDate(new Date(this.nowDate.getFullYear(), this.nowDate.getMonth() + 1, 0))
			},
			next() {
				this.nowDate.setMonth(this.nowDate.getMonth() + 1);
				this.startDate = this.nowDate.getFullYear() + "-" + (this.nowDate.getMonth() + 1) + "-" + this.nowDate
					.getDate()
				this.endDate = this.getFullDate(new Date(this.nowDate.getFullYear(), this.nowDate.getMonth() + 1, 0))
			},
			formatDate2(date) {
			     const year = date.getFullYear();
			     const month = ('0' + (date.getMonth() + 1)).slice(-2);
			     const day = ('0' + date.getDate()).slice(-2);
			     return `${year}-${month}-${day}`;
			   },
			   updateDateRange() {
			     const startOfMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth(), 1);
			     const endOfMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() + 1, 0);
			     this.startMonthDate = this.formatDate2(startOfMonth);
			     this.endMonthDate = this.formatDate2(endOfMonth);
				 this.page = 1
				 this.getCategoryRankData(this.startMonthDate, this.page)
			   },
			   getPreviousMonth() {
			     this.currentMonth.setMonth(this.currentMonth.getMonth() - 1);
			     this.updateDateRange();
			   },
			   getNextMonth() {
			     this.currentMonth.setMonth(this.currentMonth.getMonth() + 1);
			     this.updateDateRange();
			   },
			changeMonth(value) {
				if (value == 'pre') {
					this.getPreviousMonth()
					// this.last()
					// this.currentMonthStart = moment(this.startDate).format('YYYY-MM-DD')
					// this.currentMonthEnd = moment(this.endDate).format('YYYY-MM-DD')
				} else {
					this.getNextMonth()
					// this.next()
					// if (new Date(this.endDate).getTime() > new Date(this.today).getTime()) {
					// 	this.currentMonthEnd = this.today
					// 	this.currentMonthStart = moment(this.startDate).format('YYYY-MM-DD')
					// } else {
					// 	this.currentMonthEnd = moment(this.endDate).format('YYYY-MM-DD')
					// 	this.currentMonthStart = moment(this.startDate).format('YYYY-MM-DD')
					// }
				}
				
			},
			changeWeek(value) {
				if (value == 'pre') {
					const lastWeek = this.getLastWeekRange();
					this.currentWeekStart = lastWeek.start.toLocaleDateString()
					this.currentWeekEnd = lastWeek.end.toLocaleDateString()
					this.currentWeekStart = moment(this.currentWeekStart).format('YYYY-MM-DD');
					this.currentWeekEnd = moment(this.currentWeekEnd).format('YYYY-MM-DD');
				} else {
					const nextWeek = this.getNextWeekRange();
					if (new Date(nextWeek.end.toLocaleDateString()).getTime() > new Date(this.today).getTime()) {
						this.currentWeekEnd = this.today
						this.currentWeekStart = nextWeek.start.toLocaleDateString()
						this.currentWeekStart = moment(this.currentWeekStart).format('YYYY-MM-DD');
						this.currentWeekEnd = moment(this.currentWeekEnd).format('YYYY-MM-DD');
					} else {
						this.currentWeekEnd = nextWeek.end.toLocaleDateString()
						this.currentWeekStart = nextWeek.start.toLocaleDateString()
						this.currentWeekStart = moment(this.currentWeekStart).format('YYYY-MM-DD');
						this.currentWeekEnd = moment(this.currentWeekEnd).format('YYYY-MM-DD');
					}
				}
				this.page = 1
				this.getCategoryRankData(this.currentWeekStart, this.page)
			}
		},
		onReady() {
			this.nowDate = new Date();
			this.fullYear = this.nowDate.getFullYear();
			this.month = this.nowDate.getMonth() + 1; // getMonth 方法返回 0-11，代表1-12月
			this.endOfMonth = new Date(this.fullYear, this.month, 0).getDate(); // 获取本月最后一天
			this.endDate = this.getFullDate(this.nowDate.setDate(this.endOfMonth)); //当月最后一天
			this.startDate = this.getFullDate(this.nowDate.setDate(1)); //当月第一天

		},
		onLoad(options) {
			this.pageTitle = options.title
			this.label = options.label
			this.org_business_id = options.org_business_id
			this.currentDate = new Date().toISOString().slice(0, 10)
			this.today = new Date().toISOString().slice(0, 10)
			this.setPageTitle(`${options.title}详情`);
			this.getCategoryRankData(this.currentDate, this.page)
			this.getTimeandWeek()
		}
	}
</script>

<style lang="less" scoped>
	.pageContainer {
		min-height: 100vh;
		background-color: rgba(240, 240, 240, 1);

		.timeQueryTab {
			display: flex;
			align-items: center;
			height: 112upx;
			border-top: 1px solid #F2F2F2;
			background-color: rgba(255, 255, 255, 1);

			.tab {
				width: 150upx;
				text-align: center;
				font-size: 14px;
				color: rgba(0, 0, 0, 0.9);
			}

			.activeTab {
				color: rgba(22, 93, 255, 1);
				font-weight: bold;
			}
		}

		.dateTab {
			display: flex;
			align-items: center;
			height: 112upx;
			background-color: rgba(255, 255, 255, 1);
			border-top: 1px solid #F2F2F2;

			.preDay,
			.nextDay {
				width: 150upx;
				text-align: center;
				font-size: 14px;
				color: rgba(22, 93, 255, 1);
			}

			.today {
				flex: 1;
				text-align: center;
				font-size: 14px;
			}
		}

		.pageContent {
			padding: 8px;

			.showData {
				width: 100%;
				min-height: 198upx;
				border-radius: 4px;
				background: rgba(255, 255, 255, 1);
				display: flex;

				// justify-content: space-between;
				.dataLeft {
					width: 50%;
					padding: 16upx 32upx;
					box-sizing: border-box;
				}

				.dataRight {
					width: 50%;
					padding: 16upx 32upx;
					box-sizing: border-box;
				}

			}

			.categoryDetail {
				margin-top: 16upx;

				// .scroll-Y {
				// 	height: calc(100vh - 432upx);

					.category {
						height: 244upx;
						background-color: rgba(255, 255, 255, 1);
						border-radius: 4px;
						margin-bottom: 16upx;
						display: flex;
						align-items: end;
						padding: 32upx 16upx;
						box-sizing: border-box;

						.categoryLeft {
							width: 320upx;
							height: 180upx;
							line-height: 180upx;
							border-radius: 4px;
							background-color: rgba(245, 248, 255, 1);
							margin-right: 16upx;
							position: relative;

							.categoryIndex {
								position: absolute;
								width: 64upx;
								height: 32upx;
								line-height: 32upx;
								text-align: center;
								border-radius: 4px 0px 4px 0px;
								font-size: 10px;
								color: rgba(255, 255, 255, 1);
							}

							.categoryLogo {
								text-align: center;
								color: rgba(38, 79, 247, 1);
								font-size: 24px;
								font-weight: 600;
							}
						}
					}
				// }
			}
		}
	}
</style>