<template>
	<view class="deviceContainer">
		<view class="tabList">
			<view :class="{tab:true,activeTab:activeTab=='1'}" @tap="changeTab('1')">
				<view class="">
					设备简介
				</view>
				<view :class="{activeBottom:activeTab=='1'}"></view>
			</view>
			<view :class="{tab:true,activeTab:activeTab=='2'}" @tap="changeTab('2')">
				<view class="">
					烹饪记录
				</view>
				<view :class="{activeBottom:activeTab=='2'}"></view>
			</view>
			<view :class="{tab:true,activeTab:activeTab=='3'}" @tap="changeTab('3')">
				<view class="">
					故障统计
				</view>
				<view :class="{activeBottom:activeTab=='3'}"></view>
			</view>
			<!-- <view :class="{tab:true,activeTab:activeTab=='4'}" @tap="changeTab('4')">
				设备履历
			</view> -->
		</view>
		<view class="payBtn" v-if="activeTab=='1'">
			<button @tap="toCreateOrder" style="background-color: rgba(38, 79, 247, 1);color:#fff;border-radius: 0upx;">立即付费</button>
		</view>
		<view class="device_info" @tap="toProductDetail">
			<view class="infoLeft">
				<view class="device_image">
					<image style="width: 96upx;height: 88upx;margin-top: 10upx;" src="/static/image/robot.png" mode=""></image>
				</view>
				<view class="device_des">
					<view class="device_name">
						{{deviceName}}
					</view>
					<view class="device_code">
						SN编号：{{deviceInfo.device_code}}
					</view>
					<view class="device_category">
						<text v-if="deviceInfo.deviceInfos.category_code">品类：{{deviceInfo.deviceInfos.category_code}}</text>
						<text v-else>品类：-</text>
						<text v-if="deviceInfo.deviceInfos.type_code">型号：{{deviceInfo.deviceInfos.type_code}}</text>
						<text v-else>型号：-</text>
						<text v-if="deviceInfo.deviceInfos.version_code">版本：{{deviceInfo.deviceInfos.version_code}}</text>
						<text v-else>版本：-</text>
					</view>
				</view>
			</view>
			<view class="toDetail">
				<!-- <text class="detail">详情</text> -->
				<text class="iconfont icon-xiangyou"></text>
			</view>
		</view>
		<view class="device_intro" v-if="activeTab=='1'">
			
			<view class="device_status">
				<view>设备状态：</view>
				<view class="statusBox green" v-if="deviceInfo.status=='布机'||deviceInfo.status=='布机中'||deviceInfo.status=='在库'">
					{{deviceInfo.status}}
				</view>
				<view class="statusBox gray" v-else-if="deviceInfo.status=='未激活'">
					{{deviceInfo.status}}
				</view>
				<view class="statusBox blue" v-else-if="deviceInfo.status=='运营中'">
					{{deviceInfo.status}}
				</view>
				<view class="statusBox red" v-else>
					{{deviceInfo.status}}
				</view>
			</view>
			<view class="end_time">
				<view>计费结束时间：</view>
				<view>-</view>
			</view>
			<view class="device_status">
				<view>门店名称：</view>
				<view v-if="deviceInfo.store.name">{{deviceInfo.store.name}}</view>
				<view v-else>-</view>
			</view>
			<view class="end_time">
				<view>门店地址：</view>
				<view v-if="deviceInfo.store.address_detail">{{deviceInfo.store.address_detail}}</view>
				<view v-else>-</view>
			</view>
			<view class="device_status">
				<view>运营区域：</view>
				<view>-</view>
			</view>
			<view class="end_time">
				<view>所属渠道：</view>
				<view v-if="deviceInfo.channel.name">{{deviceInfo.channel.name}}</view>
				<view v-else>-</view>
			</view>
			<view class="device_status">
				<view>客户名称：</view>
				<view v-if="deviceInfo.user.name">{{deviceInfo.user.name}}</view>
				<view v-else>-</view>
			</view>
			<!-- <view class="end_time">
				<view>出厂时间：</view>
				<view v-if="deviceInfo.created_at">{{(new Date(deviceInfo.created_at).toJSON().replace('T',' ')).split('.')[0]}}</view>
				<view v-else>
					-
				</view>
			</view> -->
			<view class="title" v-if="orderInfo.order">
				订单信息
			</view>
			<view class="end_time" v-if="orderInfo.order">
				<view>订单编号：</view>
				<view  v-if="orderInfo.order.code">{{orderInfo.order.code}}</view>
				<view v-else>
					-
				</view>
			</view>
			<view class="end_time" v-if="orderInfo.order">
				<view>付费类型：</view>
				<view v-if="orderInfo.order.commission_plan_name">{{orderInfo.order.commission_plan_name}}</view>
				<view v-else>
					-
				</view>
			</view>
			<view class="end_time" v-if="orderInfo.order">
				<view>付费效期：</view>
				<view v-if="orderInfo.order.months">{{orderInfo.order.months}}个月</view>
				<view v-else>
					-
				</view>
			</view>
			<view class="end_time" v-if="orderInfo.order">
				<view>计费开始时间：</view>
				<view v-if="orderInfo.order.code">{{(new Date(deviceInfo.created_at).toJSON().replace('T',' ')).split('.')[0]}}</view>
				<view v-else>
					-
				</view>
			</view>
		</view>
		<view class="device_intro" v-if="activeTab=='2'">
			<view class="title" v-if="cookedList.length">
				烹饪记录
			</view> 
			<view class="recordContent" v-if="cookedList.length">
				<view class="record" v-for="item in cookedList" :key="item.ts_end">
					<view class="recordLeft">
						<view class="recordTitle">
							<text style="color: rgba(166, 166, 166, 1);margin-right:5px;">{{item.menu_cnt}}</text>
							<text style="color: rgba(0, 0, 0, 1);">{{item.menu}}</text>
						</view>
						<view class="recordTime">
							烹饪时间：{{item.ts}} - {{item.ts_end}}
						</view>
					</view>
					<view class="recordRight" style="margin-top: 24upx;">
						<text style="color: rgba(38, 79, 247, 1);font-size: 32upx;margin-right:5px;">{{item.menu_time}}</text>
						<text style="color: rgba(166, 166, 166, 1);font-size: 20upx;">秒</text>
					</view>
				</view>
			</view>
			<view class="empty" v-else  style="text-align: center;font-size: 40upx;color:rgba(166, 166, 166, 1);margin-top: 100upx;">
				暂无数据
			</view>
		</view>
		<view class="device_intro" v-if="activeTab=='3'">
			<view class="" style="text-align: center;font-size: 40upx;color:rgba(166, 166, 166, 1);margin-top: 100upx;">
				敬请期待
			</view>
		</view>
		<!-- <view class="device_intro" v-if="this.activeTab=='4'">
			设备履历
		</view> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				activeTab:'1',
				deviceInfo:null,
				deviceId:'',
				deviceName:'暂无名称',
				cookedList:[],
				orderInfo:uni.getStorageSync('deviceDetail')
			}
		},
		methods: {
			changeTab(val){
				this.activeTab=val
				if(val=='2'){
					this.getCookedDetail()
				}
			},
			toProductDetail(){
				
				uni.navigateTo({
					url:'/homePages/pages/productDetail/productDetail'
				})
			},
			async getDeviceDetail(){
				const res=await this.API.home.getDeviceById(this.deviceId)
				if(res.code==0){
					this.deviceInfo=res.data
					uni.setStorageSync('deviceDetail',res.data)
				}
			},
			toCreateOrder(){
				if(this.orderInfo.user){
					uni.navigateTo({
						url:`/pages/order/createOrder/createOrder?companyName=${this.orderInfo.user.name}&id=${this.orderInfo.id}&code=${this.orderInfo.device_code}`
					})
				}else{
					uni.navigateTo({
						url:`/pages/order/createOrder/createOrder?companyName=''&id=${this.orderInfo.id}&code=${this.orderInfo.device_code}`
					})
				}
			},
			async getCookedDetail(){
				const res=await this.API.home.getCookedByCode(this.deviceInfo.device_code)
				if(res.code==0){
					if(res.data){
						this.cookedList=res.data.map((item)=>{
							 if(item.ts){
								return{
									...item,
									ts:(new Date(item.ts)).toLocaleDateString().replace(/\//g,"-")+" "+(new Date(item.ts)).toTimeString().substr(0,8),
									ts_end:(new Date(item.ts_end)).toLocaleDateString().replace(/\//g,"-")+" "+(new Date(item.ts_end)).toTimeString().substr(0,8),
								}
							}else{
								return{
									...item
								}
							}
						})
					}else{
						this.cookedList=[]
					}
					// console.log(res)
				}
			}
		},
		onLoad(options) {
			this.deviceId=options.deviceId
			this.deviceName=options.name
			this.getDeviceDetail()
			// console.log(options)
		}
	}
</script>

<style lang="less" scoped>
	.deviceContainer{
		width: 100%;
		height: 100vh;
		position: relative;
		.payBtn{
			position: fixed;
			width: 100%;
			height: 96upx;
			line-height: 96upx;
			bottom: 66upx;
		}
		.tabList{
			width: 654upx;
			height: 58upx;
			margin:0 auto;
			font-size: 28upx;
			color:#A9A9AC;
			display: flex;
			justify-content: space-between;
			// align-items: center;
			padding-top: 26upx;
			border-bottom: 1px solid #EBEBEB;
			.tab{
				width: 176upx;
				text-align: center;
				position: relative;
			}
			.activeTab{
				color: rgba(38, 79, 247, 1);
			}
			.activeBottom{
				width: 176upx;
				height: 2upx;
				background-color: rebeccapurple;
				color:rgba(38, 79, 247, 1);
				position: absolute;
				bottom: 0upx;
			}
		}
		.device_info{
			width: 728upx;
			height: 220upx;
			box-sizing: border-box;
			border-bottom: 1px solid #EBEBEB;
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin: 0 auto;
			position:relative;
			
			.toDetail{
				font-size: 22upx;
				color:#264FF7;
				margin-right: 10upx;
				.detail{
					color:#A6A6A6;
					margin-right: 16upx;
				}
			}
			.infoLeft{
				display: flex;
				align-items: center;
				.device_des{
					.device_name{
						font-size: 32upx;
						margin-bottom: 16upx;
					}
					.device_code{
						font-size: 24upx;
						color:#A6A6A6;
						margin-bottom: 16upx;
					}
					.device_category{
						font-size: 24upx;
						color:#A6A6A6;
						text{
							margin-right: 16upx;
						}
					}
					
				}
				.device_image{
					width: 128upx;
					height: 128upx;
					line-height: 128upx;
					text-align: center;
					border-radius: 8upx;
					margin-right: 32upx;
					background-color: #EAEDFC;
				}
			}
			
		}
		.device_intro{
			height: 1538upx;
			.recordContent{
				padding: 0upx 10upx;
				box-sizing: border-box;
				.record{
					width:728upx;
					height: 130upx;
					border-bottom: 1px solid #F9F9F9;
					display: flex;
					padding-left: 32upx;
					box-sizing: border-box;
					justify-content: space-between;
					.recordTitle{
						font-size: 32upx;
						margin-top: 24upx;
					}
					.recordTime{
						font-size: 20upx;
						color:rgba(166, 166, 166, 1);
						margin-top: 16upx;
					}
				}
			}
			.title{
				width: 750upx;
				height: 80upx;
				// line-height: 80upx;
				display: flex;
				align-items: center;
				padding: 12upx 16upx;
				box-sizing: border-box;
				color:#7A7A7A;
				font-size: 28upx;
				background-color: #F5F5F5;
			}
			
			.device_status,.end_time{
				width: 728upx;
				height: 96upx;
				padding:0upx 20upx;
				box-sizing: border-box;
				border-bottom: 1px solid #EBEBEB;
				display: flex;
				align-items: center;
				justify-content: space-between;
				margin: 0 auto;
				font-size: 28upx;
				
				view:first-child{
					color:#A6A6A6;
				}
				.statusBox{
					width: 82upx;
					height: 32upx;
					line-height: 32upx;
					text-align: center;
					border-radius: 8upx;
					font-size: 24upx;
				}
				.gray{
					background-color: #E5E5E5;
					color:#848484;
				}
				.blue{
					background-color: #EAEDFC;
					color:#264FF7;
				}
				.red{
					background-color: #F7EAEA;
					color:#D43030;
				}
				.green{
					color:#43CF7C;
					background-color:#F8FFEE;
				}
			}
			
		}
	}
</style>
