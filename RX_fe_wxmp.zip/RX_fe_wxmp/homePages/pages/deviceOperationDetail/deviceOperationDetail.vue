<template>
	<view class="pageBox">
		<view class="pageTop" v-if="pageTitle=='调料校准'">
			<view class="topItem">
				<view class="topItemStatus">待校准</view>
				<view class="topItemDays" style="color:rgba(238, 10, 36, 1)">
					{{deviceDetailData.pump_calibration.need_pump_calibration_red}}
				</view>
				<view class="topItemDes">超过8天未校准</view>
			</view>
			<view class="topItem">
				<view class="topItemStatus">注意校准</view>
				<view class="topItemDays" style="color:rgba(255, 125, 0, 1)">
					{{deviceDetailData.pump_calibration.need_pump_calibration_yellow}}
				</view>
				<view class="topItemDes">超过7天未校准</view>
			</view>
			<view class="topItem">
				<view class="topItemStatus">已校准</view>
				<view class="topItemDays" style="color:rgba(7, 193, 96, 1)">
					{{deviceDetailData.pump_calibration.need_pump_calibration_green}}
				</view>
				<view class="topItemDes">5天内已校准</view>
			</view>
		</view>
		<view class="pageTop" style="display: flex;justify-content: center;" v-if="pageTitle=='养锅管理'">
			<view class="topItem">
				<view class="topItemStatus">注意养锅</view>
				<view class="topItemDays" style="color:rgba(255, 125, 0, 1)">
					{{deviceDetailData.pot_maintain.need_pot_maintain_red}}
				</view>
				<view class="topItemDes">超过1天未养锅</view>
			</view>
			<view class="topItem">
				<view class="topItemStatus">已养锅</view>
				<view class="topItemDays" style="color:rgba(7, 193, 96, 1)">
					{{deviceDetailData.pot_maintain.need_pot_maintain_green}}
				</view>
				<view class="topItemDes">1天内已养锅</view>
			</view>
		</view>
		<view class="pageTop" style="display: flex;justify-content: center;" v-if="pageTitle=='料管清洗'">
			<view class="topItem">
				<view class="topItemStatus">注意清洗</view>
				<view class="topItemDays" style="color:rgba(255, 125, 0, 1)">
					{{deviceDetailData.pump_cleaning.need_pump_cleaning_red}}
				</view>
				<view class="topItemDes">超过1天未清洗</view>
			</view>
			<view class="topItem">
				<view class="topItemStatus">已清洗</view>
				<view class="topItemDays" style="color:rgba(7, 193, 96, 1)">
					{{deviceDetailData.pump_cleaning.need_pump_cleaning_green}}
				</view>
				<view class="topItemDes">1天内已清洗</view>
			</view>
		</view>
		<view class="toolTipBox">
			<img style="height:10px;width:10px;margin-right: 16upx;" src="/static/image/wenhao.png" alt="" />
			<text v-if="tooltipType">
				{{tooltipType}}
			</text>
		</view>
		<scroll-view v-if="true" scroll-top="0" scroll-y="true" class="scroll-Y list" @scrolltolower="lower">
			<view class="deviceList">
				<view class="deviceItem" v-for="item in deviceList" :key="item.device_code">
					<view class="deviceItemLeft">
						<view class="deviceName">
							<img style="height:11px;width:12px;margin-right: 16upx;"
                   src="/static/image/deviceDetailLogo.png" alt="" />
							<text class="name">{{item.device_name}}</text>
						</view>
						<view class="deviceSn">SN:{{item.device_code}}</view>
						<view class="deviceDes" v-if="pageTitle=='调料校准'">
							上次校准时间：
							<text v-if="item.pump_calibration_at">{{item.pump_calibration_at}}</text>
						</view>
						<view class="deviceDes" v-if="pageTitle=='养锅管理'">
							上次养锅时间：
							<text v-if="item.pot_maintain_at">{{item.pot_maintain_at}}</text>
						</view>
						<view class="deviceDes" v-if="pageTitle=='料管清洗'">
							上次清洗时间：
							<text v-if="item.pump_cleaning_at">{{item.pump_cleaning_at}}</text>
						</view>
						<view class="storeName">门店名称：{{item.store_name}}（{{item.user_name}}）</view>
					</view>
					<view class="deviceItemRight">
						<view class="deviceDes"v-if="pageTitle=='调料校准'">
							<view v-if="item.calibrationDay">
								<view style="color:rgba(238, 10, 36, 1)" v-if="item.calibrationDay>=8">
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											{{item.calibrationDay}}
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view style="font-size: 12px;margin-top: 12upx;">
										待校准
									</view>
								</view>
								<view  style="color:rgba(7, 193, 96, 1)" v-else-if="item.calibrationDay<5">
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											{{item.calibrationDay}}
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view class="" style="font-size: 12px;margin-top: 12upx;">
										已校准
									</view>
								</view>
								<view style="color:rgba(255, 125, 0, 1)" v-else>
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											{{item.calibrationDay}}
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view class="" style="font-size: 12px;margin-top: 12upx;">
										注意校准
									</view>
								</view>
								
							</view>
							<view class="" v-else>
								<view  style="color:rgba(200, 201, 204, 1)" >
									<view class="" v-if="item.calibrationDay==null">
										<view style="height: 68upx;line-height: 68upx;">
											<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
												-
											</text>
											<text style="font-size: 12px;">天</text>
										</view>
										<view class="" style="font-size: 12px;margin-top: 12upx;">
											无数据
										</view>
									</view>
									<view class="" v-else>
										<view style="height: 68upx;line-height: 68upx;">
											<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
												0
											</text>
											<text style="font-size: 12px;">天</text>
										</view>
										<view class="" style="font-size: 12px;margin-top: 12upx;">
											已校准
										</view>
									</view>
								</view>
							</view>
						</view>
						<view class="deviceDes" v-if="pageTitle=='养锅管理'">
							<view class="" v-if="item.maintainDay">
								<view style="color:rgba(255, 125, 0, 1);" v-if="item.maintainDay&&item.maintainDay>1">
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											{{item.maintainDay}}
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view style="font-size: 12px;margin-top: 12upx;">
										注意养锅
									</view>
								</view>
								<view style="color:rgba(7, 193, 96, 1);" v-else-if="item.maintainDay&&item.maintainDay<=1">
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											{{item.maintainDay}}
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view style="font-size: 12px;margin-top: 12upx;">
										已养锅
									</view>
								</view>
							</view>
							<view class="" v-else>
								<view  style="color:rgba(200, 201, 204, 1)" >
								<view class="" v-if="item.maintainDay==null">
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											-
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view class="" style="font-size: 12px;margin-top: 12upx;">
										无数据
									</view>
								</view>
								<view class="" v-else>
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											0
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view class="" style="font-size: 12px;margin-top: 12upx;">
										已养锅
									</view>
								</view>
								</view>
							</view>
						</view>
						<view class="deviceDes" v-if="pageTitle=='料管清洗'">
							<view class="" v-if="item.cleaningDay">
								<view style="color:rgba(255, 125, 0, 1);" v-if="item.cleaningDay&&item.cleaningDay>1">
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											{{item.cleaningDay}}
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view style="font-size: 12px;margin-top: 12upx;">
										注意清洗
									</view>
								</view>
								<view style="color:rgba(7, 193, 96, 1);" v-else-if="item.cleaningDay&&item.cleaningDay<=1">
									<view style="height: 68upx;line-height: 68upx;">
										<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
											{{item.cleaningDay}}
										</text>
										<text style="font-size: 12px;">天</text>
									</view>
									<view style="font-size: 12px;margin-top: 12upx;">
										已清洗
									</view>
								</view>
							</view>
							<view class="" v-else>
								<view  style="color:rgba(200, 201, 204, 1)" >
									<view class="" v-if="item.cleaningDay==null">
										<view style="height: 68upx;line-height: 68upx;">
											<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
												-
											</text>
											<text style="font-size: 12px;">天</text>
										</view>
										<view class="" style="font-size: 12px;margin-top: 12upx;">
											无数据
										</view>
									</view>
									<view class="" v-else>
										<view style="height: 68upx;line-height: 68upx;">
											<text style="margin-right: 26upx;font-size:24px;font-weight: 500;">
												0
											</text>
											<text style="font-size: 12px;">天</text>
										</view>
										<view class="" style="font-size: 12px;margin-top: 12upx;">
											已清洗
										</view>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState('home', ['deviceDetailData']),
		},
		data() {
			return {
				tooltipType: '',
				pageTitle: '',
				org_business_id: '',
				deviceList: [],
				deviceCount: 0,
				page: 1,
				nowTime: '',
				isPlus:false,
				label:'',
			}
		},
		methods: {
			setPageTitle(title) {
				uni.setNavigationBarTitle({
					title: title
				});
			},
			getYearMonthDay(value) {
				const date = new Date(value);
				const year = date.getFullYear()
				const month = date.getMonth() + 1
				const day = date.getDate()
				return this.daysFromDate(year, month, day)
			},
			async getDeviceList(page) {
				uni.showLoading({
					title: '加载中'
				});
				let res
				if (this.label == '商户') {
					res = await this.API.home.getDeviceDetail(this.page, this.org_business_id)
				} else {
					res = await this.API.home.getUserCategoryRank(this.page, this.org_business_id)
				}
				uni.hideLoading();
				if (this.deviceList.length >= this.deviceCount) {
					return
				} else {
					this.deviceList = [...this.deviceList, ...res.data]
					this.deviceList = this.deviceDetailData.data.map((item) => {
						var maintainDay
						var calibrationDay
						var cleaningDay
						if (item.pot_maintain_at) {
							maintainDay = this.getYearMonthDay(item.pot_maintain_at)
							if(this.isPlus){
								maintainDay = maintainDay+1
							}
						}
						if (item.pump_calibration_at) {
							calibrationDay = this.getYearMonthDay(item.pump_calibration_at)
							if(this.isPlus){
								calibrationDay = calibrationDay+1
							}
						}
						if (item.pump_cleaning_at) {
							cleaningDay = this.getYearMonthDay(item.pump_cleaning_at)
							if(this.isPlus){
								cleaningDay = cleaningDay+1
							}
						}
						return {
							...item,
							'maintainDay': maintainDay<0?0:maintainDay,
							'cleaningDay': cleaningDay<0?0:cleaningDay,
							'calibrationDay': calibrationDay<0?0:calibrationDay,
							// 'maintainDay': maintainDay-1,
							// 'cleaningDay': cleaningDay-1,
							// 'calibrationDay': calibrationDay-1,
						}
					})
				}
			},
			lower: function(e) {
				if (this.deviceList.length >= this.deviceCount) {
					return
				} else {
					this.getDeviceList(this.page++)
				}
			},
			getMidnightTimestamp(date) {
			    if (!(date instanceof Date)) {
			        date = new Date(); // 如果没有提供日期，则默认为当前日期
			    }
			    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0).getTime();
			},
			formatDecimal(num, decimal) { //num 传入小数, decimal 保留几位小数
				if(num){
					var _num = num.toString()
					var index = _num.indexOf('.')
				}else{
					return
				}
				if (index !== -1) {
					_num = _num.substring(0, decimal + index + 1)
				} else {
					_num = _num.substring(0)
				}
				return parseFloat(_num).toFixed(decimal)
			},
			daysFromDate(year, month, day) {
				// 将参数转换为毫秒
				const startDate = new Date(year, month - 1, day).getTime();
				const currentDate = new Date().getTime();
				const midnightTimestamp2 = this.getMidnightTimestamp();
				var midnight = new Date();
				midnight.setHours(0, 0, 0, 0); 
				var midnightTimestamp = midnight.getTime();
				var diff = (currentDate - startDate) / (1000 * 60 * 60 * 24);
				if(currentDate>midnightTimestamp){
					this.isPlus=true
					return Math.abs(this.formatDecimal(diff,0))
				}else{
					return Math.abs(this.formatDecimal(diff,0))
				}
				// console.log(startDate,'startDate')
				// console.log(Math.abs(this.formatDecimal(diff,0)),'currentDate - startDate')
				// console.log(midnightTimestamp,'midnightTimestamp')
				// console.log(currentDate,'currentDate')
				// console.log(midnightTimestamp2,'midnightTimestamp2')
				// // 计算两个日期之间的差值，并转换为天数
				// console.log( Math.abs(Math.round(diff)),' Math.abs(Math.round(diff))')
			}

		},
		onLoad(options) {
			this.pageTitle = options.title
			this.org_business_id = options.org_business_id
			this.label = options.label
			console.log(this.label,'this.label')
			this.deviceList = this.deviceDetailData.data.map((item) => {
				var maintainDay
				var calibrationDay
				var cleaningDay
				if (item.pot_maintain_at) {
					maintainDay = this.getYearMonthDay(item.pot_maintain_at)
					if(this.isPlus){
						maintainDay = maintainDay+1
					}
				}
				if (item.pump_calibration_at) {
					calibrationDay = this.getYearMonthDay(item.pump_calibration_at)
					if(this.isPlus){
						calibrationDay = calibrationDay+1
					}
				}
				if (item.pump_cleaning_at) {
					cleaningDay = this.getYearMonthDay(item.pump_cleaning_at)
					if(this.isPlus){
						cleaningDay = cleaningDay+1
					}
				}
				return {
					...item,
					'maintainDay': maintainDay<0?0:maintainDay,
					'cleaningDay': cleaningDay<0?0:cleaningDay,
					'calibrationDay': calibrationDay<0?0:calibrationDay,
				}
			})
			this.deviceCount = this.deviceDetailData.paging.total_records
			console.log(this.deviceList, 'this.deviceList')
			if (options.title == '调料校准') {
				this.tooltipType = '如何精准调味？'
			} else if (options.title == '养锅管理') {
				this.tooltipType = '如何养护设备？'
			} else {
				this.tooltipType = '食品安全维护'
			}
			console.log(this.deviceDetailData, 'this.deviceDetailData')
			console.log(this.nowTime, 'this.nowTime')
			// 页面加载时设置标题
			this.setPageTitle(`${options.title}详情`);
		},
	}
</script>

<style lang="less" scoped>
	.pageBox {
		width: 100%;
		height: 100vh;
		background-color: rgba(245, 245, 245, 1);
		padding: 24upx 16upx;
		box-sizing: border-box;

		.toolTipBox {
			height: 112upx;
			display: flex;
			align-items: center;
			justify-content: center;
			color: rgba(100, 101, 102, 1);
			font-size: 12px;
		}

		.pageTop {
			height: 204upx;
			border-radius: 4px;
			display: flex;
			background-color: rgba(255, 255, 255, 1);

			.topItem {
				width: 240upx;
				text-align: center;
				padding: 8upx;
				box-sizing: border-box;

				.topItemStatus {
					color: rgba(150, 151, 153, 1);
					margin-bottom: 22upx;
				}

				.topItemDays {
					font-size: 24px;
				}

				.topItemDes {
					color: rgba(200, 201, 204, 1);
					font-size: 12px;
					margin-top: 6upx;
				}
			}
		}

		.scroll-Y {
			height: calc(100vh - 112upx - 228upx);
			// flex: 1;

			.deviceList {
				.deviceItem {
					height: 292upx;
					border-radius: 4px;
					background: rgba(255, 255, 255, 1);
					padding: 36upx 28upx;
					box-sizing: border-box;
					display: flex;
					justify-content: space-between;
					margin-bottom: 16upx;

					.deviceItemRight {
						.deviceDays {
							margin-bottom: 22upx;
						}
					}

					.deviceItemLeft {
						.deviceName {
							margin-bottom: 16upx;

							.name {
								font-size: 16px;
								font-weight: 400;
								color: rgba(0, 0, 0, 1);
							}
						}

						.deviceSn {
							font-size: 14px;
							font-weight: 400;
							margin-bottom: 16upx;
							color: rgba(150, 151, 153, 1);
						}
						.storeName{
							font-size: 14px;
							font-weight: 400;
							margin-bottom: 16upx;
							color: rgba(100, 101, 102, 1);
							width: 486upx;
							overflow: hidden;
							text-overflow: ellipsis;
							white-space: nowrap;
						}

						.deviceDes {
							font-size: 14px;
							font-weight: 400;
							margin-bottom: 16upx;
							color: rgba(100, 101, 102, 1);
						}
					}
				}
			}
		}

	}
</style>