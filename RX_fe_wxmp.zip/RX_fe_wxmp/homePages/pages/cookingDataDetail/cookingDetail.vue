<template>
	<view class="pageContainer">
		<view class="timeQueryTab">
			<view :class="{tab:true,activeTab:tabIndex=='2'}" @click="changeTimeTab('2')">日</view>
			<view :class="{tab:true,activeTab:tabIndex=='3'}" @click="changeTimeTab('3')">周</view>
			<view :class="{tab:true,activeTab:tabIndex=='4'}" @click="changeTimeTab('4')">月</view>
			<view :class="{tab:true,activeTab:tabIndex=='5'}" @click="changeTimeTab('5')">年</view>
			<view :class="{tab:true,activeTab:tabIndex=='6'}" @click="chooseDate">自定义</view>
		</view>
		<view class="dateTab" v-if="tabIndex=='2'">
			<view class="preDay" @click="changeDay('pre')">前一天</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{currentDate}}</view>
			<view class="nextDay" @click="changeDay('next')" v-if="currentDate!=today">后一天</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);" v-else>后一天</view>
		</view>
		<view class="dateTab" v-else-if="tabIndex=='3'">
			<view class="preDay" @click="changeWeek('pre')">前一周</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{currentWeekStart}} 至 {{currentWeekEnd}}</view>
			<view class="nextDay" @click="changeWeek('next')" v-if="currentWeekEnd!=today">后一周</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);" v-else>后一周</view>
		</view>
		<view class="dateTab" v-else-if="tabIndex=='4'">
			<view class="preDay" @click="changeMonth('pre')">前一月</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{startMonthDate}} 至 {{endMonthDate}}
			</view>
			<view class="nextDay" @click="changeMonth('next')" v-if="endMonthDate!=today">后一月</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);" v-else>后一月</view>
		</view>
		<view class="dateTab" v-else-if="tabIndex=='5'">
			<view class="preDay" style="color: rgba(150, 151, 153, 1);">前一年</view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">2024-01-01 至 {{currentDate}}</view>
			<view class="nextDay" style="color: rgba(150, 151, 153, 1);">后一年</view>
		</view>
		<view class="dateTab" v-else-if="tabIndex=='6'">
			<view class="preDay"></view>
			<view class="today" style="color: rgba(150, 151, 153, 1);">{{startDate}} 至 {{endDate}}</view>
			<view class="nextDay"></view>
		</view>
		<date-range mode="date" :showMutibleDate="showMutibleDate" :startDate="startDate" :endDate="endDate"
			@onSelected="dateSelected">
		</date-range>
		<view class="pageContent">
			<view class="showData" v-if="pageTitle=='烹饪次数'||pageTitle=='烹饪时长'">
				<view class="dataLeft">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;font-size: 14px;">{{pageTitle}}</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="cookingDetailData.cur">
									<text v-if="pageTitle=='烹饪次数'">{{cookingDetailData.cur.cooked_times}}</text>
									<text
										v-else-if="pageTitle=='烹饪时长'">{{cookingDetailData.cur.last_consumed_minute}}</text>
								</text>
								<text v-else>0.0</text>
							</view>
							<view style="width: 50%;" v-if="pageTitle=='烹饪次数'">
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="cookingDetailData.QOQ.timeData==0.0">{{cookingDetailData.QOQ.timeData}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="cookingDetailData.QOQ.timeData>0.0">{{cookingDetailData.QOQ.timeData}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="cookingDetailData.QOQ.timeData<0.0">{{cookingDetailData.QOQ.timeData}}%</text>
							</view>
							<view style="width: 50%;" v-else-if="pageTitle=='烹饪时长'">
								<text style="color: rgba(150, 151, 153, 1);"
									v-if="cookingDetailData.QOQ.minuteData==0.0">{{cookingDetailData.QOQ.minuteData}}%</text>
								<text style="color: rgba(255, 125, 0, 1);"
									v-if="cookingDetailData.QOQ.minuteData>0.0">{{cookingDetailData.QOQ.minuteData}}%</text>
								<text style="color: rgba(0, 180, 42, 1);"
									v-if="cookingDetailData.QOQ.minuteData<0.0">{{cookingDetailData.QOQ.minuteData}}%</text>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
							<view style="width: 50%;">
								<text v-if="pageTitle=='烹饪次数'">{{cookingDetailData.cur.cooked_times_unit}}</text>
								<text
									v-else-if="pageTitle=='烹饪时长'">{{cookingDetailData.cur.consumed_minute_unit?cookingDetailData.cur.consumed_minute_unit:'分钟'}}</text>
							</view>
							<view style="width: 50%;">
								<text v-if="tabIndex=='2'">比昨日</text>
								<text v-else-if="tabIndex=='3'">比上周</text>
								<text v-else-if="tabIndex=='4'">比上月</text>
								<text v-else-if="tabIndex=='5'">比去年</text>
								<text class="" v-if="pageTitle=='烹饪次数'">
									<text v-if="cookingDetailData.QOQ.timeData>0.0">上升</text>
									<text v-else-if="cookingDetailData.QOQ.timeData<0.0">下降</text>
									<text v-else>持平</text>
								</text>
								<text class="" v-else-if="pageTitle=='烹饪时长'">
									<text v-if="cookingDetailData.QOQ.minuteData>0.0">上升</text>
									<text v-else-if="cookingDetailData.QOQ.minuteData<0.0">下降</text>
									<text v-else>持平</text>
								</text>
							</view>
						</view>
					</view>
				</view>
				<view class="dataRight">
					<view class="">
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;font-size: 14px;" v-if="pageTitle=='烹饪次数'">烹饪重量
						</view>
						<view style="color: rgba(150, 151, 153, 1);margin-bottom: 16upx;font-size: 14px;" v-else-if="pageTitle=='烹饪时长'">
							开机时长</view>
						<view style="margin-bottom: 16upx;display: flex;align-items: center;">
							<view style="color: rgba(0, 0, 0, 1);font-size: 24px;width: 50%;">
								<text v-if="cookingDetailData.cur">
									<text v-if="pageTitle=='烹饪次数'">{{cookingDetailData.cur.last_spec_summed}}</text>
									<text
										v-else-if="pageTitle=='烹饪时长'">
										<text v-if="cookingDetailData.cur.last_running_mins_total">{{cookingDetailData.cur.last_running_mins_total}}</text>
										<text v-else>0.0</text>
									</text>
								</text>
								<text v-else>0.0</text>
							</view>
							<view style="width: 50%;">
								<view style="width: 50%;" v-if="pageTitle=='烹饪次数'">
									<text style="color: rgba(150, 151, 153, 1);"
										v-if="cookingDetailData.QOQ.specSummedData==0.0">{{cookingDetailData.QOQ.specSummedData}}%</text>
									<text style="color: rgba(255, 125, 0, 1);"
										v-if="cookingDetailData.QOQ.specSummedData>0.0">{{cookingDetailData.QOQ.specSummedData}}%</text>
									<text style="color: rgba(0, 180, 42, 1);"
										v-if="cookingDetailData.QOQ.specSummedData<0.0">{{cookingDetailData.QOQ.specSummedData}}%</text>
								</view>
								<view style="width: 50%;" v-else-if="pageTitle=='烹饪时长'">
									<text style="color: rgba(150, 151, 153, 1);"
										v-if="cookingDetailData.QOQ.runData==0.0">{{cookingDetailData.QOQ.runData}}%</text>
									<text style="color: rgba(255, 125, 0, 1);"
										v-if="cookingDetailData.QOQ.runData>0.0">{{cookingDetailData.QOQ.runData}}%</text>
									<text style="color: rgba(0, 180, 42, 1);"
										v-if="cookingDetailData.QOQ.runData<0.0">{{cookingDetailData.QOQ.runData}}%</text>
								</view>
							</view>
						</view>
						<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
							<view style="width: 50%;">
								<text v-if="pageTitle=='烹饪次数'">{{cookingDetailData.cur.unit?cookingDetailData.cur.unit:'克'}}</text>
								<text
									v-else-if="pageTitle=='烹饪时长'">{{cookingDetailData.cur.running_mins_total_unit?cookingDetailData.cur.running_mins_total_unit:'分钟'}}</text>
							</view>
							<view style="width: 50%;">
								<text v-if="tabIndex=='2'">比昨日</text>
								<text v-else-if="tabIndex=='3'">比上周</text>
								<text v-else-if="tabIndex=='4'">比上月</text>
								<text v-else-if="tabIndex=='5'">比去年</text>
								<text class="" v-if="pageTitle=='烹饪次数'">
									<text v-if="cookingDetailData.QOQ.specSummedData>0.0">上升</text>
									<text v-else-if="cookingDetailData.QOQ.specSummedData<0.0">下降</text>
									<text v-else>持平</text>
								</text>
								<text class="" v-else-if="pageTitle=='烹饪时长'">
									<text v-if="cookingDetailData.QOQ.runData>0.0">上升</text>
									<text v-else-if="cookingDetailData.QOQ.runData<0.0">下降</text>
									<text v-else>持平</text>
								</text>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="showEnergyData" v-else>
				<view style="text-align: center;color:rgba(150, 151, 153, 1);padding-top: 8px;font-size:14px">能耗电量</view>
				<view style="display: flex;justify-content: center;margin-top: 28upx;align-items: flex-end;">
					<view style="margin-right: 80upx;">
						<text style="font-size: 24px;color: rgba(0, 0, 0, 1);">{{cookingDetailData.cur.last_consumed_energy?cookingDetailData.cur.last_consumed_energy:'0'}}</text>
						<text style="color: rgba(150, 151, 153, 1);font-size: 12px;margin-left: 26upx;">{{cookingDetailData.cur.last_consumed_energy_unit?cookingDetailData.cur.last_consumed_energy_unit:'度'}}</text>
					</view>
					<view class="">
						<view>
							<text style="color: rgba(150, 151, 153, 1);"
								v-if="cookingDetailData.QOQ.energyData==0.0">{{cookingDetailData.QOQ.energyData}}%</text>
							<text style="color: rgba(255, 125, 0, 1);"
								v-if="cookingDetailData.QOQ.energyData>0.0">{{cookingDetailData.QOQ.energyData}}%</text>
							<text style="color: rgba(0, 180, 42, 1);"
								v-if="cookingDetailData.QOQ.energyData<0.0">{{cookingDetailData.QOQ.energyData}}%</text>
						</view>
						<view style="color: rgba(200, 201, 204, 1);font-size:12px;">
							<text v-if="tabIndex=='2'">比昨日</text>
							<text v-else-if="tabIndex=='3'">比上周</text>
							<text v-else-if="tabIndex=='4'">比上月</text>
							<text v-else-if="tabIndex=='5'">比去年</text>
							<text v-if="cookingDetailData.QOQ.energyData>0.0">上升</text>
							<text v-else-if="cookingDetailData.QOQ.energyData<0.0">下降</text>
							<text v-else>持平</text>
						</view>
					</view>
				</view>
			</view>
			<view v-if="chartDataList.length" class="charts-box"
				style="height: 250px;background-color: rgba(255, 255, 255, 1);border-top: 2px solid #F1F1F1;">
				<qiun-data-charts v-if="chartDataList.length" type="rose" :opts="opts" :chartData="chartData" canvas2d="false"/>
			</view>
			<view v-else class=""
				style="background-color: #fff;border-radius:4px;text-align: center;">
				<image style="height: 200upx;width: 292upx;margin-top: 20upx;"
					src="../../../static/image/dataEmpty.png" mode=""></image>
				<view class="" style="color:rgba(200, 201, 204, 1);padding: 20upx 0;">
					暂无数据
				</view>
			</view>
			<view class="deviceListTitle" v-if="deviceList.length">
				{{pageTitle}}详情
				<text style="margin-left: 24upx;" v-if="deviceList.length">{{deviceList.length}}台</text>
				<text style="margin-left: 24upx;" v-else>0台</text>
			</view>
			<view class="deviceListContent" v-if="deviceList.length">
				<view class="deviceItem" v-for="item in deviceList" :key="item.device_code">
					<view class="deviceItemTop">
						<view class="deviceName">
							<img style="height:11px;width:12px;margin-right: 16upx;"
								src="/static/image/deviceDetailLogo.png" alt="" />
							<text class="name">{{item.device_name}}</text>
							<text v-if="item.status=='已撤机'" style="display: inline-block;width: 40px;height: 18px;font-size: 11px;text-align: center;line-height: 18px;color: rgba(255, 125, 0, 1);background-color: rgba(255, 247, 232, 1);margin-left: 10px;">{{item.status}}</text>
						</view>
						<view class="deviceSn" v-if="item.end_at">撤机时间：{{item.end_at.replace('T', ' ')}}</view>
						<view class="deviceSn">SN：{{item.device_code}}</view>
						<view class="storeSn">门店：{{item.store_name}}</view>
					</view>
					<view class="showData" v-if="pageTitle=='烹饪次数'||pageTitle=='烹饪时长'">
						<view class="dataLeft">
							<view class="">
								<view style="color: rgba(150, 151, 153, 1);margin-bottom: 12upx;">{{pageTitle}}</view>
								<view style="margin-bottom: 12upx;display: flex;align-items: center;">
									<view style="color: rgba(0, 0, 0, 1);font-size: 24px;margin-right: 30upx;">
										<text v-if="Number(item.leftData)">{{item.leftData}}</text>
										<text v-else>0</text>
									</view>
									<view style="width: 50%;" v-if="pageTitle=='烹饪次数'">
										<text style="color: rgba(150, 151, 153, 1);"
											v-if="item.cooked_times_QoQ==0.0">{{item.cooked_times_QoQ}}%</text>
										<text style="color: rgba(255, 125, 0, 1);"
											v-if="item.cooked_times_QoQ>0.0">{{item.cooked_times_QoQ}}%</text>
										<text style="color: rgba(0, 180, 42, 1);"
											v-if="item.cooked_times_QoQ<0.0">{{item.cooked_times_QoQ}}%</text>
									</view>
									<view style="width: 50%;" v-else-if="pageTitle=='烹饪时长'">
										<text style="color: rgba(150, 151, 153, 1);"
											v-if="item.consumed_minute_QoQ==0.0">{{item.consumed_minute_QoQ}}%</text>
										<text style="color: rgba(255, 125, 0, 1);"
											v-if="item.consumed_minute_QoQ>0.0">{{item.consumed_minute_QoQ}}%</text>
										<text style="color: rgba(0, 180, 42, 1);"
											v-if="item.consumed_minute_QoQ<0.0">{{item.consumed_minute_QoQ}}%</text>
									</view>
								</view>
								<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
									<view>
										<text>{{item.leftUnit}}</text>
										
									</view>
								</view>
							</view>
						</view>
						<view class="dataRight">
							<view class="">
								<view style="color: rgba(150, 151, 153, 1);margin-bottom: 12upx;" v-if="pageTitle=='烹饪次数'">烹饪重量
								</view>
								<view style="color: rgba(150, 151, 153, 1);margin-bottom: 12upx;" v-else-if="pageTitle=='烹饪时长'">
									开机时长</view>
								<view style="margin-bottom: 12upx;display: flex;align-items: center;">
									<view style="color: rgba(0, 0, 0, 1);font-size: 24px;margin-right: 30upx;">
										<text v-if="Number(item.rightData)">{{item.rightData}}</text>
										<text v-else-if="item.rightData==null">0.0</text>
										<text v-else>0.0</text>
									</view>
									<view style="width: 50%;">
										<view style="width: 50%;" v-if="pageTitle=='烹饪次数'">
											<text style="color: rgba(150, 151, 153, 1);"
												v-if="item.spec_summed_QoQ==0.0">{{item.spec_summed_QoQ}}%</text>
											<text style="color: rgba(255, 125, 0, 1);"
												v-if="item.spec_summed_QoQ>0.0">{{item.spec_summed_QoQ}}%</text>
											<text style="color: rgba(0, 180, 42, 1);"
												v-if="item.spec_summed_QoQ<0.0">{{item.spec_summed_QoQ}}%</text>
										</view>
										<view style="width: 50%;" v-else-if="pageTitle=='烹饪时长'">
											<text style="color: rgba(150, 151, 153, 1);"
												v-if="item.running_mins_total_QoQ==0.0">{{item.running_mins_total_QoQ}}%</text>
											<text style="color: rgba(255, 125, 0, 1);"
												v-if="item.running_mins_total_QoQ>0.0">{{item.running_mins_total_QoQ}}%</text>
											<text style="color: rgba(0, 180, 42, 1);"
												v-if="item.running_mins_total_QoQ<0.0">{{item.running_mins_total_QoQ}}%</text>
										</view>
									</view>
								</view>
								<view style="color: rgba(150, 151, 153, 1);font-size: 12px;display: flex;align-items: center;">
									<view>
										<text>{{item.rightUnit}}</text>
									</view>
								</view>
							</view>
						</view>
					</view>
					<view class="showEnergyData" v-else>
						<view style="text-align: center;color:rgba(150, 151, 153, 1);padding-top: 8px;font-size:14px">能耗电量</view>
						<view style="display: flex;justify-content: center;margin-top: 28upx;align-items:flex-end;">
							<view style="margin-right: 80upx;">
								<text style="font-size: 24px;color: rgba(0, 0, 0, 1);">{{item.consumed_energy}}</text>
								<text style="color: rgba(150, 151, 153, 1);font-size: 12px;margin-left: 26upx;">度</text>
							</view>
							<view class="">
								<view>
									<text style="color: rgba(150, 151, 153, 1);"
										v-if="item.consumed_energy_QoQ==0.0">{{item.consumed_energy_QoQ}}%</text>
									<text style="color: rgba(255, 125, 0, 1);"
										v-if="item.consumed_energy_QoQ>0.0">{{item.consumed_energy_QoQ}}%</text>
									<text style="color: rgba(0, 180, 42, 1);"
										v-if="item.consumed_energy_QoQ<0.0">{{item.consumed_energy_QoQ}}%</text>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="" v-else style="text-align: center;margin-top: 100upx;">
				<image style="width: 298upx;height: 250upx;" src="../../../static/image/menuEmpty.png" mode=""></image>
				<view style="font-size: 12px;color: rgba(166, 166, 166, 1);margin-top: 48upx;">暂无数据</view>
				<button @click="toUpdate" style="background-color: rgba(22, 93, 255, 1);color: rgba(255, 255, 255, 1);width: 184upx;height: 72upx;border-radius: 4px;line-height: 72upx;text-align: center;margin-top: 54upx;">刷新</button>
			</view>
		</view>

	</view>
</template>

<script>
	import moment from "moment"
	import dateRange from '@/homePages/components/zxp-datepickerRange/zxp-datepickerRange.vue'
	export default {
		components: {
			dateRange
		},
		data() {
			return {
				currentMonth: new Date(), // 当前日期
				startMonthDate: '', // 开始日期
				endMonthDate: '' ,// 结束日期
				pageTitle: '',
				tabIndex: '2',
				org_business_id: '',
				label: '',
				showMutibleDate: false,
				chartToTop: this.$chartToTop,
				endDate: moment().format('YYYY-MM-DD'), // 默认结束时间 YYYY/MM/DD
				startDate: moment().format('YYYY-MM-DD'), // 默认开始时间 YYYY/MM/DD
				currentDate: '', //当前日期
				today: '', //当前日期
				nowDate: "", //当前日期
				// 本周的开始时间
				currentWeekStart: '',
				currentWeekEnd: '',
				currentMonthStart: '',
				currentMonthEnd: '',
				cookingDetailData: [],
				deviceList:[],
				chartData: {},
				chartDataList: [], //图表值
				opts: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [16, 16, 16, 16],
					enableScroll: false,
					legend: {
						show: false,
						position: "left",
						lineHeight: 25
					},
					extra: {
						rose: {
							type: "area",
							minRadius: 80,
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: false,
							borderWidth: 2,
							borderColor: "#FFFFFF"
						}
					}

				}
			}
		},
		methods: {
			// 更改页面标题
			setPageTitle(title) {
				uni.setNavigationBarTitle({
					title: title
				});
			},
			// 处理小数取值
			formatDecimal(num, decimal) { //num 传入小数, decimal 保留几位小数
				if(num){
					var _num = num.toString()
					var index = _num.indexOf('.')
				}else{
					return
				}
				if (index !== -1) {
					_num = _num.substring(0, decimal + index + 1)
				} else {
					_num = _num.substring(0)
				}
				return parseFloat(_num).toFixed(decimal)
			},
			async getData(date, page, data) {
				uni.showLoading({
					title: '加载中'
				})
				let res
				let minuteData
				let timeData
				let runData
				let energyData
				let specSummedData
				if (this.label == '商户') {
					res = await this.API.home.getUserSummary(this.org_business_id, this.tabIndex, date, data,
						page)
					this.chartDataList = res.data.stores
				} else {
					res = await this.API.home.getStoreSummary(this.org_business_id, this.tabIndex, date, data,
						page)
					this.chartDataList = res.data.devices
				}
				
				uni.hideLoading()
				if (res.code == 200) {
					this.cookingDetailData = res.data
				
					if(this.cookingDetailData.cur.cooked_times>10000){
						this.cookingDetailData.cur.cooked_times=this.formatDecimal(this.cookingDetailData.cur.cooked_times /10000,1)
						this.cookingDetailData.cur.cooked_times_unit = '万次'
					}else{
						this.cookingDetailData.cur.cooked_times_unit = '次'
					}
					if (this.cookingDetailData.cur) {
						if (this.cookingDetailData.cur.spec_summed < 1000) {
							this.cookingDetailData.cur.last_spec_summed = this.formatDecimal(this.cookingDetailData
								.cur.spec_summed,
								1)
							this.cookingDetailData.cur.unit = '克'
						} else {
							this.cookingDetailData.cur.last_spec_summed = this.formatDecimal(this.cookingDetailData
								.cur.spec_summed /
								1000,
								1)
							this.cookingDetailData.cur.unit = '千克'
							if(this.cookingDetailData.cur.last_spec_summed>10000){
								this.cookingDetailData.cur.last_spec_summed=this.formatDecimal(this.cookingDetailData.cur.last_spec_summed /10000,1)
								this.cookingDetailData.cur.unit = '万千克'
							}
						}
						if (this.cookingDetailData.cur.consumed_minute < 60) {
							this.cookingDetailData.cur.last_consumed_minute = this.formatDecimal(this
								.cookingDetailData.cur.consumed_minute,
								1)
							this.cookingDetailData.cur.consumed_minute_unit = '分钟'
						} else {
							this.cookingDetailData.cur.last_consumed_minute = this.formatDecimal(this
								.cookingDetailData.cur.consumed_minute /
								60,
								1)
							this.cookingDetailData.cur.consumed_minute_unit = '时'
							if(this.cookingDetailData.cur.last_consumed_minute>10000){
								this.cookingDetailData.cur.last_consumed_minute=this.formatDecimal(this.cookingDetailData.cur.last_consumed_minute /10000,1)
								this.cookingDetailData.cur.consumed_minute_unit = '万小时'
							}
						}
						if(this.cookingDetailData.cur.consumed_energy>10000){
							this.cookingDetailData.cur.last_consumed_energy=this.formatDecimal(this.cookingDetailData.cur.last_consumed_energy /10000,1)
							this.cookingDetailData.cur.last_consumed_energy_unit = '万度'
						}else{
							this.cookingDetailData.cur.last_consumed_energy = this.formatDecimal(this.cookingDetailData
								.cur.consumed_energy,
								1)
							this.cookingDetailData.cur.last_consumed_energy_unit = '度'
						}
						if(this.cookingDetailData.cur.running_mins_total){
							if (this.cookingDetailData.cur.running_mins_total < 60) {
								this.cookingDetailData.cur.last_running_mins_total = this.formatDecimal(this
									.cookingDetailData.cur.running_mins_total,
									1)
								this.cookingDetailData.cur.running_mins_total_unit = '分钟'
							} else {
								this.cookingDetailData.cur.last_running_mins_total = this.formatDecimal(this.cookingDetailData.cur.running_mins_total /60,1)
								this.cookingDetailData.cur.running_mins_total_unit = '时'
								if(this.cookingDetailData.cur.last_running_mins_total>10000){
									this.cookingDetailData.cur.last_running_mins_total=this.formatDecimal(this.cookingDetailData.cur.last_running_mins_total /10000,1)
									this.cookingDetailData.cur.running_mins_total_unit = '万小时'
								}
							}
						}else{
							this.cookingDetailData.cur.running_mins_total_unit = '分钟'
							this.cookingDetailData.cur.last_running_mins_total=0
							this.cookingDetailData.cur.running_mins_total=0
						}
						
					}
					if (res.per != null && res.per.cooked_times != 0) {
						timeData = ((res.cur.cooked_times - res.per.cooked_times) / res.per.cooked_times) * 100
						timeData = this.formatDecimal(timeData, 1)
					} else {
						timeData = '0.0'
					}
					if (res.per != null && res.per.consumed_minute != 0) {
						minuteData = ((res.cur.consumed_minute - res.per.consumed_minute) / res.per
							.consumed_minute) * 100
						minuteData = this.formatDecimal(minuteData, 1)
					} else {
						minuteData = '0.0'
					}
					if (res.per != null && res.per.running_mins_total != 0) {
						runData = ((res.cur.running_mins_total - res.per.running_mins_total) / res.per
							.running_mins_total) * 100
						runData = this.formatDecimal(runData, 1)
					} else {
						runData = '0.0'
					}
					if (res.per != null && res.per.consumed_energy != 0) {
						energyData = ((res.cur.consumed_energy - res.per.consumed_energy) / res.per
							.consumed_energy) * 100
						energyData = this.formatDecimal(energyData, 1)
					} else {
						energyData = '0.0'
					}
					if (res.per != null && res.per.spec_summed != 0) {
						specSummedData = ((res.cur.spec_summed - res.per.spec_summed) / res.per.spec_summed) *
							100
						specSummedData = this.formatDecimal(specSummedData, 1)
					} else {
						specSummedData = '0.0'
					}
					this.cookingDetailData.QOQ = {
						'timeData': timeData,
						'minuteData': minuteData,
						'runData': runData,
						'energyData': energyData,
						'specSummedData': specSummedData
					}
				}
				// 处理饼图数据
				if (this.chartDataList.length) {
					if (this.label == '商户') {
						if (this.pageTitle == '烹饪次数') {
							this.chartDataList = this.chartDataList.map((item) => {
								return {
									'name': item.store_name,
									'value': item.cooked_times
								}
							})
						} else if (this.pageTitle == '烹饪时长') {
							this.chartDataList = this.chartDataList.map((item) => {
								return {
									'name': item.store_name,
									'value': item.consumed_minute ? this.formatDecimal(item.consumed_minute,
										1) : 0
								}
							})
						} else {
							this.chartDataList = this.chartDataList.map((item) => {
								return {
									'name': item.store_name,
									'value': item.consumed_energy ? this.formatDecimal(item.consumed_energy,
										1) : 0
								}
							})
						}
					} else {
						if (this.pageTitle == '烹饪次数') {
							this.chartDataList = this.chartDataList.map((item) => {
								return {
									'name': item.device_code,
									'value': item.cooked_times
								}
							})
						} else if (this.pageTitle == '烹饪时长') {
							this.chartDataList = this.chartDataList.map((item) => {
								return {
									'name': item.device_code,
									'value': item.consumed_minute ? this.formatDecimal(item.consumed_minute,
										1) : 0
								}
							})
						} else {
							this.chartDataList = this.chartDataList.map((item) => {
								return {
									'name': item.device_code,
									'value': item.consumed_energy ? this.formatDecimal(item.consumed_energy,
										1) : 0
								}
							})
						}
					}
					this.showChartData()
				}
			},
			mergeObjects(arr1, arr2){
			  return arr1.reduce((acc, obj) => {
			    const matchingObj = arr2.find(o => o.device_code === obj.device_code);
			    if (matchingObj) {
			      // 合并对象，arr2中的对象优先
			      const mergedObj = { ...matchingObj, ...obj };
			      acc.push(mergedObj);
			    } else {
			      acc.push(obj);
			    }
			    return acc;
			  }, []);
			},
			//获取设备详情
			async getDeviceData(date, page, data){
				let res
				let arr 
				let cur_arr
				uni.showLoading({
					title: '加载中'
				})
				if (this.label == '商户') {
					res = await this.API.home.getUserTimeDevice(this.org_business_id, this.tabIndex, date, data,page)
				} else {
					res = await this.API.home.getStoreTimeDevice(this.org_business_id, this.tabIndex, date, data,page)
				}
				uni.hideLoading()
				cur_arr=res.data.cur_devices
				arr=res.data.pre_devices.map((item)=>{
					return { 
							pre_consumed_energy:item.consumed_energy,
							pre_consumed_minute:item.consumed_minute,
							pre_cooked_times:item.cooked_times,
							pre_running_mins_total:item.running_mins_total,
							pre_spec_summed:item.spec_summed,
							device_code:item.device_code
					}
				})
				this.deviceList=this.mergeObjects(cur_arr,arr)
				this.deviceList=this.deviceList.map((item)=>{
					if(item.cooked_times>10000){
						item.last_cooked_times=this.formatDecimal(item.cooked_times /10000,1)
						item.cooked_times_unit = '万次'
					}else{
						item.last_cooked_times=item.cooked_times
						item.cooked_times_unit = '次'
					}
					if (Number(item.consumed_minute) < 60) {
						item.last_consumed_minute = this.formatDecimal(item.consumed_minute,1)
						item.consumed_minute_unit = '分钟'
					} else {
						if(Number(item.consumed_minute/60) >10000){
							item.last_consumed_minute = this.formatDecimal(item.consumed_minute /60/10000,1)
							item.consumed_minute_unit = '万小时'
						}else{
							item.last_consumed_minute = this.formatDecimal(item.consumed_minute /60,1)
							item.consumed_minute_unit = '时'
						}
					}
					
					if (Number(item.running_mins_total) < 60) {
						item.last_running_mins_total = this.formatDecimal(item.running_mins_total,1)
						item.last_running_mins_total_unit = '分钟'
					} else {
						if(Number(item.consumed_minute/60) >10000){
							item.last_running_mins_total = this.formatDecimal(item.running_mins_total /60/10000,1)
							item.last_running_mins_total_unit = '万小时'
						}else{
							item.last_running_mins_total = this.formatDecimal(item.running_mins_total /60,1)
							item.last_running_mins_total_unit = '时'
						}
					}
					if (Number(item.spec_summed) < 1000) {
						item.last_spec_summed = this.formatDecimal(item.spec_summed,1)
						item.last_spec_summed_unit = '克'
					} else {
						if(Number(item.spec_summed/1000) >10000){
							item.last_spec_summed = this.formatDecimal(item.spec_summed /1000/10000,1)
							item.last_spec_summed_unit = '万千克'
						}else{
							item.last_spec_summed = this.formatDecimal(item.spec_summed /1000,1)
							item.last_spec_summed_unit = '千克'
						}
						
					}
					return{
						...item,
						'leftData':this.pageTitle=='烹饪次数'?item.last_cooked_times:this.formatDecimal(item.last_consumed_minute,1),
						'rightData':this.pageTitle=='烹饪次数'?this.formatDecimal(Number(item.last_spec_summed),1):this.formatDecimal(item.last_running_mins_total,1),
						'rightUnit':this.pageTitle=='烹饪次数'?item.last_spec_summed_unit:item.last_running_mins_total_unit,
						'leftUnit':this.pageTitle=='烹饪次数'?item.cooked_times_unit:item.consumed_minute_unit,
						'consumed_energy':this.formatDecimal(item.consumed_energy,1)
					}
				})
				this.deviceList=this.deviceList.map((item)=>{
					let consumed_energy_QoQ
					let consumed_minute_QoQ
					let cooked_times_QoQ
					let running_mins_total_QoQ
					let spec_summed_QoQ
					if (item.pre_spec_summed != 0 || item.pre_spec_summed != 0.0000) {
						spec_summed_QoQ = ((item.spec_summed - item.pre_spec_summed) / item.pre_spec_summed) * 100
						spec_summed_QoQ = this.formatDecimal(spec_summed_QoQ, 1)
					} else {
						spec_summed_QoQ = '0.0'
					}
					if (item.pre_running_mins_total != 0 || item.pre_running_mins_total != 0.0000) {
						running_mins_total_QoQ = ((item.running_mins_total - item.pre_running_mins_total) / item.pre_running_mins_total) * 100
						running_mins_total_QoQ = this.formatDecimal(running_mins_total_QoQ, 1)
					} else {
						running_mins_total_QoQ = '0.0'
					}
					if (item.pre_consumed_energy != 0 || item.pre_consumed_energy != 0.0000) {
						consumed_energy_QoQ = ((item.consumed_energy - item.pre_consumed_energy) / item.pre_consumed_energy) * 100
						consumed_energy_QoQ = this.formatDecimal(consumed_energy_QoQ, 1)
					} else {
						consumed_energy_QoQ = '0.0'
					}
					if (item.pre_consumed_minute != 0 || item.pre_consumed_minute != 0.0000) {
						consumed_minute_QoQ = ((item.consumed_minute - item.pre_consumed_minute) / item.pre_consumed_minute) * 100
						consumed_minute_QoQ = this.formatDecimal(consumed_minute_QoQ, 1)
					} else {
						consumed_minute_QoQ = '0.0'
					}
					if (item.pre_cooked_times != 0 || item.pre_cooked_times!= 0.0000) {
						cooked_times_QoQ = ((item.cooked_times - item.pre_cooked_times) / item.pre_cooked_times) * 100
						cooked_times_QoQ = this.formatDecimal(cooked_times_QoQ, 1)
					} else {
						cooked_times_QoQ = '0.0'
					}
					return {
						...item,
						cooked_times_QoQ: cooked_times_QoQ?cooked_times_QoQ:'0.0',
						consumed_minute_QoQ: consumed_minute_QoQ?consumed_minute_QoQ:'0.0',
						consumed_energy_QoQ: consumed_energy_QoQ?consumed_energy_QoQ:'0.0',
						running_mins_total_QoQ: running_mins_total_QoQ?running_mins_total_QoQ:'0.0',
						spec_summed_QoQ: spec_summed_QoQ?spec_summed_QoQ:'0.0'
					}
				})
			},
			changeTimeTab(timeSpanInt) {
				this.tabIndex = timeSpanInt
				this.currentDate = new Date().toISOString().slice(0, 10)
				this.today = new Date().toISOString().slice(0, 10)
				this.nowDate = new Date();
				if (timeSpanInt == '5') {
					this.getData(this.currentDate, this.page)
					this.getDeviceData(this.currentDate, this.page)
				} else if (timeSpanInt == '4') {
					var monthDate = this.getMonthRange(new Date(this.currentDate))
					// console.log(1, monthDate);
					this.currentMonthStart = moment(monthDate.start).format('YYYY-MM-DD')
					// console.log(2, this.currentMonthStart);
					if (new Date(monthDate.end).getTime() > new Date(this.currentDate).getTime()) {
						this.currentMonthEnd = this.currentDate
					} else {
						this.currentMonthEnd = monthDate.end
					}
					// console.log(3, this.currentMonthEnd);
					this.updateDateRange();
					// this.getData(this.currentMonthStart, this.page)
					// this.getDeviceData(this.currentMonthStart, this.page)
				} else if (timeSpanInt == '3') {
					this.getTimeandWeek()
					this.getData(this.currentWeekStart, this.page)
					this.getDeviceData(this.currentWeekStart, this.page)
				} else{
					this.getData(this.currentDate, this.page)
					this.getDeviceData(this.currentDate, this.page)
				} 
				console.log(`timeSpanInt:${timeSpanInt}, d:${this.currentDate},page:${this.page}`)
				
			},
			// 选择自定义时间
			chooseDate() {
				this.showMutibleDate = !this.showMutibleDate
				this.tabIndex = '6'
			},
			// 自定义选择时间
			dateSelected(e) {
				if (e) {
					let start = e.start
					let end = e.end
					this.startDate = moment(start).format('YYYY-MM-DD');
					this.endDate = moment(end).format('YYYY-MM-DD');
				}
				this.getDeviceData(this.startDate, this.page,{
					begin_date: this.startDate,
					end_date: this.endDate
				})
				this.getData(this.startDate, this.page,{
					begin_date: this.startDate,
					end_date: this.endDate
				})
				this.showMutibleDate = false
			},
			// 获取本月的第一天
			getMonthRange(today) {
				const year = today.getFullYear();
				const month = today.getMonth();
				const day = today.getDate();
				const startDate = new Date(year, month, 2); // 本月的第一天
				const endDate = new Date(year, month + 1, 0); // 本月的最后一天
				return {
					start: startDate.toISOString().split('T')[0],
					end: endDate.toISOString().split('T')[0],
				};
			},
			getTimeandWeek() {
				var weekDay = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期天'];
				var now = new Date();
				// 获取本周的第一天（星期一）
				var firstDay = new Date(now.setDate(now.getDate() - now.getDay() + (now.getDay() === 0 ? -6 : 1)));
				// 存储本周的日期
				var weekDates = [];
				// 循环获取本周的所有日期
				for (var i = 0; i < 7; i++) {
					var tempDate = new Date(firstDay);
					tempDate.setDate(firstDay.getDate() + i);
					var year = tempDate.getFullYear();
					var month = tempDate.getMonth() + 1;
					var day = tempDate.getDate();
					weekDates.push({
						week: weekDay[i],
						date: year + '-' + (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') +
							day
					});
				}
				this.currentWeekStart = weekDates[0].date
				var weekDateEnd = weekDates[6].date
				if (new Date(weekDateEnd).getTime() > new Date(this.currentDate).getTime()) {
					this.currentWeekEnd = this.currentDate
				} else {
					this.currentWeekEnd = weekDates[6].date
				}
			},
			// 格式化日期为YYYY-MM-DD
			formatDate(date) {
				let year = date.getFullYear();
				let month = (date.getMonth() + 1).toString().padStart(2, '0');
				let day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			// 获取前一天后一天
			changeDay(value) {
				var currentDay = new Date(this.currentDate)
				if (value == 'pre') {
					let yesterday = new Date(currentDay);
					yesterday.setDate(yesterday.getDate() - 1);
					this.currentDate = this.formatDate(yesterday)
				} else {
					if (this.currentDate == this.today) return
					let tomorrow = new Date(this.currentDate);
					tomorrow.setDate(tomorrow.getDate() + 1);
					this.currentDate = this.formatDate(tomorrow)
				}
				this.getData(this.currentDate, this.page)
				this.getDeviceData(this.currentDate, this.page)
			},
			// 获取上一周的日期范围
			getLastWeekRange() {
				const today = new Date(this.currentWeekStart);
				const lastWeekStart = new Date(today);
				lastWeekStart.setDate(today.getDate() - 7);
				const lastWeekEnd = new Date(today);
				lastWeekEnd.setDate(today.getDate() - 1);
				return {
					start: lastWeekStart,
					end: lastWeekEnd
				};
			},
			// 获取下一周的日期范围
			getNextWeekRange() {
				const today = new Date(this.currentWeekStart);
				const nextWeekStart = new Date(today);
				nextWeekStart.setDate(today.getDate() + 7);
				const nextWeekEnd = new Date(today);
				nextWeekEnd.setDate(today.getDate() + 13);
				return {
					start: nextWeekStart,
					end: nextWeekEnd
				};
			},
			getFullDate(targetDate) {
				var D, y, m, d;
				if (targetDate) {
					D = new Date(targetDate);
					y = D.getFullYear();
					m = D.getMonth() + 1;
					d = D.getDate();
				} else {
					y = fullYear;
					m = month;
					d = date;
				}
				m = m > 9 ? m : '0' + m;
				d = d > 9 ? d : '0' + d;
				return y + '-' + m + '-' + d;
			},

			// 获取上个月、下个月
			last() {
				this.nowDate.setMonth(this.nowDate.getMonth() - 1);
				this.startDate = this.nowDate.getFullYear() + "-" + (this.nowDate.getMonth() + 1) + "-" + this
					.nowDate
					.getDate()
				this.endDate = this.getFullDate(new Date(this.nowDate.getFullYear(), this.nowDate.getMonth() + 1,
					0))
			},
			next() {
				this.nowDate.setMonth(this.nowDate.getMonth() + 1);
				this.startDate = this.nowDate.getFullYear() + "-" + (this.nowDate.getMonth() + 1) + "-" + this
					.nowDate
					.getDate()
				this.endDate = this.getFullDate(new Date(this.nowDate.getFullYear(), this.nowDate.getMonth() + 1,
					0))
			},
			 formatDate2(date) {
			      const year = date.getFullYear();
			      const month = ('0' + (date.getMonth() + 1)).slice(-2);
			      const day = ('0' + date.getDate()).slice(-2);
			      return `${year}-${month}-${day}`;
			    },
			    updateDateRange() {
			      const startOfMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth(), 1);
			      const endOfMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() + 1, 0);
			      this.startMonthDate = this.formatDate2(startOfMonth);
			      this.endMonthDate = this.formatDate2(endOfMonth);
				  this.getData(this.startMonthDate, this.page)
				  this.getDeviceData(this.startMonthDate, this.page)
			    },
			    getPreviousMonth() {
			      this.currentMonth.setMonth(this.currentMonth.getMonth() - 1);
			      this.updateDateRange();
			    },
			    getNextMonth() {
			      this.currentMonth.setMonth(this.currentMonth.getMonth() + 1);
			      this.updateDateRange();
			    },

			changeMonth(value) {
				
				if (value == 'pre') {
					this.getPreviousMonth()
					// let lastMonthRange = this.getLastMonthRange();
					// console.log('上个月时间范围:', lastMonthRange.start, '到', lastMonthRange.end);
					// this.last()
					// this.currentMonthStart = moment(this.startDate).format('YYYY-MM-DD')
					// this.currentMonthEnd = moment(this.endDate).format('YYYY-MM-DD')
				} else {
					this.getNextMonth()
					// let currentMonthRange = this.getCurrentMonthRange();
					// console.log('这个月时间范围:', currentMonthRange.start, '到', currentMonthRange.end);
					// this.next()
					// if (new Date(this.endDate).getTime() > new Date(this.today).getTime()) {
					// 	this.currentMonthEnd = this.today
					// 	this.currentMonthStart = moment(this.startDate).format('YYYY-MM-DD')
					// } else {
					// 	this.currentMonthEnd = moment(this.endDate).format('YYYY-MM-DD')
					// 	this.currentMonthStart = moment(this.startDate).format('YYYY-MM-DD')
					// }
				}
				// this.getData(this.currentMonthStart, this.page)
				// this.getDeviceData(this.currentMonthStart, this.page)
			},
			changeWeek(value) {
				if (value == 'pre') {
					const lastWeek = this.getLastWeekRange();
					this.currentWeekStart = lastWeek.start.toLocaleDateString()
					this.currentWeekEnd = lastWeek.end.toLocaleDateString()
					this.currentWeekStart = moment(this.currentWeekStart).format('YYYY-MM-DD');
					this.currentWeekEnd = moment(this.currentWeekEnd).format('YYYY-MM-DD');
				} else {
					const nextWeek = this.getNextWeekRange();
					if (new Date(nextWeek.end.toLocaleDateString()).getTime() > new Date(this.today).getTime()) {
						this.currentWeekEnd = this.today
						this.currentWeekStart = nextWeek.start.toLocaleDateString()
						this.currentWeekStart = moment(this.currentWeekStart).format('YYYY-MM-DD');
						this.currentWeekEnd = moment(this.currentWeekEnd).format('YYYY-MM-DD');
					} else {
						this.currentWeekEnd = nextWeek.end.toLocaleDateString()
						this.currentWeekStart = nextWeek.start.toLocaleDateString()
						this.currentWeekStart = moment(this.currentWeekStart).format('YYYY-MM-DD');
						this.currentWeekEnd = moment(this.currentWeekEnd).format('YYYY-MM-DD');
					}
				}
				this.getData(this.currentWeekStart, this.page)
				this.getDeviceData(this.currentWeekStart, this.page)
			},
			isDecimal(value) {
			    return /^\d+(\.\d+)?$/.test(value);
			},
			showChartData() {
				let count=0
				this.chartDataList=this.chartDataList.filter(item=>{return Number(item.value)>0})
				this.chartDataList.forEach((c)=>{ count+=Number(c.value)*10})
				this.chartDataList=this.chartDataList.map((item)=>{
					let v = this.formatDecimal(item.value*10/count,4)*100
					let t = v?this.formatDecimal(v,2)+'%':''
					return{
						...item,
						'labelvalue': v,
						'labelText': t
					}
				})
				this.chartData = JSON.parse(JSON.stringify({series: [{ data: this.chartDataList }]}))
			},
			// 刷新设备列表
			toUpdate(){
				this.getDeviceData(this.currentDate, this.page)
			}

		},
		onReady() {
			this.showChartData()
		},
		onLoad(options) {
			console.log(options, 'options')
			this.pageTitle = options.title
			this.label = options.label
			this.org_business_id = options.org_business_id
			this.setPageTitle(`${options.title}详情`);
			this.currentDate = new Date().toISOString().slice(0, 10)
			this.today = new Date().toISOString().slice(0, 10)
			this.nowDate = new Date();
			this.getData(this.currentDate, this.page)
			this.getDeviceData(this.currentDate, this.page)
		}
	}
</script>

<style lang="less" scoped>
	.pageContainer {
		min-height: 100vh;
		background-color: rgba(240, 240, 240, 1);

		.timeQueryTab {
			display: flex;
			align-items: center;
			height: 112upx;
			border-top: 1px solid #F2F2F2;
			background-color: rgba(255, 255, 255, 1);

			.tab {
				width: 150upx;
				height: 112upx;
				line-height: 112upx;
				text-align: center;
				font-size: 14px;
				color: rgba(0, 0, 0, 0.9);
			}

			.activeTab {
				color: rgba(22, 93, 255, 1);
				font-weight: bold;
			}
		}

		.dateTab {
			display: flex;
			align-items: center;
			height: 112upx;
			background-color: rgba(255, 255, 255, 1);
			border-top: 1px solid #F2F2F2;

			.preDay,
			.nextDay {
				width: 150upx;
				height: 112upx;
				line-height: 112upx;
				text-align: center;
				font-size: 12px;
				color: rgba(22, 93, 255, 1);
			}

			.today {
				flex: 1;
				height: 112upx;
				line-height: 112upx;
				font-size: 14px;
				text-align: center;
			}
		}

		.pageContent {
			padding: 8px;

			.deviceListTitle {
				height: 112upx;
				line-height: 112upx;
				color: rgba(100, 101, 102, 1);
				font-size: 16px;
			}
			.deviceListContent{
				.deviceItem{
					margin-bottom: 16upx;
					.deviceItemTop{
						padding: 28upx;
						width: 100%;
						min-height: 226upx;
						box-sizing: border-box;
						border-radius: 4px;
						border-bottom-left-radius: 0px;
						border-bottom-right-radius: 0px;
						background: rgba(255, 255, 255, 1);
						border-bottom: 2px solid #F1F1F1;
						.deviceName{
							font-size: 16px;
							color: rgba(0, 0, 0, 1);
							margin-bottom: 16upx;
							display: flex;
							align-items: center;
						}
						.storeSn{
							margin-left: 40upx;
							margin-bottom: 16upx;
							font-size: 14px;
							color: rgba(150, 151, 153, 1);
						}
						.deviceSn{
							margin-left: 40upx;
							margin-bottom: 16upx;
							font-size: 14px;
							color: rgba(150, 151, 153, 1);
						}
					}
					.showEnergyData {
						width: 100%;
						height: 192upx;
						border-radius:0px 0px 4px 4px;
						background: rgba(255, 255, 255, 1);
					}
					
					.showData {
						width: 100%;
						height: 192upx;
						border-radius: 4px;
						border-top-left-radius: 0px;
						border-top-right-radius: 0px;
						background: rgba(255, 255, 255, 1);
						display: flex;
					
						// justify-content: space-between;
						.dataLeft {
							width: 50%;
							padding: 16upx 52upx;
							box-sizing: border-box;
						}
					
						.dataRight {
							width: 50%;
							padding: 16upx 52upx;
							box-sizing: border-box;
						}
					
					}
				}
			}
			.showEnergyData {
				width: 100%;
				height: 198upx;
				border-radius: 4px;
				background: rgba(255, 255, 255, 1);
			}

			.showData {
				width: 100%;
				height: 198upx;
				border-radius: 4px 4px 0px 0px;
				padding-bottom:8px;
				box-sizing: border-box;
				background: rgba(255, 255, 255, 1);
				display: flex;

				// justify-content: space-between;
				.dataLeft {
					width: 50%;
					padding: 16upx 32upx;
					box-sizing: border-box;
				}

				.dataRight {
					width: 50%;
					padding: 16upx 32upx;
					box-sizing: border-box;
				}

			}
		}
	}
</style>