<template>
	<view class="container">
		<view class="title">
			布机信息
		</view>
		<view class="infoContainer">
			<view class="infoItem">
				<view class="infoTitle">
					渠道名称：
				</view>
				<view class="infoDes" v-if="deviceInfo.channel.name">
					{{deviceInfo.channel.name}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					客户名称：
				</view>
				<view class="infoDes" v-if="deviceInfo.user.name">
					{{deviceInfo.user.name}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					门店名称：
				</view>
				<view class="infoDes" v-if="deviceInfo.store.name">
					{{deviceInfo.store.name}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					门店地址：
				</view>
				<view class="infoDes" v-if="deviceInfo.store.address_detail">
					{{deviceInfo.store.address_detail}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					客户联系电话：
				</view>
				<view class="infoDes" v-if="deviceInfo.user.phone">
					{{deviceInfo.user.phone}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					渠道联系电话：
				</view>
				<view class="infoDes" v-if="deviceInfo.channel.phone">
					{{deviceInfo.channel.phone}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
		</view>
		<view class="title">
			设备信息
		</view>
		<view class="infoContainer">
			<view class="infoItem">
				<view class="infoTitle">
					产品型号：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.type_code">
					{{deviceInfo.deviceInfos.type_code}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					SN编码：
				</view>
				<view class="infoDes" v-if="deviceInfo.device_code">
					{{deviceInfo.device_code}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					设备品类：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.category_code">
					{{deviceInfo.deviceInfos.category_code}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					设备版本：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.version_code">
					{{deviceInfo.deviceInfos.version_code}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					产品执行标准：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.standard">
					{{deviceInfo.deviceInfos.standard}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					额定功率：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.power">
					{{deviceInfo.deviceInfos.power}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					额定电压：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.voltage">
					{{deviceInfo.deviceInfos.voltage}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					额定电流：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.electric_current">
					{{deviceInfo.deviceInfos.electric_current}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					设备净重：
				</view>
				<view class="infoDes" v-if="deviceInfo.deviceInfos.net_weight">
					{{deviceInfo.deviceInfos.net_weight}}
				</view>
				<view class="infoDes" v-else>
					-
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				deviceInfo:uni.getStorageSync('deviceDetail'),
			}
		},
		methods: {
			
		},
		onLoad() {
			// console.log(uni.getStorageSync('deviceDetail'))
		}
	}
</script>

<style scoped lang="less">
	.container{
		width: 100%;
		height: 100vh;
		background-color:#F5F5F5;
		.title{
			font-size: 28upx;
			color:#808080;
			width: 728upx;
			height: 96upx;
			margin: 0 auto;
			padding: 0upx 20upx;
			box-sizing: border-box;
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-bottom: 1px solid #F0F0F0;
		}
		.infoContainer{
			width: 100%;
			background-color: #fff;
			font-size: 28upx;
			.infoItem{
				width: 728upx;
				height: 96upx;
				margin: 0 auto;
				padding: 0upx 20upx;
				box-sizing: border-box;
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-bottom: 1px solid #F0F0F0;
				.infoTitle{
					color:#808080;
				}
			}
		}
	}
</style>
