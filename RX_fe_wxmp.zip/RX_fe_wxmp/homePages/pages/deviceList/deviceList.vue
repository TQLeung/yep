<template>
	<view class="pageBody">
		<view class="pageTop">
			<view class="">当前设备：{{deviceTotal}}台</view>
			<!-- <view class="">@</view> -->
		</view>
		<view class="scrollBox">
		<scroll-view v-if="true" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y list"
			@scrolltolower="lower">
		<view class="pageContent" v-if="deviceTotal">
			<view class="deviceItem" v-for="item in deviceList" :key="item.device_code">
				<view class="deviceImage">
					<view class="tag" style="background-color: rgba(200, 201, 204, 1);color: rgba(100, 101, 102, 1);" v-if="item.iot_status=='OFFLINE'">
						离线
					</view>
					<view class="tag" style="background-color: rgba(232, 255, 234, 1);color: rgba(0, 180, 42, 1);" v-else-if="item.iot_status=='ONLINE'">
						在线
					</view>
					<view class="tag" style="background-color: rgba(255, 236, 232, 1);color:rgba(238, 10, 36, 1);" v-else>
						停机
					</view>
				</view>
				<view class="deviceDes">
					<view class="deviceTitle">
						<view class="title">{{item.device_name}}</view>
						<view class="time" v-if="item.latest_time_total==0">今日{{(((item.latest_time).replace('T',' ').split(' ')[1]).split(':'))[0]}}:{{(((item.latest_time).replace('T',' ').split(' ')[1]).split(':'))[1]}}更新</view>
						<view v-else-if="item.latest_time_total<=15" style="color: rgba(255, 125, 0, 1);font-size: 12px;">
							{{item.latest_time_total}}天前更新
						</view>
						<view v-else>
							
						</view>
					</view>
					<view class="des">S N 编号：{{item.device_code}}</view>
					<view class="des">APP版本：
					<text v-if="item.hsoftware_version">{{item.hsoftware_version}}</text>
					<text v-if="item.hsoftware_version&&item.lsoftware_version">/</text>
					<text v-if="item.lsoftware_version">{{item.lsoftware_version}}</text>
					</view>
					<view class="des">布机日期：{{item.deploy_at}}</view>
					<view class="des">所在门店：{{item.store_name}}</view>
				</view>
			</view>
		</view>
		<view class="menuEmpty" v-else>
			<image src="/static/image/menuEmpty.png" mode="" style="width: 298upx;height: 250upx;"></image>
			<view class="emptyTip">
				暂无设备
			</view>
		</view>
		</scroll-view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ori_id:'',
				deviceTotal:0,
				deviceList:[],
				scrollTop: 0,
				label:'',
				page:1
			}
		},
		onLoad(options) {
			this.ori_id=options.id
			this.label=options.label
			this.getDeviceData(this.page,this.ori_id,options.label)
			console.log(options,'options设备列表')
		},
		methods: {
			getMidnightTimestamp(date) {
			    if (!(date instanceof Date)) {
			        date = new Date(); // 如果没有提供日期，则默认为当前日期
			    }
			    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0).getTime();
			},
			formatDecimal(num, decimal) { //num 传入小数, decimal 保留几位小数
				if(num){
					var _num = num.toString()
					var index = _num.indexOf('.')
				}else{
					return
				}
				if (index !== -1) {
					_num = _num.substring(0, decimal + index + 1)
				} else {
					_num = _num.substring(0)
				}
				return parseFloat(_num).toFixed(decimal)
			},
			daysFromDate(year, month, day) {
				// 将参数转换为毫秒
				const startDate = new Date(year, month - 1, day).getTime();
				const currentDate = new Date().getTime();
				const midnightTimestamp2 = this.getMidnightTimestamp();
				var midnight = new Date();
				midnight.setHours(0, 0, 0, 0); 
				var midnightTimestamp = midnight.getTime();
				var diff = (currentDate - startDate) / (1000 * 60 * 60 * 24);
				if(currentDate>midnightTimestamp){
					this.isPlus=true
					return Math.abs(this.formatDecimal(diff,0))
				}else{
					return Math.abs(this.formatDecimal(diff,0))
				}
				// console.log(startDate,'startDate')
				// console.log(Math.abs(this.formatDecimal(diff,0)),'currentDate - startDate')
				// console.log(midnightTimestamp,'midnightTimestamp')
				// console.log(currentDate,'currentDate')
				// console.log(midnightTimestamp2,'midnightTimestamp2')
				// // 计算两个日期之间的差值，并转换为天数
				// console.log( Math.abs(Math.round(diff)),' Math.abs(Math.round(diff))')
			},
			getYearMonthDay(value) {
				const date = new Date(value);
				const year = date.getFullYear()
				const month = date.getMonth() + 1
				const day = date.getDate()
				return this.daysFromDate(year, month, day)
			},
			async getDeviceData(page,id,label){
				let res
				if(label=='商户'){
					res= await this.API.home.getUserDeviceData(this.page,id)
				}else{
					res= await this.API.home.getStoreDeviceData(this.page,id)
				}
				if(res.code==0){
					this.deviceTotal=res.paging.total_records
					if (this.deviceList.length >= res.paging.total_records) {
						return
					} else {
						this.deviceList = [...this.deviceList, ...res.data]
					}
				}
				this.deviceList=this.deviceList.map((item)=>{
					return{
						...item,
						latest_time_total:this.getYearMonthDay(item.latest_time)
					}
				})
				console.log(this.deviceList,'deviceList设备列表')
			},
			
			
			lower: function(e) {
				console.log(e,'hhh')
				if (this.deviceList.length >= this.deviceTotal) {
					return
				} else {
					console.log(this.page,'this.page++')
					this.getDeviceData(this.page++,this.ori_id,this.label)
				}
			},
			
		}
	}
</script>

<style lang="less" scoped>
.pageBody{
	background-color: rgba(240, 240, 240, 1);
	height: 100vh;
	.pageTop{
		height: 112upx;
		background-color: #F8F8F8;
		display: flex;
		justify-content: center;
		align-items: center;
		color: rgba(100, 101, 102, 1);
	}
	.scrollBox{
			height: calc(100vh - 88px);
			// position: fixed;
			top: 200;
			z-index: 9999;
			.scroll-Y {
					height: calc(100vh - 88px);
				}
		}
		
	.menuEmpty {
		width: 298upx;
		text-align: center;
		margin: 0 auto;
		margin-top: 254upx;
	
		.emptyTip {
			font-size: 24upx;
			color: rgba(166, 166, 166, 1);
			margin-top: 48upx;
		}
	}
	.pageContent{
		width: 718upx;
		margin: 0 auto;
		.deviceItem{
			display:flex;
			margin-top: 16upx;
			min-height: 316upx;
			background-color: rgba(255, 255, 255, 1);
			border-radius:4px;
			padding: 18upx 16upx;
			box-sizing: border-box;
			.deviceImage{
				width: 128upx;
				height: 128upx;
				text-align: center;
				border-radius:4px;
				margin-right: 18upx;
				background-color: rgba(240, 240, 240, 1);
				.tag{
					width:78upx;
					height: 40upx;
					font-size: 12px;
					text-align: center;
					line-height: 40upx;
					margin-top: 72upx;
					margin-left: 26upx;
					border-radius:4px;
				}
			}
			.deviceDes{
				flex:1;
				.des{
					font-size: 14px;
					font-weight: 400;
					letter-spacing: 0px;
					line-height: 40upx;
					margin-top: 17upx;
					color: rgba(150, 151, 153, 1);
				}
				.deviceTitle{
					display:flex;
					align-items: center;
					justify-content: space-between;
					.title{
						font-size: 16px;
						line-height:44upx;
						font-weight: 400;
						color: rgba(0, 0, 0, 1);
					}
					.time{
						font-size: 12px;
						font-weight: 400;
						letter-spacing: 0px;
						line-height: 20px;
						color: rgba(7, 193, 96, 1);
					}
				}
			}
		}
	}
}
</style>
