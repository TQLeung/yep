<template>
	<view class="index">
		<view style="height: 100%">
			<view class="AddRess" v-for="(item,index) in Addresslist" :key="item.id" @touchstart="touchS($event,item)"
				@touchmove="touchM" @touchend="touchE">
				<view class="Bito" :style="{marginLeft:InfoId === item.id?'-'+LeftRange+'rpx':''}">
					<view class="Hiurs">
						<view class="NaPh">
							<view class="Name">
								{{item.name}}
							</view>
							<view class="Phone">
								{{item.phone}}
							</view>
						</view>

						<view class="Defas">
							<view class="DeTes" v-if="item.is_default">
								默认
							</view>
						</view>
					</view>
					<view class="DDress">
						{{item.address+''+item.detail_address}}
					</view>
					<view class="Defes">
						<view class="Pic" @click="Default(item)">
							<!-- 默认地址勾选图案  可以自选 -->
						</view>
						<view class="Tes">
							设置为默认地址
						</view>
					</view>

				</view>
				<view class="EditInfo" @click="EditInfo(item)">
					编辑
				</view>
				<view class="Delete" @click="Delete(item)">
					删除
				</view>
			</view>

		</view>



	</view>

</template>

<script>
	export default {
		data() {
			return {
				Addresslist: [{
						name: '张三',
						phone: '150****5757',
						id: 1,
						is_default: true,
						address: '某某某地区',
						detail_address: '某某某地区1d1001室'
					},
					{
						name: '李四',
						phone: '150****5757',
						id: 2,
						is_default: false,
						address: '某某某地区',
						detail_address: '某某某地区1d1001室'
					}
				],
				LeftRange: 0, //移动的范围
				startX: 0, //首次点击的位置
				moveX: 0, //滑动时的距离
				InfoId: '',

			}
		},
		methods: {
			//设置默认地址
			Default(item) {

			},
			//左滑删除
			touchS(e, item) {
				//更新初始值
				this.LeftRange = 0
				// startX记录开始移动的位置
				if (e.touches.length === 1) {
					this.startX = e.touches[0].clientX
				}
				//移动列表某个 防止v-for循环整体循环
				this.InfoId = item.id
			},
			touchM(e) {
				//滑动时判断是否为初始值
				if (this.LeftRange === 430) {
					return
				} else {
					if (e.touches.length === 1) {
						//手指移动时水平方向位置
						this.moveX = e.touches[0].clientX
						//判断移动的距离是变大变小 变大便是右移
						if (this.startX < this.moveX) {
							//更改移动时的距离。防止弹出删除按钮
							this.moveX = 0
						} else {
							//移动的距离 加 20 如需调整 可以调整这里
							this.LeftRange += 20
							if (this.LeftRange > 300) {
								//如果大于430 则直接等于300
								this.LeftRange = 300
							}
						}

					}
				}
			},
			touchE(e) {
				//如果滑动的距离大于45  则直接弹出删除按钮
				if (this.moveX > 45) {
					this.LeftRange = 300
				}
				//松开后刷新 滑动的距离
				this.moveX = 0
			},
			//编辑地址
			EditInfo(item) {
				console.log(item)
			},
			//删除地址
			Delete(item) {
				console.log(item)
			},

		}
	}
</script>

<style lang="less" scoped>
	.AddRess {
		width: 702rpx;
		height: 252rpx;
		background: #ffffff;
		border: 2rpx solid #f4f4f4;
		overflow: hidden;
		border-radius: 20rpx;
		margin: 20rpx 28rpx;
		display: flex;
		align-items: center;

		.Bito {
			height: 100%;
			width: 100%;
			display: flex;
			flex-direction: column;
			justify-content: space-evenly;

			.Hiurs {
				margin: 0 44rpx 0 30rpx;
				display: flex;
				align-items: center;
				justify-content: space-between;

				.NaPh {
					display: flex;
					align-items: center;

					.Name {
						font-size: 28rpx;
						font-weight: 400;
						color: #000000;
					}

					.Phone {
						margin-left: 28rpx;
						font-size: 28rpx;
						font-weight: 400;
						color: #000000;
					}
				}

				.Defas {
					width: 58rpx;
					height: 28rpx;
					display: flex;
					align-items: center;
					justify-content: center;

					.DeTes {

						width: 58rpx;
						height: 28rpx;
						display: flex;
						align-items: center;
						justify-content: center;
						background-color: #000;
						font-size: 20rpx;
						font-weight: 400;
						color: #ffffff;
					}
				}

			}

			.DDress {
				margin-left: 30rpx;
				width: 520rpx;
				height: 34rpx;
				font-size: 24rpx;
				font-weight: 400;
				color: #000000;
			}

			.Defes {
				margin-left: 30rpx;
				display: flex;
				align-items: center;

				.Pic {
					display: flex;
					align-items: center;

					image {
						width: 34rpx;
						height: 34rpx;
					}
				}

				.Tes {
					margin-left: 19rpx;
					font-size: 26rpx;
					font-weight: 400;
					color: #000000;
				}
			}
		}

		.Delete {
			margin-left: 20rpx;
			width: 124rpx;
			height: 252rpx;
			background: #e4e4e4;
			border-radius: 20rpx;
			margin-right: -430rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 22rpx;
			font-weight: 400;
			color: #ffffff;
		}

		.EditInfo {
			margin-left: 20rpx;
			width: 124rpx;
			height: 252rpx;
			background: #04a1eb;
			border-radius: 20rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 22rpx;
			font-weight: 400;
			color: #ffffff;
		}
	}
</style>