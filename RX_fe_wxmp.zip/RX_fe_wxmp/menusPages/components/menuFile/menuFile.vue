<template>
	<view class="menuFileContainer">
		<view class="" v-if="showMenuExamine">
			<view class="btn" v-if="!isShow">
				<button @tap="showRadio" v-if="!useFileInfo[0]">审核菜谱文件</button>
				<button @tap="showRadio" v-else>重新审核菜谱文件</button>
			</view>
			<view class="confirmBtn" v-else>
				<button class="cancle" @tap="cancle">取消</button>
				<button class="confirm" @tap="confirm">审核已选中菜谱文件</button>
			</view>
		</view>
		<view class="elseMenu" v-if="useFileInfo.length">
			已审核采用菜谱
		</view>
		<view class="auditPass" v-if="useFileInfo.length">
			<view class="fileContent">
				<view class="itemTop" @tap="toFileDetail(useFileInfo[0])">
					<view class="dateIndex" style="display: flex;justify-content: space-between;">
						<view class="">
							<text class="iconfont icon-check-circle-fill"
								style="color:rgba(38, 79, 247, 1);margin-right: 20upx;"></text>
							<text class="date"
								v-if="useFileInfo[0].created_at">[{{(useFileInfo[0].created_at).replace('T',' ').split('.')[0]}}]</text>
						</view>
						<view class="">
							<text
								style="padding: 12upx 16upx;background-color: rgba(192, 204, 252, 1);color: rgba(38, 79, 247, 1);font-size: 24upx;border-radius: 4px;margin-left: 30upx;">审核采用</text>
						</view>
					</view>
					<view class="icon">
						<text class="iconfont icon-xiangyou" style="color:rgba(38, 79, 247, 1);"></text>
					</view>
				</view>
				<view class="itemContent" @tap="toFileDetail(useFileInfo[0])">
					<view class="contentTop" @tap="toFileDetail(useFileInfo[0])" style="margin-bottom: 10upx;">
						<text style="margin-right: 20upx;"
							v-if="useFileInfo[0].device_code">研发设备：{{useFileInfo[0].device_code}}</text>
					</view>
					<view style="margin-bottom: 10upx;">
						<text>文件编号：{{useFileInfo[0].code}}</text>
					</view>
					<view class="shopAddress" style="margin-bottom: 10upx;">
						<text>研发账号：{{useFileInfo[0].develop_account}}</text>
					</view>
					<view class="shopAddress">
						<text v-if="useFileInfo[0].approval_at">审核时间：{{(useFileInfo[0].approval_at).replace('T',' ').split('.')[0]}}</text>
					</view>
				</view>
				
				<view class="remarks">
					备注：审核后下发菜谱时，将该配方工艺下发到设备
				</view>
				<!-- <view class="des">
					<view class="desTitle">
						研发来源
					</view>
					<view class="desValue">
						<text class="iconfont icon-xiangyou" style="color:rgba(38, 79, 247, 1);"></text>
					</view>
				</view> -->
			</view>
			
		</view>
		
		<view class="elseMenu" v-if="fileList.length">
			待审核菜谱
		</view>
		<radio-group class="fileList" @change="radioChange" v-if="fileList.length">
			<label class="fileItem uni-list-cell uni-list-cell-pd" v-for="(item,index) in fileList" :key="item.id">
				<view class="radioBox" v-if="isShow">
					<radio :id="item.name" :value="JSON.stringify(item)" :checked="item.checked"></radio>
				</view>
				<view class="fileContent" @longpress="showRadio" @tap="toFileDetail(item)">
					<view class="itemTop">
						<view class="dateIndex">
							<text class="index"
								style="color:rgba(38, 79, 247, 1);margin-right: 20upx;">{{index+1}}</text>
							<text class="date"
								v-if="item.created_at">[{{(item.created_at).replace('T',' ').split('.')[0]}}]</text>
						</view>
						<view class="icon">
							<text v-if="item.status=='待审核'" style="color:red">{{item.status}}</text>
							<text v-else style="color:gray;">{{item.status}}</text>
							<text class="iconfont icon-xiangyou"
								style="color:rgba(38, 79, 247, 1);margin-left: 20upx;"></text>
						</view>
					</view>
					<view class="itemContent">
						<view class="contentTop" style="margin-bottom: 10upx;">
							<text style="margin-right: 20upx;" v-if="item.device_code">研发设备：{{item.device_code}}</text>
						</view>
						<view style="margin-bottom: 10upx;">
							<text>文件编号：{{item.code}}</text>
						</view>
						<view class="shopAddress" style="margin-bottom: 10upx;">
							<text>研发账号：{{item.develop_account}}</text>
						</view>
						<view class="shopAddress">
							<text v-if="item.approval_at">审核时间：{{(item.approval_at).replace('T',' ').split('.')[0]}}</text>
						</view>
					</view>
				</view>
			</label>
		</radio-group>
		<view class="elseMenu" v-if="elseMenuFile.length">
			历史采用菜谱
		</view>
			<radio-group class="fileList" @change="radioChange" v-if="elseMenuFile.length">
				<label class="fileItem uni-list-cell uni-list-cell-pd" v-for="(item,index) in elseMenuFile" :key="item.id">
					<view class="radioBox" v-if="isShow">
						<radio :id="item.name" :value="JSON.stringify(item)" :checked="item.checked"></radio>
					</view>
				<view class="fileContent" @tap="toFileDetail(item)">
					<view class="itemTop">
						<view class="dateIndex">
							<text class="index"
								style="color:rgba(38, 79, 247, 1);margin-right: 20upx;">{{index+1}}</text>
							<text class="date"
								v-if="item.created_at">[{{(item.created_at).replace('T',' ').split('.')[0]}}]</text>
						</view>
						<view class="icon">
							<text style="color:gray;">{{item.status}}</text>
							<text class="iconfont icon-xiangyou"
								style="color:rgba(38, 79, 247, 1);margin-left: 20upx;"></text>
						</view>
					</view>
					<view class="itemContent">
						<view class="contentTop" style="margin-bottom: 10upx;">
							<text style="margin-right: 20upx;" v-if="item.device_code">研发设备：{{item.device_code}}</text>
						</view>
						<view style="margin-bottom: 10upx;">
							<text>文件编号：{{item.code}}</text>
						</view>
						<view class="shopAddress" style="margin-bottom: 10upx;">
							<text>研发账号：{{item.develop_account}}</text>
						</view>
						<view class="shopAddress">
							<text v-if="item.approval_at">审核时间：{{(item.approval_at).replace('T',' ').split('.')[0]}}</text>
						</view>
					</view>
			</view>
			</label>
			</radio-group>
		<view class="menuEmpty" v-if="!total">
			<image src="../../static/image/menuEmpty.png" mode="" style="width: 298upx;height: 250upx;"></image>
			<view class="emptyTip">
				请上传菜谱文件
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		props:['menuDetail'],
		computed: {
			...mapState('menus', {
				customer: state => state.customer,
				menuInfo: state => state.menuInfo,
			})
		},
		data() {
			return {
				isShow: false,
				// menuInfo: {},
				chooseMenuFile: {},
				fileList: [],
				useFileInfo: [],
				elseMenuFile:[],
				showMenuExamine:false,
				total: 0,
				org_business_id: '',
				account_id: uni.getStorageSync('userInfo').account_id,
				radioItems: [{
						name: 'USA',
						value: '美国',
						time: '[2023.05.06 11:23:23]',
						code: '202309374830'
					},
					{
						name: 'CHN',
						value: '中国',
						time: '[2023.05.06 11:43:20]',
						checked: 'true',
						code: '2023093749090'
					}
				],
			}
		},
		methods: {
			async getMenuFileList() {
				uni.showLoading({
					title: '加载中'
				});
				const res = await this.API.menus.getFileList(this.org_business_id, this
					.menuInfo.recipe_category_id, this.menuInfo.spec, this.menuInfo.copies)
				if (res.code == 0) {
					uni.hideLoading();
					this.total = res.paging.total_records
					this.fileList = (res.data.filter((item) => {
						return item.status == '待审核'
					})).map((item) => {
						return {
							...item,
							checked: false
						}
					})
					this.elseMenuFile=(res.data.filter((item) => {
						return item.status != '审核采用'&&item.status != '待审核'
					}))
					this.useFileInfo = (res.data.filter((item) => {
						return item.status == '审核采用'
					}))
				}
			},
			radioChange(e) {
				this.chooseMenuFile = JSON.parse((e.target.value))
				this.chooseMenuFile.spec = Number(this.chooseMenuFile.spec)
				this.chooseMenuFile.copies = Number(this.chooseMenuFile.copies)
				var checked = e.target.value
				var changed = {}
				for (var i = 0; i < this.radioItems.length; i++) {
					if (checked.indexOf(this.radioItems[i].name) !== -1) {
						changed['radioItems[' + i + '].checked'] = true
					} else {
						changed['radioItems[' + i + '].checked'] = false
					}
				}
			},
			cancle() {
				this.isShow = false
			},
			confirm() {
				if (!this.chooseMenuFile.spec) {
					uni.showToast({
						title: '请选择菜谱',
						icon: 'error'
					})
					return
				}
				uni.showModal({
					title: '菜谱文件审核确认',
					content: '审核菜谱文件后，可将该菜谱下载其他设备使用。',
					confirmText: '确定审核',
					cancelText: '取消',
					showCancel: true,
					success: async function(res) {
						var that = this
						if (res.confirm) {
							uni.showLoading({
								title: '加载中'
							});
							console.log(this.chooseMenuFile,'this.chooseMenuFile')
							const res = await this.API.menus.auditFile({
								"account_id": this.account_id,
								"user_id": this.org_business_id,
								"recipe_category_id": this.chooseMenuFile.recipe_category_id,
								"recipe_id": this.chooseMenuFile.id,
								"recipe_sc_id": this.chooseMenuFile.recipe_sc_id,
								"spec": this.chooseMenuFile.spec,
								"copies": this.chooseMenuFile.copies,
								"approval_remark": "非常好吃"
							})
							if (res.code == 0) {
								uni.hideLoading();
								uni.showToast({
									title: '审核成功',
									icon: 'success'
								})
								this.isShow = false
								this.getMenuFileList()
								let pages = getCurrentPages();
								let beforePage = pages[pages.length - 1]
								beforePage.$vm.isUpdate()
							}else{
								uni.showToast({
									title: res,
									icon: 'error'
								})
							}
						} else if (res.cancel) {
							this.isShow = false
						}
					}.bind(this)
				})
			},
			showRadio() {
				this.isShow = !this.isShow
			},
			toRecord() {
				uni.navigateTo({
					url: `/menusPages/pages/recordDetail/recordDetail?recipe_category_id=${this.menuInfo.recipe_category_id}`
				})
			},
			toFileDetail(row) {
				uni.navigateTo({
					url: `/menusPages/pages/fileDetail/fileDetail?fileId=${row.id}&menuInfo=${JSON.stringify(row)}`
				})
			}
		},
		mounted() {
			// this.menuInfo = options
			// console.log(this.menuInfo,'this.menuInfo')
			this.org_business_id = this.customer.org_business_id
			this.userInfo = uni.getStorageSync('userInfo')
			if(this.userInfo.menu_ids){
				this.showMenuExamine=(this.userInfo.menu_ids.split(',')).includes('7')
			}
			if(this.menuInfo){
				this.getMenuFileList()
			}
			
		}
	}
</script>

<style lang="less" scoped>
	.menuFileContainer {
		height: 100vh;
		background-color: rgba(245, 245, 245, 1);
		position: relative;

		.menuEmpty {
			width: 298upx;
			text-align: center;
			margin: 0 auto;
			margin-top: 254upx;

			.emptyTip {
				font-size: 24upx;
				color: rgba(166, 166, 166, 1);
				margin-top: 48upx;
			}
		}

		.btn {
			position: fixed;
			bottom: 40upx;
			left: 50%;
			transform: translateX(-50%);

			button {
				width: 686upx;
				height: 80upx;
				line-height:80upx;
				background-color: rgba(38, 79, 247, 1);
				border-radius: 875px;
				color: #fff;
			}
		}

		.confirmBtn {
			width: 100vw;
			position: fixed;
			bottom: 40upx;
			display: flex;
			justify-content: space-between;

			.cancle {
				width: 216upx;
				height: 80upx;
				line-height:80upx;
				background-color: #fff;
				border-radius: 875px;
				color: rgba(128, 128, 128, 1);
				border: 1px solid rgba(229, 229, 229, 1);
			}

			.confirm {
				width: 454upx;
				height: 80upx;
				line-height:80upx;
				background-color: rgba(38, 79, 247, 1);
				border-radius: 875px;
				color: #fff;
			}
		}

		.menuTop {
			width: 750upx;
			// height: 112upx;
			background-color: #fff;
			padding: 14upx 30upx;
			box-sizing: border-box;
			box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.25);

			.menuLeft {
				display: flex;
				justify-content: space-between;
				align-items: center;

				.menuTitle {
					font-size: 36upx;
					color: #000;
				}

			}

			.menuCode {
				font-size: 24upx;
				color: rgba(166, 166, 166, 1);
			}
		}

		.elseMenu {
			padding: 4upx 38upx;
			margin-top: 16upx;
			// height: 82upx;
			color: rgba(128, 128, 128, 1);
		}
		
		.auditPass {
			width: 100vw;
			min-height: 320upx;
			// display: flex;
			// align-items: center;
			// margin-bottom: 16upx;
			margin-top: 16upx;
			
			.fileContent {
				flex-grow: 1;
				background-color: #fff;
				padding: 32upx 34upx;
				// padding-bottom: 0px;
				border-radius: 5px;
				box-sizing: border-box;
				margin-bottom: 16upx;

				.itemTop {
					display: flex;
					align-items: center;
					justify-content: space-between;
					margin-bottom: 32upx;
					color: rgba(38, 79, 247, 1);
				}

				.itemContent {
					color: rgba(166, 166, 166, 1);
					font-size: 24upx;

					.contentTop {
						// margin-bottom: 16upx;
					}
				}
				.des {
					// width: 100vw;
					height: 112upx;
					// padding: 36upx 34upx;
					font-size: 28upx;
					box-sizing: border-box;
					display: flex;
					align-items: center;
					justify-content: space-between;
					background-color: #fff;
					border-bottom: 1px solid #F6F6F6;
				
					.desTitle {
						// color: rgba(166, 166, 166, 1);
					}
				}
				
			}

			.remarks {
				margin-top: 32upx;
				color: rgba(38, 79, 247, 1);
				font-size: 24upx;
			}
		}

		.fileList {
			width: 100vw;
			padding: 32upx 8upx;

			.fileItem {
				width: 734upx;
				// height:220upx;
				display: flex;
				align-items: center;
				margin-bottom: 40upx;

				.radioBox {
					width: 88upx;
					text-align: center;
					// margin-right: 16upx;
				}

				.fileContent {
					flex-grow: 1;
					background-color: #fff;
					padding: 32upx 34upx;
					border-radius: 5px;
					box-sizing: border-box;

					.itemTop {
						display: flex;
						align-items: center;
						justify-content: space-between;
						margin-bottom: 32upx;
					}

					.itemContent {
						color: rgba(166, 166, 166, 1);
						font-size: 24upx;

						.contentTop {
							// margin-bottom: 16upx;
						}
					}
				}
			}
		}
	}
</style>