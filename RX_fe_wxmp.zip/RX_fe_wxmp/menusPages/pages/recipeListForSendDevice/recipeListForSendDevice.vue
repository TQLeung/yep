<template>
  <view class="chooseMenu">
    <view class="searchBox" style="position: relative">
      <input
        class="uni-input"
        focus
        placeholder="搜索菜品名称"
        type="text"
        :value="menuCategoryName"
        @input="queryMenu"
      />
      <uni-icons
        style="position: absolute; right: 120upx; z-index: 9999"
        type="clear"
        size="16"
        v-if="menuCategoryName"
        @click="clearIcon"
      ></uni-icons>
    </view>

    <view class="menuContainer">
      <view class="checkGroup">
        <checkbox-group>
          <view
            class="menuLabel"
            v-for="(item, index) in menuList"
            :key="item.id"
          >
            <!-- 一级菜单 -->
            <view
              class="menuLabel_stair"
              @tap.stop="controlAdjustment(index, item)"
            >
              <label
                class="menuLabel_stair"
                @tap.stop="recipeCategoryCheck(index, item)"
              >
                <checkbox
                  :value="item.id"
                  :checked="item.checked"
                  color="rgba(38, 79, 247, 1)"
                  style="transform: scale(0.7)"
                />
                <view class="menuItem">
                  <view class="menuInfo">
                    <view class="tag">菜品</view>
                    <view class="menuTitle">
                      <!-- <text style="margin-right: 20upx;" v-if="menuCategoryName" v-html="brightenKeyword(item.name,keyWord)"></text> -->
                      <!-- <text v-else>{{item.name}}</text> -->
                      <!-- <text>{{ item.showChildren }}</text> -->
                      <text
                        v-for="(v, i) in item.bringtKeyList"
                        :key="i"
                        :style="{ color: `${v.color}` }"
                        >{{ v.value }}</text
                      >
                    </view>
                  </view>
                </view>
              </label>

              <!-- 右侧图标 -->
              <view class="rightIcon">
                <text>{{ item.recipe_num }}</text>
                <view :class="{ iconfont: true, active: item.showChildren }">
                  <uni-icons
                    type="bottom"
                    color="rgba(38, 79, 247, 1)"
                    size="18"
                  ></uni-icons>
                </view>
              </view>
            </view>
            <!-- 二级菜单 -->
            <view
              :style="[{ height: `${item.twoChildren.length * 120}rpx` }]"
              v-show="item.showChildren"
            >
              <view
                :style="[
                  {
                    display: 'flex',
                    alignItems: 'center',
                    padding: '0 55rpx',
                    backgroundColor: 'white',
                    marginBottom: '5rpx',
                    height: '115rpx',
                    boxSizing: 'border-box',
                  },
                ]"
                v-for="(subItem, subIndex) in item.twoChildren"
                :key="subItem.recipe_id"
              >
                <template v-if="subItem.recipe_id">
                  <label
                    @tap.stop="recipeSpecCopyCheck(subItem, item)"
                    :style="[
                      {
                        display: 'flex',
                        fontSize: '27rpx',
                        backgroundColor: 'white',
                      },
                    ]"
                  >
                    <checkbox
                      :value="subItem.recipe_id"
                      :checked="subItem.checked"
                      color="rgba(37, 79, 247, 1)"
                      style="transform: scale(0.7)"
                    />
                    <view
                      class="tag"
                      style="
                        color: gray;
                        margin-right: 19upx;
                        margin-left: 20upx;
                      "
                    >
                      菜谱{{ subIndex + 1 }}</view
                    >
                    <view class="menuTitle">
                      <text style="margin-right: 19upx">{{
                        subItem.name
                      }}</text>
                      {{ subItem.spec }}g/{{ subItem.copies }}份
                    </view>
                  </label>
                </template>
                <template v-else>
                  <view class="iconfont_nodata">
                    <uni-icons
                      type="info"
                      color="#8a9a9a"
                      size="27"
                    ></uni-icons>
                    <text>暂无数据</text>
                  </view>
                </template>
              </view>
            </view>
            <!-- 过度效果 -->
            <view
              :class="{ menuInfo_second_level: true }"
              :style="[
                item.loading ? { height: `120rpx` } : { height: '0rpx' },
              ]"
            >
              <view class="iconfont_loading">
                <uni-icons
                  type="spinner-cycle"
                  color="#9a9a9a"
                  size="48"
                ></uni-icons>
              </view>
            </view>
          </view>
        </checkbox-group>
      </view>
    </view>
    <view class="menuBottom">
      <view class="checkboxAll">
        <label>
          <checkbox
            @click="rcChangeAll"
            value="all"
            :checked="checkAll"
            color="rgba(38, 79, 247, 1)"
            style="transform: scale(0.7)"
          />
          <text style="color: rgba(38, 79, 247, 1)">全选</text>
        </label>
      </view>
      <view class="count" style="color: rgba(128, 128, 128, 1)">
        已选菜谱{{ chooseMenuCount }}/{{ menuCount }}
      </view>
      <view class="nextBtn">
        <button @click="toChooseDevice">下一步</button>
      </view>
    </view>
  </view>
</template>

<script>
import { mapMutations, mapState } from "vuex";
// import { reative} from "vue";

export default {
  computed: {
    ...mapState("menus", {
      customer: (state) => state.customer,
      menusListContent: (state) => state.menusListContent,
      allMenus: (state) => state.allMenus,
    }),
  },
  data() {
    return {
      menuCount: 0,
      value: ["0"],
      menuList: [],
      checkAll: false,
      org_business_id: "",
      recipeSelected: [],
      chooseMenuList: [],
      chooseMenuCount: 0,
      menuCategoryName: "",
      keyWord: "",
    };
  },
  watch: {
    recipeSelected: {
      handler(nv, ov) {
        // console.log("wi recipe selected @@@@");
        this.chooseMenuCount = this.recipeSelectedIds().length;
      },
      deep: true,
    },
  },
  methods: {
    ...mapMutations("menus", [
      "setMenusListContent",
      "setAllMenus",
      "setCustomer",
    ]),
    rcChangeAll() {
      this.checkAll = !this.checkAll;
      const c = this.checkAll;
      this.menuList.forEach((el) => {
        el.checked = c;
        if (c) {
          this.recipeSelectedModify(
            el,
            el.twoChildren.map((e) => {
              e.checked = c;
              return e.recipe_id;
            }),
            null
          );
        } else {
          this.recipeSelectedModify(
            el,
            null,
            el.twoChildren.map((e) => {
              e.checked = c;
              return e.recipe_id;
            })
          );
        }
      });
    },
    recipeSelectedModify(category, add, remove) {
      let sl = this.recipeSelected[category.id];
      if (!sl) {
        this.$set(this.recipeSelected, category.id, []);
        // this.recipeSelected[category.id] = [];
        sl = this.recipeSelected[category.id];
      }
      if (add) {
        add.forEach((el) => {
          if (!sl.includes(el)) {
            sl.push(el);
          }
        });
      }
      if (remove) {
        remove.forEach((el) => {
          const index = sl.indexOf(el);
          if (index > -1) {
            sl.splice(index, 1);
          }
        });
      }
      this.$delete(this.recipeSelected, category.id);
      this.$set(this.recipeSelected, category.id, sl);
      const obj = this.recipeSelected;
      if (obj[category.id].length == 0) category.checked = false;
      // this.chooseMenuCount = this.recipeSelectedIds().length;
      //   console.log("final recipe selected:", this.recipeSelected);
    },
    recipeSelectedIds() {
      let ids = [];
      const obj = this.recipeSelected;
      for (let key in obj) {
        if (obj.hasOwnProperty(key) && obj[key] && obj[key].length > 0) {
          obj[key].forEach((el) => ids.push(el));
        }
      }
      return ids;
    },
    clearIcon() {
      this.menuCategoryName = "";
      this.getMenuListData();
    },
    recipeCategoryCheck(index, item) {
      const fc = !item.checked;
      // console.log(item.checked);
      // console.log(e.detail.value);
      const list = this.menuList[index].twoChildren;
      const modifyIds = this.menuList[index].twoChildren.map(
        (el) => el.recipe_id
      );
      for (let i = 0; i < list.length; i++) {
        this.$set(list[i], "checked", fc);
        // list[i].checked = item.checked;
      }
      // console.log(add);
      if (fc) this.recipeSelectedModify(item, modifyIds, null);
      else this.recipeSelectedModify(item, null, modifyIds);
      this.$set(item, "checked", fc);
    },
    recipeSpecCopyCheck(sc, category) {
      sc.checked = !sc.checked;
      if (sc.checked) this.recipeSelectedModify(category, [sc.recipe_id], null);
      else this.recipeSelectedModify(category, null, [sc.recipe_id]);
    },
    queryMenu(val) {
      this.menuCategoryName = val.detail.value;
      this.keyWord = this.menuCategoryName;
      this.getMenuListData();
    },
    // 调整控件
    controlAdjustment(index, item) {
      this.menuList[index].loading = true; // 开启过度效果
      item.showChildren = !item.showChildren;
      // item.checkd=true
      this.menuList[index].loading = false;
    },

    async getMenuListData() {
      uni.showLoading({
        title: "加载中",
      });
      const res = await this.API.menus.getVarietyList(
        1,
        this.org_business_id,
        this.menuCategoryName,
        "1",
        "",
        true
      );
      if (res.code == 0) {
        // let menuCount = 0
        this.menuList = res.data.map((el) => {
          // menuCount += el.recipe_num;
          let checked = false;
          let children = [];
          const rcSelected = this.recipeSelected[el.id];
          if (rcSelected && rcSelected.length > 0) {
            checked = true;
          }
          if (el.recipe_ids_info) {
            el.recipe_ids_info.split(",").forEach((i) => {
              const sr = i.split("#-#");
              let scChecked = false;
              if (rcSelected && rcSelected.includes(sr[0])) scChecked = true;
              children.push({
                recipe_id: sr[0],
                spec: sr[1],
                copies: sr[2],
                recipe_category_id: el.id,
                checked: scChecked,
              });
            });
          }
          return {
            id: el.id,
            recipe_num: el.recipe_num,
            bringtKeyList: el.name.split("").map((item) => {
              return {
                value: item,
                color: "rgba(0, 0, 0, 1)",
              };
            }),
            checked: checked,
            loading: false, // 过度效果
            showChildren: false,
            twoChildren: children.sort((a, b) => {
              return b.spec - a.spec;
            }), // 二层数据
          };
        });
        if (this.menuCategoryName) {
          this.menuList.forEach((menu) => {
            menu.bringtKeyList.forEach((key) => {
              if (this.menuCategoryName.indexOf(key.value) != -1) {
                key.color = "rgba(255, 125, 0, 1)";
              } else {
                key.color = "rgba(0, 0, 0, 1)";
              }
            });
          });
        }
        // console.log(this.menuList);
        uni.hideLoading();
      } else {
        // setTimeout(function () {
        //   uni.hideLoading();
        // }, 5000);
        uni.showModal({
          content: "搜索失败",
          success: function (res) {
            if (res.confirm) {
              console.log("确定");
            } else if (res.cancel) {
              console.log("取消");
            }
          },
        });
      }
    },
    async getTotal() {
      const res = await this.API.menus.getMenuTotal(this.org_business_id);
      this.menuCount = res.paging.total_records;
      // console.log(res, "res");
    },
    toChooseDevice() {
      // 数据过滤
      // console.log(this.chooseMenuList, "哈哈选择的菜谱");
      let newMenusList = [];
      if (this.chooseMenuCount <= 0) {
        uni.showToast({
          title: "请选择菜谱",
          icon: "error",
        });
        return;
      }
      // let arr = Array.from(new Set(this.chooseMenuList));
      let arr = this.recipeSelectedIds();
      // console.log(arr, "arr");
      uni.navigateTo({
        url: `/menusPages/pages/downToDevice/downToDevice?chooseMenu=${arr}`,
      });
    },
    // 获取第二层数据
    // 二级菜单数据变化
  },

  onLoad() {
    // this.setCustomer({
    //   org_business_id: "f059d57e-1979-4678-bf1b-677c8e59f13a",
    // });
    // console.log("rrr", this.customer);
    this.org_business_id = this.customer.org_business_id;
    this.getMenuListData();
    this.getTotal();
    // this.setMenusListContent([])
    // this.setColor('1')
  },
};
</script>
<style lang="less" scoped>
.chooseMenu {
  width: 100vw;
  height: 100vh;
  background-color: rgba(245, 245, 245, 1);
  position: relative;

  .menuBottom {
    width: 100vw;
    height: 112upx;
    background: rgba(255, 255, 255, 1);
    position: fixed;
    bottom: 0;
    left: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16upx 20upx 26upx 20upx;
    box-sizing: border-box;

    .nextBtn {
      button {
        background-color: rgba(38, 79, 247, 1);
        width: 214upx;
        height: 80upx;
        border-radius: 875px;
        text-align: center;
        line-height: 80upx;
        color: #fff;
      }
    }
  }

  .menuEmpty {
    // width: 298upx;
    text-align: center;
    margin: 0 auto;
    padding-top: 254upx;

    .emptyTip {
      font-size: 24upx;
      color: rgba(166, 166, 166, 1);
      margin-top: 48upx;
    }
  }

  .searchBox {
    height: 56px;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(255, 255, 255, 1);
    // padding: 12px;
    box-sizing: border-box;

    .uni-input {
      width: 351px;
      height: 32px;
      opacity: 1;
      border-radius: 16px;
      background: rgba(245, 245, 245, 1);
    }
  }

  .menuContainer {
    height: calc(100vh - 112px);
    overflow-y: scroll;
    background-color: rgba(245, 245, 245, 1);

    .checkGroup {
      padding: 16upx;
      box-sizing: border-box;

      .menuLabel {
        display: flex;
        flex-direction: column;
        border-radius: 5px;
        margin-bottom: 16upx;
        display: flex;

        .menuItem {
          .menuInfo {
            display: flex;
            align-items: center;

            .tag {
              width: 56upx;
              height: 32upx;
              text-align: center;
              line-height: 32upx;
              border-radius: 4px;
              background-color: #d0d8f9;
              color: rgba(14, 60, 238, 1);
              margin-right: 20upx;
              font-size: 16upx;
            }

            .menuTitle {
              font-size: 28upx;
            }

            .menuSpec {
              width: 140upx;
              height: 36upx;
              text-align: center;
              line-height: 36upx;
              border-radius: 4px;
              background: rgba(38, 79, 247, 0.1);
              font-size: 24upx;
              color: rgba(38, 79, 247, 1);
              margin-top: 22upx;
              margin-bottom: 30upx;
            }

            .useCount {
              color: rgba(166, 166, 166, 1);
              font-size: 28upx;
            }
          }

          .menuImage {
            width: 320upx;
            height: 180upx;
            line-height: 180upx;
            text-align: center;
            background-color: rgba(245, 248, 255, 1);
            border-radius: 4px;
            position: relative;
            margin-right: 16upx;
            overflow: hidden;

            .menuTag {
              width: 86upx;
              height: 32upx;
              text-align: center;
              line-height: 32upx;
              font-size: 20upx;
              position: absolute;
              top: 0px;
              left: 0px;
              background-color: rgba(255, 205, 194, 1);
              border-radius: 4px 0px, 4px, 0px;
              color: rgba(255, 87, 51, 1);
            }

            .menuName {
              width: 98%;
              margin: 0 auto;
              font-size: 48upx;
              color: rgba(38, 79, 247, 1);
            }
          }
        }
      }
    }
  }
}

// 一级菜单样式
/deep/ .menuLabel_stair {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 15rpx;
  box-sizing: border-box;
  height: 115rpx;
  margin-bottom: 5rpx;
  background-color: #fff;

  .rightIcon {
    display: flex;

    > text {
      font-size: 26rpx;
      margin-right: 5rpx;
      color: rgba(166, 166, 166, 1);
    }

    .iconfont {
      transition: 0.2s all;
      transform: rotate(180deg);

      &.active {
        transform: rotate(0deg);
      }
    }
  }
}

// 二级菜单样式
/deep/ .menuInfo_second_level {
  position: relative;
  width: 100%;
  height: 0rpx;
  overflow: hidden;
  transition: 0.2s all;

  &.active {
    opacity: 0;
  }

  .menuInfo_second_level_item {
    display: flex;
    align-items: center;
    width: 100%;
    height: 115rpx;
    padding: 0 55rpx;
    box-sizing: border-box;
    margin-bottom: 5rpx;
    background-color: #fff;

    &:last-child {
      margin: 0;
    }

    .menuInfo_item {
      display: flex;
      align-items: center;
    }

    .iconfont_nodata {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;

      > text {
        color: #9a9a9a;
      }
    }
  }

  .iconfont_loading {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    width: 80rpx;
    height: 80rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: rotate 1s infinite;

    @keyframes rotate {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }
  }
}
</style>
