<template>
	<view class="chooseDeviceContainier">
		<view class="shopList">
			<checkbox-group @change="checkAllChange">
				<view class="shopItem" v-for="item,index in deviceList" :key="item.store_id">
					<label>
						<checkbox :value="item.store_id" :checked="item.checked"
							color="rgba(38, 79, 247, 1)"
							style="transform:scale(0.7);margin-right: 12upx;" />
						<text
							style="width: 56upx;height: 32upx;line-height:32upx;text-align: center;background-color: #F8D0A3;color: rgba(255, 141, 26, 1);padding: 8upx;margin-right: 20upx;border-radius: 6px;font-size: 20upx;">门店</text>
						<text>{{item.name}}</text>
					</label>
					<checkbox-group @change="checkboxChange($event,item,index)">
						<view class="" v-for="child,index in item.arr" :key="child.code"
							style="display: flex;background-color: #fff;padding: 20upx 40upx;border-radius: 4px;">
							<view style="margin-right: 4upx;">
								<checkbox :value="child.code" :checked="child.checked"
									color="rgba(38, 79, 247, 1)" style="transform:scale(0.7);" />
							</view>
							<view class="">
								<view>
									<text
										style="color: gray;display:inline-block;width: 50upx;text-align: center;margin-right: 10upx;">{{index+1}}</text>
									<text>{{child.code}}</text>
								</view>
							</view>
						</view>
					</checkbox-group>
				</view>
			</checkbox-group>
		</view>
		<view class="btn">
			<button @click="submitDown">确认下发</button>
		</view>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	// uuid生成
	function uuid() {
		var s = [];
		var hexDigits = "0123456789abcdef";
		for (var i = 0; i < 36; i++) {
			s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
		}
		s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
		s[19] = hexDigits.substr((s[19] & 0x3) | 0x8,
			1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
		s[8] = s[13] = s[18] = s[23] = "-";

		var uuid = s.join("");
		return uuid;
	}
	export default {
		computed: {
			...mapState('menus', {
				customer: state => state.customer,
			})
		},
		data() {
			return {
				title: 'checkbox 复选框',
				page: 1,
				deviceList: [],
				deviceTotal: 0,
				chooseMenuList: [],
				org_business_id: '',
				chooseDevice: [],
				checkAll: [],
				totalMenuCount: null
			}
		},
		watch: {
			deviceList: {
				deep: true,
				handler(newValue) {
					// this.checkAll = newValue.map((item) => {
					// 	return item.arr.every(child => child.checked)
					// })
				}
			}
		},
		methods: {
			async getDeviceList(page) {
				uni.showLoading({
					title: '加载中'
				});
				const resultDeviceList = await this.API.home.getNewDevice(this.org_business_id,
					this.page)
				if (resultDeviceList.code == 0) {
					uni.hideLoading();
					this.deviceTotal = resultDeviceList.paging.total_records
					this.deviceList = resultDeviceList.data.reduce((acc, cur) => {
						// cur.uuid = uuid()
						// ------------------
						const index = acc.findIndex(item => item.arr[0].store_id === cur
							.store_id);
						if (index === -1) {
							acc.push({
								'name': cur.store_name,
								'store_id': cur.store_id,
								'checked': false,
								'arr': [cur]
							});
						} else {
							acc[index].arr.push(cur);
						}
						return acc;
					}, []);
					this.deviceList = this.deviceList.map((device) => {
						return {
							...device,
							'arr': device.arr.map((child) => {
								return {
									...child,
									checked: false
								}
							})
						}
					})
					this.checkAll = this.deviceList.map((item) => item.checked)
				}
				// console.log(this.deviceList, '设备列表的数据')
			},
			// 二级菜单样式状态变化
			checkboxChange(e, row, index) {
				// console.log(e, row, '二级变化')
				const {
					value
				} = e.detail
				// 先改变状态
				row.arr.forEach(item => {
					if (value.indexOf(item.code) !== -1) item.checked = true
					else item.checked = false
				})
				// 更新一级菜单状态
				row.checked = row.arr.every(item => item.checked === true)
			},
			// 一级菜单状态变化
			checkAllChange(e) {
				// console.log(e, '一级变化')
				const {
					value
				} = e.detail
				// 更新二级菜单样式
				this.deviceList.forEach(item => {
					if (value.indexOf(item.store_id.toString()) !== -1) item.checked = true
					else item.checked = false
					item.arr.forEach(subItem => {
						subItem.checked = item.checked
					}) // 二级菜单状态
				})
			},
			submitDown() {
				this.chooseDevice = []
				let ar = []
				this.ar = this.deviceList.map((item) => {
					return item.arr.filter((ar) => ar.checked == true)
				})
				this.ar.forEach((item) => {
					item.forEach((el) => this.chooseDevice.push(el))
				})
				this.chooseDevice = this.chooseDevice.map((item) => item.code)
				if (!this.chooseDevice.length) {
					uni.showToast({
						title: '请选择设备',
						icon: 'error'
					})
					return
				}
				uni.showModal({
					title: '菜谱下发确认',
					content: `请确认本次下载${this.totalMenuCount}道菜谱`,
					confirmText: '确定下发',
					// confirmColor:'rgba(38, 79, 247, 1)',
					cancelText: '取消',
					showCancel: true,
					fail: function(res) {
						console.log(res);
					},
					success: function(res) {
						if (res.confirm) {
							var that = this
							uni.showLoading({
								title: '加载中'
							});
							const promises = that.chooseMenuList.map((item) => {
								return that.API.menus.downMenu(item, that
									.chooseDevice.toString())
							})
							Promise.all(promises).then((posts) => {
								uni.hideLoading();
								uni.showToast({
									title: '已下发',
									icon: 'success',
									duration: 1000
								})
								setTimeout(() => {
									uni.switchTab({
										url: '/pages/menus/menus'
									})
								}, 1000)
							}).catch((reason) => {
								console.log(reason)
								uni.showToast({
									title: '下发失败',
									icon: 'error',
									duration: 2000
								})
							});
						} else if (res.cancel) {
							// console.log('用户点击取消');
						}

					}.bind(this)
				})
			},
			async calculateTotalMenuCount() {
				let totalCount = 0;
				for (let id of this.chooseMenuList) {
					const menu = await this.API.menus.getRecipeSubdata(id, this.org_business_id);
					console.log(menu.data);
					totalCount += menu.data.length > 0 ? menu.data.length : 1;
				}
				this.totalMenuCount = totalCount;
			}
		},
		async onLoad(options) {
			this.chooseMenuList = (options.chooseMenu.split(',')).map((item) => item)
			console.log(this.chooseMenuList);
			this.org_business_id = this.customer.org_business_id,
				this.getDeviceList()
			await this.calculateTotalMenuCount();
		}
	}
</script>

<style lang="less" scoped>
	.scroll-Y {
		height: 100%;
		// height: calc(100vh - 0upx  );
	}

	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
	}

	.scroll-view-item {
		width: 702upx;
		height: 100%;
		margin: 0 auto;
		margin-bottom: 24upx;
		border-radius: 10upx;
		background-color: #fff;
		padding: 24upx;
		box-sizing: border-box;
	}

	.chooseDeviceContainier {
		height: 100vh;
		background-color: rgba(245, 245, 245, 1);
		position: relative;

		.btn {
			button {
				background-color: rgba(38, 79, 247, 1);
				width: 686upx;
				height: 80upx;
				border-radius: 875px;
				text-align: center;
				line-height: 80upx;
				margin-top: 20upx;
				margin-bottom: 20upx;
				color: #fff;
			}
		}

		.confirmTip {
			width: 100vw;
			height: 96upx;
			text-align: center;
			line-height: 96upx;
			background-color: rgba(255, 234, 230, 1);
			margin-bottom: 16upx;
			color: rgba(255, 87, 51, 1);
			font-size: 28upx;
		}

		.shopList {
			padding-top: 22upx;
			background-color: #f5f5f5;

			.shopItem {
				width: 734upx;
				margin: 0 auto;
				padding: 32upx;
				box-sizing: border-box;
				border-radius: 6px;
				background-color: #fff;
				margin-bottom: 8upx;
			}
		}

	}
</style>