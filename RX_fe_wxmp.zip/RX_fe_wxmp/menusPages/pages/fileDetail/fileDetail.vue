<template>
	<view class="fileContainer">
		<view class="detailTop">
			<view class="fileTip">
				<text v-if="menuInfo.status">{{menuInfo.status}}</text>
			</view>
			<view class="fileInfo">
				<text v-if="menuInfo.name">{{menuInfo.name}}</text>
				<text v-else>
					<text v-if="menuInfo.recipe_category">{{menuInfo.recipe_category}}</text>
				</text>
				<text v-if="menuInfo.spec">[{{menuInfo.spec}}g/</text>
				<text v-if="menuInfo.copies">{{menuInfo.copies}}份]</text>
			</view>
			<view class="tabList">
				<view v-for="item in tabList" :key="item.id" :class="{tab:true,currentTab:tabIndex==item.id}"
					@click="changeTab(item.id)">
					{{item.name}}
				</view>
			</view>
		</view>
		<view class="lastTab" style="height: 100%;margin-top: 32upx;" v-if="tabIndex=='1'">
			<view class="popup-content" v-for="item in foodList" :key="item.id">
				<div class="boxName">
					<div class="boxNameLeft">
						<image src="../../../static/image/boxPicture.png" mode=""
							style="width:30upx;height:30upx;margin-right: 10px;"></image>
						<text>{{item.action_name}}</text>
					</div>
					<div class="boxNameRight">
						<text @click="toAdd(item,item.food_box.length)"> + 添加食材</text>
					</div>
				</div>
				<uni-collapse ref="collapse" class="foodBoxContainer" accordion v-for="food,index in item.food_box"
					:key="index">
					<uni-collapse-item class="foodBoxItem">
						<template v-slot:title>
							<view
								style="height: 56px;line-height: 56px;display:flex;align-items: center;margin-left: 10px;">
								<view class="chooseName" style="color:gray">{{food.category}}{{index+1}}</view>
							</view>
						</template>
						<view class="foodNameContainer">
							<view class="foodName">
								<text class="food_name_box" v-if="food.food_name"
									style="font-size: 16px;margin-right: 10px;font-weight: bold;">{{food.food_name}}</text>
								<text v-if="food.weight"
									style="color:gray;white-space: nowrap;">（{{food.weight/1000}}g）</text>
								<text v-else style="color:gray;white-space: nowrap;">（0g）</text>
							</view>
							<view class="moreAction">
								<a style="margin-right: 10px;color:rgba(38, 79, 247, 1);"
									@click="editFoodBoxes(food)">编辑</a>
								<a style="color:red;" @click="removeFoodBoxes(food)">删除</a>
							</view>
						</view>
						<view style="background-color: rgba(245, 245, 245, 1);padding: 40upx 16upx;" class=""
							v-if="food.pics.length">
							<uni-swiper-dot style="width:96vh;margin:0 auto;text-align: center;overflow: hidden;"
								v-if="food.pics.length" :info="food.pics" :current="current" field="content"
								mode="indexes">
								<swiper style="height:300upx;margin-bottom: 34upx;" class="swiper-box" @change="change">
									<swiper-item v-for="pic,index2 in food.pics" :key="pic.file_path">
										<view class="swiper-item">
											<!-- 正式 -->
											<image style="width:96vw;height:300upx;border-radius: 8px;" @click="preview(index,index2,food.pics)" :src="`https://admin.renxin-robot.com/enclosure/${pic.file_path}`" mode="aspectFill"></image>
											<!-- 测试 -->
										<!-- 	<image style="width:96vw;height:300upx;border-radius: 8px;"
												@click="preview(index,index2,food.pics)"
												:src="`https://rr.renxin-robot.com/enclosure/${pic.file_path}`"
												mode="aspectFill"></image> -->
										</view>
									</swiper-item>
								</swiper>
							</uni-swiper-dot>
						</view>
						<view class="picturesAndDes" v-if="food.specification">
							<text style="color:gray">切配说明：</text>
							<text>{{food.specification}}</text>
						</view>
					</uni-collapse-item>
				</uni-collapse>
			</view>
			<view class="menuEmpty" v-if="!foodList.length">
				<image src="../../../static/image/emptyRecord.png" mode="" style="width: 298upx;height: 250upx;">
				</image>
				<view class="emptyTip">
					暂无食材
				</view>
			</view>
			<!-- <view class="tableTitle">
				<view class="index">料盒</view>
				<view class="action">食材名称</view>
				<view class="totalTime">重量</view>
			</view>
			<view class="tableItem" v-for="item in newFoodList" :key="item.id">
				<view class="index">
					<text v-if="item.action_name">{{item.action_name}}</text>
				</view>
				<view class="action" v-if="item.food">{{item.food}}</view>
				<view class="totalTime" v-if="item.weight">{{item.weight}}g</view>
			</view>
			<view class="menuEmpty" v-if="!newFoodList.length">
				<image src="../../../static/image/emptyRecord.png" mode="" style="width: 298upx;height: 250upx;">
				</image>
				<view class="emptyTip">
					暂无食材
				</view>
			</view> -->
		</view>

		<view class="lastTab" v-if="tabIndex=='2'">
			<view class="tableTitleContainer">
				<view class="index">调料编号</view>
				<view class="time">调料名称</view>
				<view class="action">重量</view>
			</view>
			<view class="tableItemContainer" v-for="item in flavourList" :key="item.action_code">
				<view class="index">{{item.action_code}}</view>
				<view class="time">{{item.action_name}}</view>
				<view class="action" v-if="item.flavour_weight">{{item.flavour_weight}}g</view>
			</view>
			<view class="menuEmpty" v-if="!flavourList.length">
				<image src="../../../static/image/emptyRecord.png" mode="" style="width: 298upx;height: 250upx;">
				</image>
				<view class="emptyTip">
					暂无配料
				</view>
			</view>
		</view>
		<view class="lastTab" v-if="tabIndex=='3'">
			<view class="tableTitle">
				<view class="index">序号</view>
				<view class="time">时间</view>
				<view class="action">动作/参数 </view>
				<view class="totalTime">持续时间</view>
			</view>
			<!-- 	@touchstart="touchS($event,item)"
			@touchmove="touchM" @touchend="touchE" -->
			<view class="tableItem" id="box_center" v-for="item,index in detailList" :key="item.id" 
		
			>
				<view class="showContainer" :style="{marginLeft:InfoId === item.id?'-'+LeftRange+'rpx':''}">
					<view class="index">{{index+1}}</view>
					<view class="time">
						<text v-if="item.start_millsec==0">0"</text>
						<text v-if="item.startMinutes">{{item.startMinutes}}<text>'</text></text>
						<text v-if="item.startSeconds">{{item.startSeconds}}<text>"</text></text>
					</view>
					<view class="action"
						style="display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp:2;overflow: hidden;">
						<text v-if="item.action_name">
							<text v-if="index==0">开始</text>
							<text v-else-if="index==detailList.length-1">结束</text>
							<text v-else>{{item.action_name}}</text>
						</text>
						<text v-if="item.action_name=='人工投料'">
							<text v-if="item.desc.flavours.length">
								<text v-for="cl,index1 in item.desc.flavours" :key="index1">
									<text v-if="cl.flavour">/{{cl.flavour}}</text>
									<text v-if="cl.weight">（{{cl.weight/1000}}g）</text>
								</text>
							</text>
							<text v-if="item.desc.foods">
								<text v-for="foods,ind in item.desc.foods" :key="ind">
									<text v-if="foods.food">/{{foods.food}}</text>
									<text v-if="foods.weight">（{{foods.weight/1000}}g）</text>
									<text v-else>（0g）</text>
								</text>
							</text>
						</text>
						<text
							v-if="item.action_name=='料盒1'||item.action_name=='料盒2'||item.action_name=='料盒3'||item.action_name=='料盒4'">
							<text v-if="item.desc.flavours">
								<text v-for="cl,index1 in item.desc.flavours" :key="index1">
									<text v-if="cl.flavour">/{{cl.flavour}}</text>
									<text v-if="cl.weight">（{{cl.weight/1000}}g）</text>
								</text>
							</text>
							<text v-if="item.desc.foods">
								<text v-for="foods,ind in item.desc.foods" :key="ind">
									<text v-if="foods.food">/{{foods.food}}</text>
									<text v-if="foods.weight">（{{foods.weight/1000}}g）</text>
									<text v-else>（0g）</text>
								</text>
							</text>
						</text>
						<text v-if="item.flavour_weight">/{{item.flavour_weight}}g</text>
						<text v-if="item.action_code==10000">
							<text v-if="item.power_rate==0&&index!=0&&index!=detailList.length-1">/0档</text>
							<text v-if="item.power_rate==1000">/1档(1000w)</text>
							<text v-if="item.power_rate==2000">/2档(2000w)</text>
							<text v-if="item.power_rate==3000">/3档(3000w)</text>
							<text v-if="item.power_rate==4000">/4档(4000w)</text>
							<text v-if="item.power_rate==4500">/5档(4500w)</text>
							<text v-if="item.power_rate==5000">/6档(5000w)</text>
							<text v-if="item.power_rate==5500">/7档(5500w)</text>
							<text v-if="item.power_rate==6000">/8档(6000w)</text>
							<text v-if="item.power_rate==6500">/9档(6500w)</text>
							<text v-if="item.power_rate==7000">/10档(7000w)</text>
							<text v-if="item.power_rate==8000">/11档(8000w)</text>
						</text>
						<text v-if="item.action_code==20000||item.action_code==20001">
							<text v-if="item.rotate_speed==28000||item.rotate_speed==-28000">/4档(42r/min)</text>
							<text v-else-if="item.rotate_speed==22000||item.rotate_speed==-22000">/3档(33r/min)</text>
							<text v-else-if="item.rotate_speed==14667||item.rotate_speed==-14667">/2档(22r/min)</text>
							<text v-else-if="item.rotate_speed==8667||item.rotate_speed==-8667">/1档(13r/min)</text>
							<text v-else-if="item.rotate_speed==0&&index!=0&&index!=detailList.length-1">/0档</text>
							<text v-else>/({{item.rotate_speed_rpm}}r/min)</text>
						</text>
					</view>
					<view class="totalTime" v-if="item.duration">{{(item.duration/1000).toFixed(1)}}s</view>
				</view>
				<!-- <view class="AddInfo" >
					新增
				</view>
				<view class="EditInfo" >
					编辑
				</view>
				<view class="Delete" >
					删除
				</view> -->
			</view>
			<view v-if="totalTime" style="border:1px solid #EBEEF5;height: 40px;text-align: center;line-height: 40px;">
				<text style="margin-right: 20px;color: gray;">烹饪时间 </text>
				<text v-if="minutes">{{minutes}}<text>分</text></text>
				<text v-if="seconds">{{seconds}}<text>秒</text></text>

			</view>
			<view class="menuEmpty" v-if="!detailList.length">
				<image src="../../../static/image/emptyRecord.png" mode="" style="width: 298upx;height: 250upx;">
				</image>
				<view class="emptyTip">
					暂无工艺
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import {
		mapMutations,
	} from 'vuex'
	export default {
		data() {
			return {
				tabList: [{
						name: '食材',
						id: '1'
					},
					{
						name: '调料',
						id: '2'
					},
					{
						name: '工艺',
						id: '3'
					},
				],
				tabIndex: '1',
				detailList: [],
				minutes: 0,
				seconds: 0,
				startMinutes: 0,
				startSeconds: 0,
				totalTime: 0,
				foodList: [],
				flavourList: [],
				menuInfo: {},
				user_id: '',
				current: 0,
				// fileDetaulInfo:{},
				newFoodList: [],
				// 测试滑动输入条
				rangeMin: 5,
				rangMax: 200,
				rangeValue: [10, 50],
				currentPage: '',
				removeInfo: {},
				allPictures: [],
				// 左滑
				LeftRange: 0, //移动的范围
				startX: 0, //首次点击的位置
				moveX: 0, //滑动时的距离
				InfoId: '',
				
			}
		},
		methods: {
			...mapMutations('menus', ['setFood']),

			changeTab(val) {
				this.tabIndex = val
			},
			format(val) {
				return val + '%'
			},
			handleRangeChange(e) {
				this.rangeValue = e
			},
			async getFileDetail(id) {
				uni.showLoading({
					title: '加载中'
				});
				const res = await this.API.menus.getMenuDetail(id)
				const boxesInfo = await this.API.menus.getBoxes(id)
				if (boxesInfo.code == 200) {
					this.foodList = boxesInfo.data
					if (boxesInfo.data.length) {
						this.user_id = boxesInfo.data[0].user_id
						uni.setStorageSync('user_id', boxesInfo.data[0].user_id)
					}
				}
				if (res.code == 0) {
					uni.hideLoading();
					// console.log(res.data.steps,'res.data.steps')
					this.detailList = res.data.steps?.map((item) => {
						return {
							...item,
							'startMinutes': Math.floor(Math.ceil(item.start_millsec / 1000) / 60),
							'startSeconds': Math.floor(Math.ceil(item.start_millsec / 1000) % 60),
						}
					})
					// console.log(this.detailList.length,'this.detailList')
					// this.foodList = this.detailList.filter((item) => {
					// 	this.totalTime+=item.duration
					// 	return item.action_code == 30000 || item.action_code == 30001 || item.action_code ==
					// 		30002 || item.action_code == 30003
					// })
					// if (this.foodList) {
					// 	this.foodList = this.foodList.map((food) => {
					// 		if (food.desc) {
					// 			return {
					// 				...food,
					// 				foodInfo: food.desc.foods.map((el) => {
					// 					return {
					// 						...el,
					// 						action_name: food.action_name
					// 					}
					// 				})
					// 			}
					// 		} else {
					// 			return {
					// 				...food,
					// 				foodInfo: []
					// 			}
					// 		}

					// 	})
					// 	this.foodList.map((food) => {
					// 		if (food.foodInfo) {
					// 			food.foodInfo.map((item) => {
					// 				if(item.weight){
					// 					item.weight=item.weight/1000
					// 				}
					// 				this.newFoodList.push(item)
					// 			})
					// 		}
					// 	})
					// 	// console.log(this.newFoodList,'food')
					// }
					this.flavourList = this.detailList.filter((item) => {
						return item.action_code > 100000
					})
					this.flavourList = this.flavourList.map((item) => {
						if (item.flavour_weight) {
							item.flavour_weight = item.flavour_weight / 1000
						}
						return item
					})
					if (this.totalTime) {
						this.totalTime = (this.totalTime / 1000).toFixed(1)
						this.minutes = Math.floor(this.totalTime / 60)
						this.seconds = Math.floor(this.totalTime % 60)
					}
				}
			},
			change(e) {
				this.current = e.detail.current;
			},
			editFoodBoxes(row) {
				this.setFood(row)
				uni.navigateTo({
					url: `/menusPages/pages/fileDetail/addFood/addFood?category=${row.category}&food_name=${row.food_name}&id=${row.id}&specification=${row.specification}&recipe_step_id=${row.recipe_step_id}&pics=${row.pics}&weight=${row.weight}`
				})
			},

			toAdd(row, length) {
				if (length >= 20) {
					uni.showToast({
						title: '已达上限',
						icon: 'error',
						duration: 1000
					})
					return
				}
				this.setFood({
					'category': "食材",
					'specification': '',
					'weight': 0,
					'pics': [],
					'recipe_food_id': '',
					'food_name': '',
					'recipe_id': row.recipe_id,
					'recipe_step_id': row.id
				})
				// console.log(length,'料盒信息')
				uni.navigateTo({
					url: `/menusPages/pages/fileDetail/addFood/addFood`
				})
			},
			async confirmRemove() {
				uni.showLoading({
					title: '删除中'
				});
				const removeRes = await this.API.menus.deleteBoxesFood({
					"food_ids": this.removeInfo.id
				}, this.removeInfo.recipe_id, this.removeInfo.recipe_step_id)
				if (removeRes.code == 200) {
					uni.hideLoading();
					uni.showToast({
						title: removeRes.data,
						icon: removeRes.msg,
						duration: 1000
					})
					this.getFileDetail(this.menuInfo.id)
				}
			},
			removeFoodBoxes(row) {
				this.removeInfo = row
				let self = this
				uni.showModal({
					title: '提示',
					content: '确定删除该食材吗？',
					success: async function(res) {
						if (res.confirm) {
							self.confirmRemove()
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				});
			},
			//左滑删除
			touchS(e, item) {
				//更新初始值
				this.LeftRange = 0
				// startX记录开始移动的位置
				if (e.touches.length === 1) {
					this.startX = e.touches[0].clientX
				}
				//移动列表某个 防止v-for循环整体循环
				this.InfoId = item.id
			},
			touchM(e) {
				//滑动时判断是否为初始值
				if (this.LeftRange === 430) {
					return
				} else {
					if (e.touches.length === 1) {
						//手指移动时水平方向位置
						this.moveX = e.touches[0].clientX
						//判断移动的距离是变大变小 变大便是右移
						if (this.startX < this.moveX) {
							//更改移动时的距离。防止弹出删除按钮
							this.moveX = 0
						} else {
							//移动的距离 加 20 如需调整 可以调整这里
							this.LeftRange += 20
							if (this.LeftRange > 300) {
								//如果大于430 则直接等于300
								this.LeftRange = 400
							}
						}
			
					}
				}
			},
			touchE(e) {
				//如果滑动的距离大于45  则直接弹出删除按钮
				if (this.moveX > 45) {
					this.LeftRange = 400
				}
				//松开后刷新 滑动的距离
				this.moveX = 0
			},
			// 大图预览
			preview(index, index2, row) {
				this.allPictures = []
				this.foodList?.map((item) => {
					item.food_box.map((child) => {
						child.pics.map((last) => {
							this.allPictures.push(last.file_path)
						})
					})
				})

				let lastIndex = index + index2
				// 调用uni.previewImage()方法,传递index
				uni.previewImage({
					current: lastIndex,
					// 返回所有图片的url地址数组 `https://rr.renxin-robot.com/enclosure/`
					urls: this.allPictures.map((item) => `${this.$baseUrl}/enclosure/${item}`)
				});
			}
		},

		onLoad(options) {
			this.menuInfo = JSON.parse(options.menuInfo)
			// console.log(this.menuInfo,'this.menuInfo')
			if (this.menuInfo) {
				this.getFileDetail(this.menuInfo.id)
			}
		},
		onShow() {
			this.getFileDetail(this.menuInfo.id),
				// 手动刷新collapse的容器高度
				this.$nextTick(() => {
					if (this.$refs.collapse) {
						this.$refs.collapse.map((item) => {
							item.resize()
						})
					}
				})
		}
	}
</script>

<style lang="less" scoped>
	.popup-content {
		overflow-y: scroll;
		background-color: #fff;

		.boxName {
			display: flex;
			align-items: center;
			justify-content: space-between;
			height: 112upx;
			padding: 0px 10px;
			border-bottom: 1px solid rgba(0, 0, 0, 0.1);

			.boxNameRight {
				color: rgba(38, 79, 247, 1);
			}
		}

		.foodBoxContainer {

			.foodNameContainer {
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-top: 1px solid rgba(0, 0, 0, 0.1);

				.foodName {
					width: 76%;
					margin-left: 10px;
					min-height: 94upx;
					display: flex;
					align-items: center;
					flex-wrap: wrap;
					white-space: normal;
					word-break: break-all;
					word-warp: break-word;

					// overflow: hidden;
					// text-overflow: ellipsis; /* 设置文本溢出时显示省略号 */
					// white-space: nowrap;
					.food_name_box {
						white-space: normal;
						word-break: break-all;
						word-warp: break-word;

					}
				}

				.moreAction {
					margin-right: 10px;
					display: flex;

					.actionBox {
						z-index: 999;
					}
				}
			}

			.foodBoxItem {}
		}

	}

	.fileContainer {
		width: 100%;
		height: 100vh;
		overflow-x: hidden;
		background-color: rgba(245, 245, 245, 1);

		.detailTop {
			width: 100vw;
			// height: 112upx;
			padding: 14upx 40upx;
			box-sizing: border-box;
			background-color: #fff;
			text-align: center;
			box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.25);

			.tabList {
				width: 432upx;
				margin: 0 auto;
				margin-top: 18upx;
				display: flex;
				justify-content: space-between;
				font-size: 32upx;
				color: gray;

				.tab {
					padding-bottom: 10upx;
				}

				.currentTab {
					color: rgba(38, 79, 247, 1);
					border-bottom: 1px solid rgba(38, 79, 247, 1);
				}
			}

			.fileTip {
				margin-bottom: 14upx;
				color: rgba(38, 79, 247, 1);
			}

			.fileInfo {
				font-size: 28upx;
				color: gray;
				margin-bottom: 12upx;
			}

			.fileCode {
				font-size: 28upx;
				color: rgba(166, 166, 166, 1);
			}
		}

		.lastTab {
			.tableTitleContainer {
				display: flex;
				height: 112upx;
				padding: 0upx 18upx;
				box-sizing: border-box;
				line-height: 112upx;
				color: rgba(166, 166, 166, 1);

				.index {
					width: 30%;
				}

				.time {
					width: 30%;
				}

				.action {
					flex-grow: 1;
				}
			}

			.tableTitle {
				display: flex;
				height: 112upx;
				padding: 0upx 18upx;
				box-sizing: border-box;
				line-height: 112upx;
				color: rgba(166, 166, 166, 1);

				.index {
					width: 13%;
				}

				.time {
					width: 16%;
				}

				.totalTime {
					width: 20%;
				}

				.action {
					flex-grow: 1;
				}
			}

			.menuTotalTime {
				height: 112upx;
				padding: 0upx 18upx;
				box-sizing: border-box;
				line-height: 112upx;
				background-color: #fff;
				text-align: center;
			}

			.menuEmpty {
				// width: 298upx;
				text-align: center;
				margin: 0 auto;
				margin-top: 20upx;
				// background-color: #fff;
				padding: 20px;

				.emptyTip {
					font-size: 24upx;
					color: rgba(166, 166, 166, 1);
					margin-top: 48upx;
				}
			}

			.tableItemContainer {
				display: flex;
				height: 112upx;
				padding: 0upx 18upx;
				box-sizing: border-box;
				line-height: 112upx;
				background-color: #fff;
				border-bottom: 1px solid #F6F6F6;

				.index {
					width: 30%;
				}

				.time {
					width: 30%;
				}

				.action {
					flex-grow: 1;
				}
			}

			.tableItem {
				display: flex;
				min-height: 112upx;
				padding: 0upx 18upx;
				box-sizing: border-box;
				// line-height: 112upx;
				align-items: center;
				background-color: #fff;
				position: relative;
				border-bottom: 1px solid #F6F6F6;
				.Delete {
					width: 128rpx;
					height: 112upx;
					// margin-left: 20px;
					background: rgba(238, 10, 36, 1);
					margin-right: -430rpx;
					display: flex;
					align-items: center;
					justify-content: center;
					font-size: 22rpx;
					font-weight: 400;
					color: #ffffff;
				}
				
				.EditInfo {
					width: 128rpx;
					height: 112upx;
					background: rgba(255, 125, 0, 1);
					display: flex;
					align-items: center;
					justify-content: center;
					font-size: 22rpx;
					font-weight: 400;
					color: #ffffff;
				}
				.AddInfo {
					width: 128rpx;
					height: 112upx;
					background: rgba(22, 93, 255, 1);
					display: flex;
					align-items: center;
					justify-content: center;
					font-size: 22rpx;
					font-weight: 400;
					color: #ffffff;
				}
				.showContainer {
					height: 100%;
					width: 100%;
					display: flex;
					// flex-direction: column;
					// justify-content: space-evenly;
					
					.index {
						width: 15%;
					}

					.time {
						width: 20%;
					}

					.index {
						color: rgba(166, 166, 166, 1);
					}

					.totalTime {
						width: 16%;
					}

					.action {
						flex-grow: 1;
						width: 70%;
					}
				}

			}
		}


	}
</style>