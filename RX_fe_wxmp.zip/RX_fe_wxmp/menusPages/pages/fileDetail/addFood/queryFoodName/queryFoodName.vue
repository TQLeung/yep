<template>
	<view class="queryBox">
		<view class="searchContainer">
			<view class="inputBox">
				<view class="boxLeft" style="width: 90%;">
					<image src="../../../../../static/image/querySearch.png" mode=""
						style="width: 36upx;height: 40upx;margin-right: 16upx;"></image>
					<input v-model="queryName" style="width: 84%;" maxlength="30"  @input="getName" placeholder-style="font-size:24upx;" type="text"
						:placeholder="`搜索${foodInfos.category}名称`">
				</view>
				<image v-if="queryName" @click="clearName" src="../../../../../static/image/clear.png"
					style="width: 26upx;height: 26upx;margin-right: 26upx;" mode=""></image>
			</view>
		</view>
		<view class="listContainer">
			<scroll-view v-if="true" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y list"
				@scrolltolower="lower">
			<view class="varietyContainer" v-if="varietyCount">
				<view class="varietyItem" @click="chooseFood(item)" v-for="item,index in foodsData" :key="index">
						<view class="varietyName">
							<!-- <text>{{foodInfos.category}}名称：</text> -->
							<text style="word-break: break-all;">{{item.name}}</text>
						</view>
				</view>
			</view>
			<view class="menuEmpty" v-else>
				<image src="../../../../../static/image/menuEmpty.png" mode="" style="width: 298upx;height: 250upx;"></image>
				<view class="emptyTip">
					{{showEmpty}}
				</view>
				<view class="btn">
					<button @click="toAddNew" style="background-color: rgba(38, 79, 247, 1);margin-top: 10px;border-radius:875px;color: #fff;">
						去新增
					</button>
				</view>
			</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	import {mapState,mapMutations } from 'vuex'
	export default {
		// 引入vuex中的state值
		computed: {
					...mapState('menus', ['foodInfos']),
				},
		data() {
			return {
				queryName: '',
				placeText: '搜索食材名称',
				account_id: uni.getStorageSync('userInfo').account_id,
				user_id:uni.getStorageSync('user_id'),
				foodsData:[],
				varietyCount: 0,
				page: 1,
				showEmpty: '暂未搜索到您想要的',
				size:20,
				pages:0,
				foodInfo:{}
			}
		},
		 
		 onReady(){
		 	 uni.setNavigationBarTitle({
		         title: `选择${this.foodInfos.category}`
		      });
		 },

		methods: {
			...mapMutations('menus', ['setFood']),
			// 获取食材库
			async getFoodsData(page,all){
				if(this.foodInfos.category=='调料'){
					const flavoursRes= await this.API.menus.getFlavours(this.user_id,page,this.size,this.queryName,all)
					if(flavoursRes.code==0){
						this.varietyCount = flavoursRes.paging.total_records
						// this.pages=
						if (this.foodsData.length >= this.varietyCount) {
							return
						} else {
							this.foodsData = [...this.foodsData, ...flavoursRes.data]
						}
					}
				}else{
					const res= await this.API.menus.getFoods(this.user_id,page,this.size,this.queryName,all)
					if(res.code==0){
						this.varietyCount = res.paging.total_records
						if (this.foodsData.length >= this.varietyCount) {
							return
						} else {
							this.foodsData = [...this.foodsData, ...res.data]
						}
					}
				}
				
			},
			lower: function(e) {
				if (this.foodsData.length >= this.varietyCount) {
					return
				} else {
					this.page=this.page+2
					this.getFoodsData(this.page)
				}
			},
			// 获取搜索名称
			getName(e) {
				this.foodsData=[]
				this.queryName = e.target.value
				this.getFoodsData(1,true)
				if(this.queryName.length==30){
					uni.showToast({
						title: '不可超过30字！',
						icon: 'error',
						duration: 1000
					})
				}
			},
			clearName() {
				this.queryName = ''
				this.getFoodsData(1,false)
			},
			// 选择食材/调料
			chooseFood(row){
				this.queryName=row.name
				this.foodInfo.food_name=row.name
				if(this.foodInfos.category=='调料'){
					this.foodInfo.recipe_food_id=row.code
				}else{
					this.foodInfo.recipe_food_id=row.id
				}
				this.setFood(this.foodInfo)
				// console.log(this.foodInfos,'this.foodInfos')
				uni.navigateBack()
			},
			// 去新增新食材或者新调料
			async toAddNew(){
					this.foodInfo.food_name=this.queryName
					if(this.foodInfo.category=='调料'){
						const addFlavourRes=await this.API.menus.addFlavour({'user_id':this.user_id,'name':this.queryName})
						if(addFlavourRes==0){
							this.foodInfo.recipe_food_id=addFlavourRes.data
						}
					}else{
						const addFoodRes=await this.API.menus.addFood({'user_id':this.user_id,'foods':this.queryName})
						if(addFoodRes==0){
							this.foodInfo.recipe_food_id=addFlavourRes.data[0]
						}
					}
					this.setFood(this.foodInfo)
					uni.navigateBack()
			}
		},
		onLoad() {
			this.foodInfo=this.foodInfos
			this.getFoodsData(this.page,false)
		}
	}
</script>

<style lang="less" scoped>
.queryBox{
	height: 100vh;
	background-color: rgba(245, 245, 245, 1);
	.menuEmpty {
		width: 298upx;
		text-align: center;
		margin: 0 auto;
		margin-top: 254upx;
	
		.emptyTip {
			font-size: 24upx;
			color: rgba(166, 166, 166, 1);
			margin-top: 48upx;
		}
	}
	.scroll-Y {
			height: calc(100vh);
			background-color: #fff;
			// position: absolute;
			.varietyContainer{
				width: 100vw;
				.varietyItem{
					min-height: 112upx;
					// line-height: 112upx;
					display: flex;
					align-items: center;
					padding: 0upx 20upx;
					border-bottom: 1px solid rgba(0, 0, 0, 0.1);
				}
			}
		}
	.searchContainer {
		width: 100%;
		height: 112upx;
		background-color: #fff;
		// margin-top: 88px;
		padding: 24upx 52upx 24upx 30upx;
		box-sizing: border-box;
		// position: fixed;
		z-index: 99;
		.inputBox {
			display: flex;
			align-items: center;
			justify-content: space-between;
			width: 100%;
			height: 64upx;
			border-radius: 16px;
			padding-left: 22upx;
			background-color: rgba(245, 245, 245, 1);
	
			.boxLeft {
				display: flex;
				align-items: center;
			}
		}
	}
}
</style>
