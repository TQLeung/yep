<template>
	<view class="addContainer">
		<view class="chooseCategory">
			<view class="addTitle">
				选择库
			</view>
			<view class="select">
				<picker @change="bindCategoryChange" :value="index" :range="categoryList">
					<view class="categoryInfo">
						<view class="version" style="color:gray;">
							{{categoryList[categoryIndex]}}
						</view>
						<text class="iconfont icon-xiangyou"
							style="color:gray;margin-left: 4px;position: relative;top:2px;"></text>
					</view>
				</picker>
			</view>
		</view>
		<view class="chooseCategory">
			<view class="addTitle" style="width: 100px;">
				选择<text v-if="categoryIndex=='0'">食材</text><text v-else>调料</text>
			</view>
			<view class="select" style="word-break:break-all;text-align: right;" @click="toQueryFoodName">
				<view class="categoryInfo">
					<view class="version" style="color:gray;">
						{{foodInfo.food_name}}
					</view>
					<text class="iconfont icon-xiangyou"
						style="color:gray;margin-left: 4px;position: relative;top:2px;"></text>
				</view>
			</view>
		</view>
		<view class="chooseCategory">
			<view class="addTitle">
				输入重量
			</view>
			<view class="select">
				<view class="categoryInfo">
					<view class="version" style="color:gray;display: flex;">
						<!-- <uni-number-box :value="1.1" :step="0.1" /> -->
						<input class="uni-input" type="digit" placeholder="重量..." @input="changeFoodWeight"
							style="width: 200upx;text-align: right;" v-model="foodWeight" focus />
						<!-- <input type="number" style="width: 200upx;text-align: right;" @input="changeFoodWeight" class="uni-input" v-model="foodWeight" focus placeholder="重量..." /> -->
						<text>g</text>
					</view>
				</view>
			</view>
		</view>
		<view class="desTitle">
			<text>切配说明</text>
		</view>
		<view class="" style="position:relative;">
			<textarea maxlength="1000" class="desBox" @blur="bindTextAreaBlur" v-model="foodInfo.specification"
				auto-height placeholder="请输入食材切配说明" />
			<view class="" style="position: absolute;bottom: 4px;right: 20px;color: gray;">
				<text v-if="foodInfo.specification">{{foodInfo.specification.length}}</text>
				<text v-else>0</text>
				/1000
			</view>
		</view>
		<view class="desTitle">
			<text>切配说明配图</text>
		</view>
		<uni-section title="只选择图片" type="line" style="margin-left: 20upx;">
			<view class="example-body">
				<uni-file-picker limit="5" :sourceType="['album','camera']" :sizeType="['original', 'compressed']" :value="fileList" @delete="deletePicture"
					@select="select"></uni-file-picker>
			</view>
		</uni-section>
		<view class="" style="margin-top: 10px;font-size: 12px;color:gray;margin-left: 20upx;">
			最多上传5张图,建议尺寸比例16：9
		</view>
		<view class="saveBtnContainer">
			<button class="saveBtn" @click="saveFoodInfo">保 存</button>
		</view>
	</view>
</template>

<script>
	import {
		mapMutations,
		mapState
	} from 'vuex'
	import FormData from '../../../../uilts/formdata'
	export default {
		// 引入vuex中的state值
		computed: {
			...mapState('menus', ['foodInfos', 'menuInfo']),
		},
		data() {
			return {
				categoryList: ['食材库', '调料库'],
				categoryIndex: 0,
				foodInfo: {},
				foodWeight: 0,
				account_id: uni.getStorageSync('userInfo').account_id,
				user_id: uni.getStorageSync('user_id'),
				formData: {},
				pictures: [],
				fileList: [],
				imageUrl: '',
				maxLength: 5,
				count:0
			}
		},
		methods: {
			...mapMutations('menus', ['setFood']),
			toUpload() {
				uni.chooseImage({
					count: 6, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album', 'camera'], //从相册选择
					success: function(res) {
						console.log(JSON.stringify(res.tempFilePaths), res);
					}
				});
			},
			// 切换食材来源库
			bindCategoryChange(e) {
				this.categoryIndex = e.detail.value
				if (this.categoryIndex == 1) {
					this.foodInfo.category = '调料'
				} else {
					this.foodInfo.category = '食材'
				}
				this.setFood(this.foodInfo)
			},
			// 校验是否是数值
			validateInput(val) {
				const regExp = /^(?:[1-9]\d{0,3}|[1-4]\d{0,2}\.\d|500\.[0])$/; // 定义正则表达式

				return regExp.test(val); // 返回true或false判断输入是否符合要求
			},
			// 改变食材重量
			changeFoodWeight(e) {
				let that = this;
				let price = e.detail.value
				let maxLength = price.indexOf('.');
				if (price.indexOf(".") < 0 && price != "") {
					if (price.length > 4) {
						price = price.substring(0, price.length - 1)
						uni.showToast({
							title: '重量不超过9999g',
							icon: 'none'
						})
					} else {
						price = parseFloat(price);
					}
				} else if (price.indexOf(".") == 0) {
					//'首位小数点情况'
					price = price.replace(/[^$#$]/g, "0.");
					price = price.replace(/\.{1,}/g, ".");
				} else if (!(/^(\d?)+(\.\d{0,1})?$/.test(price))) {
					//去掉最后一位
					price = price.substring(0, price.length - 1)
				}
				that.$nextTick(function() {
					//'有小数点时，最大长度为7位，没有则是5位'
					that.maxLength = maxLength == -1 ? 5 : 6
					that.foodWeight = price
				})

			},
			// 改变切配说明
			bindTextAreaBlur: function(e) {
				console.log(e.detail.value)
			},
			// 改变图片
			// 获取上传状态
			select(e) {
				uni.showLoading({
					title: "保存图片中"
				});
				e.tempFilePaths.forEach((tempFilePath,index) => {
					const uploadTask = uni.uploadFile({
						url: `${this.$baseUrl}/mam/enclosure/upload`, //仅为示例，非真实的接口地址
						name: 'file',
						filePath: tempFilePath,
						header: {
							"x-renxin-token": uni.getStorageSync('token'),
						},
						formData: {
							'business_type': '菜谱文件_料盒_食材_图片'
						},
						complete: ()=> {
							this.count=this.count+1
							// console.log(this.count,'aaaaaaa')
							if(this.count==e.tempFilePaths.length){
								uni.hideLoading()
								this.count=0
								// console.log('请求全部完成了')
							}
						},
						success: (uploadFileRes) => {
							if(uploadFileRes.statusCode==200){
								const res = JSON.parse(uploadFileRes.data)
								if (res.code == 200) {
									this.pictures.push({
										'id': res.data[0].id,
										// 'url': `https://rr.renxin-robot.com/enclosure/${res.data[0].file_path}`,
										'url': tempFilePath,
										// https://admin.renxin-robot.com
										'tempFilePaths': tempFilePath,
										'extname': res.data[0].file_suffix,
										'name': res.data[0].file_suffix,
									})
								
								}
							}else{
								e.tempFilePaths=e.tempFilePaths.filter((path)=>{
									return path!=tempFilePath
								})
									uni.showToast({
										icon:'error',
										title:'图片最大10MB',
										duration:1000
									})
								}
						},
						
					});
					
				})

			},
			deletePicture(e) {
				console.log(e,'删除得那张图片')
				this.fileList = this.fileList.filter((item) => item.url !== e.tempFilePath)
				this.pictures = this.pictures.filter((pic) => pic.tempFilePaths !== e.tempFilePath)
				let allPicArr=[...this.fileList,...this.pictures]
				let newArr=[]
				allPicArr.forEach((itemPic)=>{
					let flag=true
					newArr.forEach((newPic)=>{
						if(itemPic.id==newPic.id){
							flag=false
						}
					})
					if(flag){
						newArr.push(itemPic)
					}
				})
				this.fileList=newArr
				console.log(newArr,'this.newArr')
				console.log(this.pictures,'this.pictures')
				console.log(this.fileList,'this.fileList')
			},
			// 保存新增食材
			async saveFoodInfo() {
				if (!this.foodInfo.food_name) {
					uni.showToast({
						title: `未选择${this.foodInfo.category}`,
						icon: 'error',
						duration: 1000
					})
					return
				}
				if (!this.foodWeight) {
					this.foodInfo.weight = 0
				}
				uni.showLoading({
					title: '保存中'
				});
				this.foodInfo.weight = this.foodWeight * 1000
				if (this.foodInfo.pics.length) {
					this.fileList.map((item) => {
						this.pictures.push({
							'id': item.id,
							'url': `${this.$baseUrl}/enclosure/${item.file_path}`
						})
					})
				}
				this.pictures = this.pictures.map((item) => {
					return item.id
				})
				let newArr = []
				this.pictures.forEach((v, i) => {
					var bool = this.pictures.indexOf(v, i + 1); //从传入参数的下一个索引值开始寻找是否存在重复
					if (bool === -1) {
						newArr.push(v);
					}
				})
				this.foodInfo.pics = newArr.toString()
				if (this.foodInfo.category == '调料') {
					const flavoursRes = await this.API.menus.getFlavours(this.user_id, 1, 20, this.foodInfo.food_name,
						true)
					if (flavoursRes.code == 0) {
						if (flavoursRes.paging.total_records == 0) {
							const addFlavourRes = await this.API.menus.addFlavour({
								'user_id': this.user_id,
								'name': this.foodInfo.food_name
							})
							if (addFlavourRes == 0) {
								this.foodInfo.recipe_food_id = addFlavourRes.data
								this.setFood(this.foodInfo)
							}
						} else {
							this.foodInfo.recipe_food_id = flavoursRes.data[0].code
							this.setFood(this.foodInfo)
						}
					}
				} else {
					// 先查询食材库中是否已有该食材
					const foodRes = await this.API.menus.getFoods(this.user_id, 1, 20, this.foodInfo.food_name, true)
					if (foodRes.code == 0) {
						// 如果没有去新增
						if (foodRes.paging.total_records == 0) {
							const addFoodRes = await this.API.menus.addFood({
								'user_id': this.user_id,
								'foods': this.foodInfo.food_name
							})
							if (addFoodRes.code == 0) {
								this.foodInfo.recipe_food_id = addFoodRes.data[0]
								this.setFood(this.foodInfo)
							}
						} else {
							this.foodInfo.recipe_food_id = foodRes.data[0].id
						}
					}

				}
				if (this.foodInfo.id) {
					const updateFoodRes = await this.API.menus.updateBoxesFood([{
						'id': this.foodInfo.id.toString(),
						'category': this.foodInfo.category,
						'food_name': this.foodInfo.food_name,
						'specification': this.foodInfo.specification,
						'weight': this.foodInfo.weight,
						'recipe_food_id': this.foodInfo.recipe_food_id.toString(),
						'pics': this.foodInfo.pics,
					}], this.foodInfo.recipe_id, this.foodInfo.recipe_step_id)
					if (updateFoodRes.code == 200) {
						uni.hideLoading();
						uni.showToast({
							title: updateFoodRes.data,
							icon: updateFoodRes.msg,
							duration: 1000
						})
						setTimeout(() => {
							uni.navigateBack()
						}, 1000)
					}
				} else {
					const addFoodRes = await this.API.menus.addBoxesFood([{
						'category': this.foodInfo.category,
						'specification': this.foodInfo.specification,
						'food_name': this.foodInfo.food_name,
						'weight': this.foodInfo.weight,
						'recipe_food_id': this.foodInfo.recipe_food_id.toString(),
						'pics': this.foodInfo.pics,
					}], this.foodInfo.recipe_id, this.foodInfo.recipe_step_id)
					if (addFoodRes.code == 200) {
						uni.hideLoading();
						uni.showToast({
							title: addFoodRes.data,
							icon: addFoodRes.msg,
							duration: 1000
						})
						setTimeout(() => {
							uni.navigateBack()
						}, 1000)
					} else {
						uni.showToast({
							title: addFoodRes.msg,
							icon: 'error',
							duration: 1000
						})
					}
				}

			},
			// 去选择食材、调料页面
			toQueryFoodName() {
				uni.navigateTo({
					url: `/menusPages/pages/fileDetail/addFood/queryFoodName/queryFoodName`,

				})
			},
		},
		onLoad(options) {
			this.foodInfo = this.foodInfos
			// this.user_id=
			if (this.foodInfo.pics.length) {
				this.foodInfo.pics.map((item) => {
					this.fileList.push({
						'name': item.file_name,
						'url': `${this.$baseUrl}/enclosure/${item.file_path}`,
						'extname': item.file_suffix,
						'id': item.enclosure_id
					})
				})
			}

			if (this.foodInfo.weight) {
				this.foodWeight = this.foodInfo.weight / 1000
			}
			if (this.foodInfo.specification == 'null') {
				this.foodInfo.specification = ''
			}
			if (this.foodInfo.category == '调料') {
				this.categoryIndex = 1
			} else {
				this.categoryIndex = 0
			}
		},
	}
</script>

<style scoped lang="less">
	.addContainer {
		height: 100%;
		padding-bottom: 20px;
		background-color: rgba(245, 245, 245, 1);

		.desTitle {
			height: 112upx;
			color: gray;
			line-height: 112upx;
			padding: 0upx 20upx;
		}

		.saveBtnContainer {
			.saveBtn {
				width: 90vw;
				height: 80upx;
				line-height: 80upx;
				margin-top: 20px;
				margin-bottom: 20px;
				background-color: rgba(38, 79, 247, 1);
				border-radius: 875px;
				color: #fff;
			}
		}

		.desBox {
			background-color: #fff;
			min-height: 400upx;
			width: 96vw;
			margin: 0 auto;
			padding: 20upx 20upx;
			padding-bottom: 40upx;
			box-sizing: border-box;
			border: 1px solid rgba(217, 217, 217, 1);
		}

		.chooseCategory {
			height: 112upx;
			background-color: #fff;
			border-bottom: 1px solid rgba(0, 0, 0, 0.1);
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 0upx 20upx;

			.select {
				.categoryInfo {
					display: flex;
					align-items: center;
					justify-content: end;
				}
			}
		}
	}
</style>