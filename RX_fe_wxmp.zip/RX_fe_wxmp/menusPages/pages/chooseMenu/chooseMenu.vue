<template>
	<view class="chooseMenu">
		<view class="searchBox" style="position: relative;">
			<input class="uni-input" focus placeholder="搜索菜品名称" type="text"
				:value="menuCategoryName" @input="queryMenu" />
			<uni-icons style="position: absolute;right: 120upx;z-index: 9999;" type="clear"
				size="16" v-if="menuCategoryName" @click="clearIcon"></uni-icons>
		</view>
		<view class="menuContainer" v-if="menuCount">
			<view class="checkGroup">
				<checkbox-group @change="changeCheckBox">
					<view class="menuLabel" v-for="(item, index) in menuList" :key="item.id">
						<!-- 一级菜单 -->
						<view class="menuLabel_stair" @tap.stop="controlAdjustment(index)">
							<label @tap.stop="" class="menuLabel_stair">
								<checkbox :value="item.id" :checked="item.checked"
									color="rgba(38, 79, 247, 1)" style="transform:scale(0.7);" />
								<view class="menuItem">
									<view class="menuInfo">
										<view class="tag">菜品</view>
										<view class="menuTitle">
											<!-- <text style="margin-right: 20upx;" v-if="menuCategoryName" v-html="brightenKeyword(item.name,keyWord)"></text> -->
											<!-- <text v-else>{{item.name}}</text> -->
											<text v-for="(v,i) in item.bringtKeyList" :key="i"
												:style="{color:`${v.color}`}">{{v.value}}</text>
										</view>
									</view>
								</view>
							</label>

							<!-- 右侧图标 -->
							<view class="rightIcon">
								<text>{{item.recipe_num}}</text>
								<view
									:class="{iconfont: true, active: secondaryControl === index }">
									<uni-icons type="bottom" color="rgba(38, 79, 247, 1)"
										size="18"></uni-icons>
								</view>
							</view>
						</view>

						<!-- 二级菜单 -->
						<view :class="{menuInfo_second_level: true, active: item.loading}"
							:style="[secondaryControl === index && !item.loading ? { height: `${ 120 * item.twoChildren.length }rpx` } : { height: '0rpx' }]">
							<checkbox-group @change="changeCheckBoxItem">
								<view class="menuInfo_second_level_item"
									v-for="subItem,subIndex in item.twoChildren"
									:key="subItem.recipe_id">
									<template v-if="subItem.recipe_id">
										<label class="menuInfo_item">
											<checkbox :value="subItem.recipe_id"
												:checked="subItem.checked"
												color="rgba(38, 79, 247, 1)"
												style="transform:scale(0.7);" />
											<view class="tag"
												style="color: gray;margin-right: 20upx;margin-left: 20upx;">
												菜谱{{subIndex+1}}</view>
											<view class="menuTitle">
												<text
													style="margin-right: 20upx;">{{subItem.name}}</text>
												{{subItem.spec}}g/{{subItem.copies}}份
											</view>
										</label>
									</template>
									<template v-else>
										<view class="iconfont_nodata">
											<uni-icons type="info" color="#9a9a9a"
												size="28"></uni-icons>
											<text>暂无数据</text>
										</view>
									</template>
								</view>
							</checkbox-group>
						</view>
						<!-- 过度效果 -->
						<view :class="{menuInfo_second_level: true}"
							:style="[item.loading ? { height: `120rpx` } : { height: '0rpx' }]">
							<view class="iconfont_loading">
								<uni-icons type="spinner-cycle" color="#9a9a9a"
									size="48"></uni-icons>
							</view>
						</view>
					</view>
				</checkbox-group>
			</view>

		</view>
		<view class="menuEmpty" v-else>
			<image src="../../../static/image/menuEmpty.png" mode=""
				style="width: 298upx;height: 250upx;"></image>
			<view class="emptyTip">
				暂无可下载菜谱
			</view>
		</view>
		<!-- 底部控件 -->
		<view class="menuBottom">
			<view class="checkboxAll">
				<checkbox-group @change="changeAll">
					<checkbox value="all" :checked="checkAll" color="rgba(38, 79, 247, 1)"
						style="transform:scale(0.7);" />
					<text style="color:rgba(38, 79, 247, 1);">全选</text>
				</checkbox-group>
			</view>
			<view class="count" style="color:rgba(128, 128, 128, 1);">
				已选菜谱{{chooseMenuCount}}/{{menuCount}}
			</view>
			<view class="nextBtn">
				<button @click="toChooseDevice">下一步</button>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapMutations,
		mapState
	} from 'vuex'

	export default {
		computed: {
			...mapState('menus', {
				customer: state => state.customer,
				menusListContent: state => state.menusListContent,
				allMenus: state => state.allMenus,
			})
		},
		data() {
			return {
				menuCount: 0,
				value: ['0'],
				menuList: [],
				checkAll: false,
				org_business_id: '',
				chooseMenuList: [],
				oldChooseMenuList: [],
				chooseMenuCount: 0,
				menuCategoryName: '',
				keyWord: '',
				allMenuCount: 0,
				secondaryControl: '', // 二级菜单控件
				loadingTime: null // 过度时间 
			}
		},
		watch: {
			menuList: {
				deep: true,
				handler(newValue) {
					this.checkAll = newValue.every(item => item.checked)
				}
			}
		},
		methods: {
			...mapMutations('menus', ['setMenusListContent', 'setAllMenus']),
			async getTotal() {
				const res = await this.API.menus.getMenuTotal(this.org_business_id)
				this.menuCount = res.paging.total_records
				console.log(res, 'res')
			},
			async getMenuListData() {
				uni.showLoading({
					title: '加载中'
				});
				// if(this.menusListContent.length){
				// 	this.menusListContent.forEach((menu)=>{
				// 		if(this.chooseMenuList.indexOf(menu)==-1){
				// 			this.chooseMenuList.push(menu)
				// 		}
				// 	})
				// }
				// this.setMenusListContent(this.chooseMenuList)
				// console.log(this.menusListContent,'menusListContent')
				// console.log(this.chooseMenuList,'chooseMenuList请求接口')
				const res = await this.API.menus.getVarietyList(1, this.org_business_id, this
					.menuCategoryName, '1', undefined, true)
				if (res.code == 0) {
					// let menuCount = 0
					this.oldChooseMenuList = [];
					this.menuList = res.data.map((el) => {

						// menuCount += el.recipe_num;
						let checked = false;
						this.chooseMenuList.map((chooseId) => {
							if (chooseId === el.id) {
								checked = true;
								this.oldChooseMenuList.push(chooseId);
							}

						})
						return {
							...el,
							bringtKeyList: (el.name.split('')).map((item) => {
								return {
									'value': item,
									'color': 'rgba(0, 0, 0, 1)'
								}
							}),
							checked: checked,
							loading: false, // 过度效果
							twoChildren: [] // 二层数据
						}
					})
					// uni.setStorageSync('allMenuCount', tokenValue)
					this.chooseMenuList.forEach(async (choose) => {
						this.menuList = await Promise.all(this.menuList.map(async (
							menu) => {
							if (menu.id == choose) {
								return {
									...menu,
									checked: true
								};
							} else {
								const menu1 = await this.API.menus
									.getRecipeSubdata(menu.id, this
										.org_business_id);
								const allMatch = menu1.data.every(
									item => this.chooseMenuList
									.includes(item.recipe_id));
								if (allMatch) {
									return {
										...menu,
										checked: true
									};
								} else {
									return menu;
								}
							}
						}));
					});


					console.log(this.menuList, 'this.menuList')
					if (this.menuCategoryName) {
						this.menuList.forEach((menu) => {
							menu.bringtKeyList.forEach((key) => {
								if (this.menuCategoryName.indexOf(key.value) != -
									1) {
									key.color = 'rgba(255, 125, 0, 1)'
								} else {
									key.color = 'rgba(0, 0, 0, 1)'
								}
							})
						})
					}
					this.setAllMenus(this.menuList)
					uni.hideLoading();
				} else {
					setTimeout(function() {
						uni.hideLoading();
					}, 5000);
					uni.showModal({
						content: '搜索失败',
						success: function(res) {
							if (res.confirm) {
								console.log('确定');
							} else if (res.cancel) {
								console.log('取消');
							}
						}
					});
				}

			},

			clearIcon() {
				this.menuCategoryName = ''
				this.getMenuListData()
			},
			queryMenu(val) {
				this.menuCategoryName = val.detail.value
				this.keyWord = this.menuCategoryName
				this.getMenuListData()
			},
			brightenKeyword(val, key) {
				const Reg = new RegExp(key)
				if (val) {
					const res = val.replace(Reg, `<text style="color:#D7311E;">${key}</text>`)
					console.log(res, ',resresresresres')
					return res
				}
			},
			upDateChooseMenu() {
				this.chooseMenuList = []
				this.menuList.forEach(item => {
					if (item.checked) {
						if (item.recipe_num > 1) {
							(item.recipe_ids.split(',')).forEach((id) => this.chooseMenuList
								.push(id))
						} else {
							this.chooseMenuList.push(item.recipe_ids)
						}
					} else {
						item.twoChildren.forEach((child) => {
							if (child.checked) this.chooseMenuList.push(child
								.recipe_id)
						})
					}
				})
				// this.setMenusListContent(this.chooseMenuList)
				console.log(this.chooseMenuList, '选中的菜谱')
			},
			upDateChecked() {
				// console.log('up新子节点')
				this.menuList.forEach(item => {
					item.checked = item['twoChildren'].length ? item['twoChildren'].every(
						subItem =>
						subItem.checked === true) : item.checked
				})
			},
			async changeCheckBox(e) {
				if (this.oldChooseMenuList.length > e.detail.value.length) {
					for (let i = 0; i < this.oldChooseMenuList.length; i++) {
						let status = false;
						e.detail.value.forEach(item => {
							if (this.oldChooseMenuList[i] === item) {
								status = true;
							}
						});
						if (!status) {
							let index = -1;
							for (let j = 0; j < this.chooseMenuList.length; j++) {
								if (this.chooseMenuList[j] == this.oldChooseMenuList[i]) {
									index = j;
									this.chooseMenuList.splice(j, 1);
									this.oldChooseMenuList.splice(i, 1);
									break;
								}
							}
							if (index >= 0) {
								break;
							}
						}
					}
				} else {
					let index = -1;
					for (let i = 0; i < e.detail.value.length; i++) {
						let status = true;
						for (let j = 0; j < this.oldChooseMenuList.length; j++) {
							if (e.detail.value[i] === this.oldChooseMenuList[j]) {
								status = false;
								index = i;
								break;
							}
						}
						if (status) {
							this.oldChooseMenuList.push(e.detail.value[i]);
							this.chooseMenuList.push(e.detail.value[i]);
							break;
						}
					}
				}

				for (let item of this.menuList) {
					let sign = true;
					e.detail.value.forEach(item_id => {
						if (item.id === item_id) sign = false;
					});
					if (sign) {
						if (item.checked !== false) {
							const menu = await this.API.menus.getRecipeSubdata(item.id, this
								.org_business_id);
							menu.data.forEach(menuItem => {
								if (this.chooseMenuList.includes(menuItem.recipe_id)) {
									// 从 this.chooseMenuList 中删除已存在的 recipe_id
									let index = this.chooseMenuList.indexOf(menuItem
										.recipe_id);
									if (index !== -1) {
										this.chooseMenuList.splice(index, 1);
									}
									let index1 = this.chooseMenuList.indexOf(item.id);
									if (index1 !== -1) {
										this.chooseMenuList.splice(index1, 1);
									}
								}
							});
							this.chooseMenuCount -= item.recipe_num;
							item.checked = false;
							if (item['twoChildren'].length) {
								item['twoChildren'].forEach(child => child.checked = false);
							}
						}
					} else {
						if (item.checked !== true) {
							const menu = await this.API.menus.getRecipeSubdata(item.id, this
								.org_business_id);
							let countToAdd = item.recipe_num;
							menu.data.forEach(menuItem => {
								if (this.chooseMenuList.includes(menuItem.recipe_id)) {
									countToAdd--;
									// 从 this.chooseMenuList 中删除已存在的 recipe_id
									let index = this.chooseMenuList.indexOf(menuItem
										.recipe_id);
									if (index !== -1) {
										this.chooseMenuList.splice(index, 1);
										this.chooseMenuList.push(item.id)
									}
								}
							});

							this.chooseMenuCount += countToAdd;
							item.checked = true;
							if (item['twoChildren'].length) {
								item['twoChildren'].forEach(child => child.checked = true);
							}
						}
					}
				}
				console.log(this.chooseMenuList);
				console.log(this.oldChooseMenuList);
				console.log(e.detail.value);
				console.log(this.menuList, '点击一级菜单this.menuList');
			},

			changeAll(e) {
				if (e.detail.value.length) {
					let count = 0;
					this.chooseMenuList = this.menuList.map((item) => {
						count += item.recipe_num;
						return item.id;
					});
					this.chooseMenuCount = count;
				} else {
					this.chooseMenuList = [];
					this.chooseMenuCount = 0;
				}
				console.log(this.chooseMenuList, 'this.chooseMenuList全选');
				// console.log('时间筛选', e)
				this.checkAll = !this.checkAll
				// this.setMenusListContent(this.chooseMenuList)
				this.menuList.forEach(item => {
					item.checked = this.checkAll
					item['twoChildren'].forEach(subItem => {
						subItem.checked = this.checkAll
					})
				})
				// this.upDateChooseMenu()
			},

			toDetail() {
				uni.navigateTo({
					url: '/menusPages/pages/menuDetail/menuDetail'
				})
			},
			toChooseMenu() {
				uni.navigateTo({
					url: '/menusPages/pages/chooseMenu/chooseMenu'
				})
			},
			toChooseDevice() {
				// 数据过滤
				console.log(this.chooseMenuList, '哈哈选择的菜谱')
				let newMenusList = []
				if (!this.chooseMenuList.length) {
					uni.showToast({
						title: '请选择菜谱',
						icon: 'error'
					})
					return
				}
				// this.menuList.forEach((item) => {
				// 	this.chooseMenuList.forEach((menu) => {
				// 		if (item.id == menu) {
				// 			newMenusList.push(item.recipe_ids)
				// 		}
				// 	})
				// })
				// console.log(newMenusList, 'newMenusListnewMenusListnewMenusList')
				let arr = Array.from(new Set(this.chooseMenuList));
				console.log(arr, 'arr')
				uni.navigateTo({
					url: `/menusPages/pages/downToDevice/downToDevice?chooseMenu=${arr}`
				})
			},


			// 调整控件
			controlAdjustment(index) {
				if (index === this.secondaryControl) this.secondaryControl = ''
				else this.secondaryControl = index

				this.secondaryControl !== '' && this.obtainLayerTwodata() // 请求第二层数据
			},
			// 获取第二层数据
			async obtainLayerTwodata() {
				// 清除一下所有过度效果避免重复出现
				this.colseLoading()
				// 开启过度效果
				this.menuList[this.secondaryControl].loading = true // 开启过度效果 

				// 判断是否已有数据
				if (this.menuList[this.secondaryControl]['twoChildren'][0]?.recipe_id && this
					.menuList[this
						.secondaryControl]['twoChildren'].length) {
					setTimeout(() => {}, 500)
					return
				}

				const menu = await this.API.menus.getRecipeSubdata(this.menuList[this
						.secondaryControl].id, this
					.org_business_id)
				// 这段代码是部数据的 用来测试 后端数据保证没问题后可以删除
				// menu.data.forEach(item => {
				// 	if (!item.recipe_id) item.recipe_id = '3sdsjjads8sdhjahsd8ads'
				// })
				// ---------------------------------------------------------------------------------
				this.chooseMenuList.map((menu1) => {
					if (this.menuList[this.secondaryControl].id === menu1) {
						menu.data.forEach(item => {
							item.checked = true;
						})
					} else {
						menu.data.forEach(item => {
							if (menu1 === item.recipe_id) {
								item.checked = true;
							}
						})
					}

				})
				this.loadingTime = setTimeout(() => {
					this.menuList[this.secondaryControl].twoChildren = menu.data.length ?
						menu.data : [{
							recipe_id: '',
							checked: this.menuList[this.secondaryControl].checked
						}] // 二级菜单
					this.menuList[this.secondaryControl].loading = false // 关闭过度效果 
					this.upDateChecked()
				}, 500)
			},
			// 清除所有过度
			colseLoading() {
				clearTimeout(this.loadingTime) // 清除上一次计时器
				this.menuList.forEach(item => {
					item.loading = false
				})
			},
			// 二级菜单数据变化
			async changeCheckBoxItem(e) {
				let {
					value
				} = e.detail;
				console.log(value, '点击二级菜单');

				// 遍历当前控制的二级菜单项
				for (let item of this.menuList[this.secondaryControl]['twoChildren']) {
					console.log(value.indexOf(item.recipe_id), item.recipe_id);
					if (value.indexOf(item.recipe_id) !== -1) {
						console.log(111);
						if (!item.checked) {
							item.checked = true;
							this.chooseMenuList.push(item.recipe_id); // 添加到 chooseMenuList
							this.chooseMenuCount++;
						}
					} else {
						console.log(222);
						if (item.checked) {
							item.checked = false;
							this.chooseMenuCount--;

							// 从 chooseMenuList 中移除
							let index = this.chooseMenuList.indexOf(item.recipe_id);
							if (index !== -1) {
								this.chooseMenuList.splice(index, 1);
							}

							// 获取所有同级二级菜单项
							const menu = await this.API.menus.getRecipeSubdata(item
								.recipe_category_id, this.org_business_id);
							console.log(menu.data, 'menu.data');

							// 检查当前一级菜单下是否还有其他已选中的二级菜单项
							let hasChecked = false;
							for (let menuItem of menu.data) {
								if (this.chooseMenuList.indexOf(menuItem.recipe_id) !== -1) {
									hasChecked = true;
									break;
								}
							}

							// 如果当前一级菜单下没有其他已选中的二级菜单项，则移除一级菜单项的ID
							if (!hasChecked) {
								let parentIndex = this.chooseMenuList.indexOf(item
									.recipe_category_id);
								if (parentIndex !== -1) {
									this.chooseMenuList.splice(parentIndex, 1);
								}
							}
						}
					}
				}

				console.log(this.menuList, '点击二级菜单this.menuList');
				console.log(this.chooseMenuList, '点击二级菜单this.chooseMenuList');
				this.upDateChecked();
			}
		},
		onLoad() {
			this.org_business_id = this.customer.org_business_id,
				this.getMenuListData()
			this.getTotal()
			// this.setMenusListContent([])
			// this.setColor('1')
		}
	}
</script>
<style lang="less" scoped>
	.chooseMenu {
		width: 100vw;
		height: 100vh;
		background-color: rgba(245, 245, 245, 1);
		position: relative;

		.menuBottom {
			width: 100vw;
			height: 112upx;
			background: rgba(255, 255, 255, 1);
			position: fixed;
			bottom: 0;
			left: 0;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 16upx 20upx 26upx 20upx;
			box-sizing: border-box;

			.nextBtn {
				button {
					background-color: rgba(38, 79, 247, 1);
					width: 214upx;
					height: 80upx;
					border-radius: 875px;
					text-align: center;
					line-height: 80upx;
					color: #fff;
				}
			}
		}

		.menuEmpty {
			// width: 298upx;
			text-align: center;
			margin: 0 auto;
			padding-top: 254upx;

			.emptyTip {
				font-size: 24upx;
				color: rgba(166, 166, 166, 1);
				margin-top: 48upx;
			}
		}

		.searchBox {
			height: 56px;
			text-align: center;
			display: flex;
			align-items: center;
			justify-content: center;
			background-color: rgba(255, 255, 255, 1);
			// padding: 12px;
			box-sizing: border-box;

			.uni-input {
				width: 351px;
				height: 32px;
				opacity: 1;
				border-radius: 16px;
				background: rgba(245, 245, 245, 1);
			}
		}

		.menuContainer {
			height: calc(100vh - 112px);
			overflow-y: scroll;
			background-color: rgba(245, 245, 245, 1);

			.checkGroup {
				padding: 16upx;
				box-sizing: border-box;

				.menuLabel {
					display: flex;
					flex-direction: column;
					border-radius: 5px;
					margin-bottom: 16upx;
					display: flex;

					.menuItem {
						.menuInfo {
							display: flex;
							align-items: center;

							.tag {
								width: 56upx;
								height: 32upx;
								text-align: center;
								line-height: 32upx;
								border-radius: 4px;
								background-color: #D0D8F9;
								color: rgba(14, 60, 238, 1);
								margin-right: 20upx;
								font-size: 16upx;
							}

							.menuTitle {
								font-size: 28upx;
							}

							.menuSpec {
								width: 140upx;
								height: 36upx;
								text-align: center;
								line-height: 36upx;
								border-radius: 4px;
								background: rgba(38, 79, 247, 0.1);
								font-size: 24upx;
								color: rgba(38, 79, 247, 1);
								margin-top: 22upx;
								margin-bottom: 30upx;
							}

							.useCount {
								color: rgba(166, 166, 166, 1);
								font-size: 28upx;
							}
						}

						.menuImage {
							width: 320upx;
							height: 180upx;
							line-height: 180upx;
							text-align: center;
							background-color: rgba(245, 248, 255, 1);
							border-radius: 4px;
							position: relative;
							margin-right: 16upx;
							overflow: hidden;

							.menuTag {
								width: 86upx;
								height: 32upx;
								text-align: center;
								line-height: 32upx;
								font-size: 20upx;
								position: absolute;
								top: 0px;
								left: 0px;
								background-color: rgba(255, 205, 194, 1);
								border-radius: 4px 0px, 4px, 0px;
								color: rgba(255, 87, 51, 1);
							}

							.menuName {
								width: 98%;
								margin: 0 auto;
								font-size: 48upx;
								color: rgba(38, 79, 247, 1);
							}
						}
					}
				}
			}

		}
	}

	// 一级菜单样式
	/deep/ .menuLabel_stair {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 15rpx;
		box-sizing: border-box;
		height: 115rpx;
		margin-bottom: 5rpx;
		background-color: #fff;

		.rightIcon {
			display: flex;

			>text {
				font-size: 26rpx;
				margin-right: 5rpx;
				color: rgba(166, 166, 166, 1);
				;
			}

			.iconfont {
				transition: .2s all;
				transform: rotate(180deg);

				&.active {
					transform: rotate(0deg);
				}
			}
		}
	}

	// 二级菜单样式
	/deep/ .menuInfo_second_level {
		position: relative;
		width: 100%;
		height: 0rpx;
		overflow: hidden;
		transition: .2s all;

		&.active {
			opacity: 0;
		}

		.menuInfo_second_level_item {
			display: flex;
			align-items: center;
			width: 100%;
			height: 115rpx;
			padding: 0 55rpx;
			box-sizing: border-box;
			margin-bottom: 5rpx;
			background-color: #fff;

			&:last-child {
				margin: 0;
			}

			.menuInfo_item {
				display: flex;
				align-items: center;
			}

			.iconfont_nodata {
				width: 100%;
				display: flex;
				align-items: center;
				justify-content: center;

				>text {
					color: #9a9a9a;
				}
			}
		}

		.iconfont_loading {
			position: absolute;
			left: 0;
			top: 0;
			right: 0;
			bottom: 0;
			margin: auto;
			width: 80rpx;
			height: 80rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			animation: rotate 1s infinite;

			@keyframes rotate {
				0% {
					transform: rotate(0deg);
				}

				100% {
					transform: rotate(360deg);
				}
			}
		}
	}
</style>