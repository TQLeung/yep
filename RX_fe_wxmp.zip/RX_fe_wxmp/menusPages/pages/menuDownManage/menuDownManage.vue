<template>
	<view class="menuDownContainer">
		<view class="menuTop">
			<view class="menuLeft">
				<view class="menuTitle">
					<text>{{info.name||info.recipe_category}}</text>
					<text v-if="info.spec!='undefined'">[{{info.spec}}g</text>
					<text v-if="info.copies!='undefined'">/{{info.copies}}份]</text>
				</view>
				<view class="menuCode">
					菜谱编号：<text v-if="info.recipe_id!='undefined'">{{info.code}}</text>
				</view>
				<view class="menuCode">
					配方文件：
					<text>[{{info.name||info.recipe_category}}]</text>
					<text v-if="info.spec!='undefined'">[{{info.spec}}g]</text>
					<text v-if="info.copies!='undefined'">[{{info.copies}}份]</text>
				</view>
			</view>
		</view>
		<view class="recordTitle">
			菜谱下发记录
		</view>
		<scroll-view v-if="true" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y list"
			@scrolltolower="lower">
		<view class="recordList" v-if="total">
			<view class="record" v-for="item in downLogList" :key="item.log_id">
				<view class="recordTop">
					<text class="iconfont icon-weizhi" style="margin-right: 16upx;color:rgba(38, 79, 247, 1);"></text>
					<text>{{item.store_name}}</text>
				</view>
				<view class="deviceCode">
					设备SN:{{item.sn_code}}
				</view>
				<view class="deviceTime">
					<text style="margin-right: 38upx;">下发时间：
						<text v-if="item.send_at">{{(item.send_at).replace('T',' ').split('.')[0]}}</text>
					</text>
				</view>
				<view class="deviceCode">
					<text>操作账号：<text v-if="item.account">{{item.account}}</text></text>
				</view>
			</view>
		</view>
		<view class="menuEmpty" v-else>
			<image src="../../../static/image/emptyRecord.png" mode="" style="width: 298upx;height: 250upx;"></image>
			<view class="emptyTip">
				暂无下发记录
			</view>
		</view>
		</scroll-view>
		
		<!-- <view class="btnContainer">
			<button class="btn" @tap="toChooseDevice">菜谱下发</button>
		</view> -->
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState('menus', {
				customer: state => state.customer,
			})
		},
		data() {
			return {
				info: {},
				downLogList: [],
				total: 0,
				org_business_id: '',
				page:1
			}
		},
		methods: {
			toChooseDevice() {
				uni.navigateTo({
					url: '/menusPages/pages/downToDevice/downToDevice'
				})
			},
			async getDownloadLog() {
				uni.showLoading({
					title: '加载中'
				});
				const res = await this.API.menus.getDownLog({
					'user_id': this.org_business_id,
					'recipe_category_id': this.info.recipe_category_id,
					'recipe_sc_id': this.info.recipe_id,
					'page_index':this.page
				})
				if (res.code == 0) {
					uni.hideLoading();
					this.total = res.paging.total_records
					if (this.downLogList.length >= this.total) {
						return
					} else {
						this.downLogList = [...this.downLogList, ...res.data]
					}
				}
				// console.log(this.downLogList,'哈哈哈哈哈')
			},
			lower: function(e) {
				// console.log('kkk')
				if (this.downLogList.length >= this.total) {
					return
				} else {
					this.getDownloadLog(this.page++)
				}
			},
		},
		onLoad(options) {
			this.info = options
			console.log(this.info,'this.info下载管理页面')
			this.org_business_id = this.customer.org_business_id
			this.downLogList=[]
			// console.log(this.info, 'info')
			this.getDownloadLog()
		}
	}
</script>

<style lang="less" scoped>
	.menuDownContainer {
		height: 100vh;
		background-color: rgba(245, 245, 245, 1);
		position: relative;

		.recordTitle {
			height: 112upx;
			line-height: 112upx;
			color: rgba(166, 166, 166, 1);
			font-size: 28upx;
			margin-left: 34upx;
		}
		.scroll-Y {
				height: calc(100vh - 88px);
			}
		.menuEmpty {
			width: 298upx;
			text-align: center;
			margin: 0 auto;
			margin-top: 254upx;

			.emptyTip {
				font-size: 24upx;
				color: rgba(166, 166, 166, 1);
				margin-top: 48upx;
			}
		}

		.recordList {
			width: 734upx;
			margin: 0 auto;

			.record {
				width: 734upx;
				// height: 220upx;
				background-color: rgba(255, 255, 255, 1);
				border-radius: 5px;
				margin-bottom: 16upx;
				padding: 34upx;
				box-sizing: border-box;

				.recordTop {
					margin-bottom: 16upx;
				}

				.deviceCode {
					font-size: 24upx;
					margin-bottom: 16upx;
					color: rgba(166, 166, 166, 1);
				}

				.deviceTime {
					margin-bottom: 16upx;
					color: rgba(166, 166, 166, 1);
					font-size: 24upx;
				}
			}
		}

		.btnContainer {
			position: absolute;
			width: 100vw;
			text-align: center;
			height: 80upx;
			margin: 0 auto;
			bottom: 18upx;

			.btn {
				width: 686upx;
				height: 80upx;
				border-radius: 875px;
				background-color: rgba(38, 79, 247, 1);
				color: #fff;
			}
		}

		.menuTop {
			width: 750upx;
			height: 198upx;
			background-color: #fff;
			padding: 14upx 30upx;
			box-sizing: border-box;
			box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.25);
			display: flex;
			justify-content: space-between;
			align-items: center;

			.menuLeft {
				.menuTitle {
					font-size: 36upx;
					color: #000;
					margin-bottom: 16upx;
				}

				.menuCode {
					font-size: 24upx;
					margin-bottom: 16upx;
					color: rgba(166, 166, 166, 1);
				}
			}
		}
	}
</style>