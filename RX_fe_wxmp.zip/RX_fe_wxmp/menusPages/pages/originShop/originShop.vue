<template>
	<view class="shopInfo">
		<view class="detail">
			<view class="des">
				<view class="desTitle">
					客户名称：
				</view>
				<view class="desValue">
					<text>-</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					门店名称：
				</view>
				<view class="desValue">
					<text>-</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					门店地址：
				</view>
				<view class="desValue">
					<text>-</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					客户联系电话：
				</view>
				<view class="desValue">
					<text>-</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					渠道联系电话：
				</view>
				<view class="desValue">
					<text>-</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="less" scoped>
.shopInfo{
	height: 100vh;
	.detail{
		.des{
			width: 100vw;
			height:112upx;
			padding: 36upx 34upx;
			font-size: 28upx;
			box-sizing: border-box;
			display: flex;
			align-items: center;
			justify-content: space-between;
			background-color: #fff;
			border-bottom: 1px solid #F6F6F6;
			.desTitle{
				color:rgba(166, 166, 166, 1);
			}
		}
	}
}
</style>
