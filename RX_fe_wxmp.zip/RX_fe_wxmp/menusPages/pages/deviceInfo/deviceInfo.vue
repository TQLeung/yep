<template>
	<view class="deviceInfoContainer">
		<view class="detailTip">
			设备信息
		</view>
		<view class="detail">
			<view class="des">
				<view class="desTitle">
					产品型号：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					设备品类：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					设备版本：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					产品执行标准：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					额定功率：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					额定电压：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					额定电流：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
			<view class="des">
				<view class="desTitle">
					设备净重：
				</view>
				<view class="desValue">
					<text>KUKE9.0</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="less" scoped>
.deviceInfoContainer{
	height: 100vh;
	background-color: rgba(245, 245, 245, 1);
	.detailTip{
		width: 100vw;
		height:112upx;
		padding: 36upx 34upx;
		color:rgba(166, 166, 166, 1);
		font-size: 28upx;
		box-sizing: border-box;
		box-shadow: 1px 1px 2px  rgba(0, 0, 0, 0.25);
	}
	.detail{
		.des{
			width: 100vw;
			height:112upx;
			padding: 36upx 34upx;
			font-size: 28upx;
			box-sizing: border-box;
			display: flex;
			align-items: center;
			justify-content: space-between;
			background-color: #fff;
			border-bottom: 1px solid #F6F6F6;
			.desTitle{
				color:rgba(166, 166, 166, 1);
			}
		}
	}
}
</style>
