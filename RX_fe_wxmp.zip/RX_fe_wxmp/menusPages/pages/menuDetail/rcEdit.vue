<template>
  <view class="detailContainer">
    <view
      style="
        font-size: 28upx;
        color: rgb(200, 201, 204);
        width: 100vw;
        text-align: center;
        line-height: 60upx;
        margin-bottom: 15upx;
      "
    >
      『{{ rc_name_original }}』 规格
    </view>
    <view
      v-for="(sc, index) in sc_list"
      :key="index"
      style="
        display: flex;
        background-color: #ffffff;
        height: 108upx;
        justify-content: center;
        align-items: center;
        border-radius: 12upx;
        margin-bottom: 2px;
        padding-right: 10upx;
      "
    >
      <view style="flex: 3 1 0; text-align: center; color: rgb(150, 151, 153)"
        >菜谱 {{ index + 1 }}</view
      >
      <view style="flex: 2 1 0">
        <view v-show="sc.confine_tag == 1">
          <view
            style="
              border-radius: 7.8upx;
              background-color: rgb(240, 240, 240);
              color: rgb(200, 201, 204);
              width: 67upx;
              height: 25upx;
              text-align: center;
              line-height: 25upx;
              font-size: 18upx;
            "
          >
            已停用
          </view>
        </view>
      </view>
      <view
        style="
          font-size: 28upx;
          flex: 8 1 0;
          border-bottom: 1px solid rgb(200, 201, 204);
          display: flex;
          align-items: center;
          margin-right: 30upx;
        "
      >
        <view
          style="
            flex: 4 1 0;
            text-align: center;
            font-size: 35upx;
            line-height: 35upx;
          "
        >
          <input v-model="sc.spec" type="number" maxlength="6" />
        </view>
        <view
          style="
            flex: 1 1 0;
            text-align: center;
            color: rgb(150, 151, 153);
            font-size: 23upx;
          "
        >
          克
        </view>
        <view
          style="flex: 1 1 0; text-align: center; color: rgb(150, 151, 153)"
        >
          /
        </view>
        <view
          style="
            flex: 3 1 0;
            text-align: center;
            font-size: 35upx;
            line-height: 35upx;
          "
        >
          <input v-model="sc.copies" type="number" maxlength="2" />
        </view>
        <view
          style="
            flex: 1 1 0;
            text-align: center;
            color: rgb(150, 151, 153);
            font-size: 23upx;
          "
        >
          份
        </view>
      </view>
      <view style="flex: 2 1 0" @click="sc_confine_change(sc)">
        <view v-if="sc.confine_tag == 1" style="">
          <view
            style="
              border-radius: 7.8upx;
              background-color: rgb(175, 240, 181);
              color: rgb(0, 180, 42);
              width: 95upx;
              height: 50upx;
              text-align: center;
              line-height: 50upx;
            "
          >
            启用
          </view>
        </view>
        <view v-else>
          <view
            style="
              color: rgb(238, 10, 36);
              background-color: rgb(253, 205, 197);
              border-radius: 7.8upx;
              width: 95upx;
              height: 50upx;
              text-align: center;
              line-height: 50upx;
            "
          >
            停用
          </view>
        </view>
      </view>
    </view>
    <view style="position: fixed; bottom: 0upx">
      <button
        style="
          width: 100vw;
          background-color: rgba(0, 180, 42, 1);
          color: #ffffff;
        "
        @click="rcEdit"
      >
        {{ op_state_text }}
      </button>
    </view>
  </view>
</template>

<script>
import { mapState, mapMutations } from "vuex";
import ajax from "@/uilts/ajax/index.js";
export default {
  computed: {
    ...mapState("menus", {
      customer: (state) => state.customer,
      index: (state) => state.index,
    }),
    op_state_text() {
      let t = "保存";
      switch (this.edit_state) {
        // case 0 : t= "保存"; break;
        case -1:
          t = "重复『规格/份数』！";
          break;
        case 1:
          t = "保存在……稍等";
          break;
        case 2:
          t = "保存完成";
          break;
      }
      return t;
    },
    sc_can_save_() {
      this.sc_can_save =
        new Set(
          this.sc_list.map((sc) => {
            return `${sc.spec}@@@${sc.copies}`;
          })
        ).size == this.sc_list.length;
      this.edit_state = !this.sc_can_save?-1:0;
      // console.log("eq:" + this.sc_can_save);
    },
  },

  data() {
    return {
      rc_id: "",
      rc_name_original: "",
      org_business_id: "",
      edit_state: 0, //就绪/进行中/完成
      sc_list: [],
      sc_can_save: true,
    };
  },
  methods: {
    sc_confine_change(sc) {
      sc.confine_tag = sc.confine_tag == 1 ? 0 : 1;
    },
    rcEdit: async function () {
      if (this.sc_can_save && this.edit_state != 1) {
        this.edit_state = 1;
        const scList = this.sc_list.map((sc) => {
          return {
            sc_id: sc.sc_id,
            confine: sc.confine_tag,
            spec: sc.spec,
            copies: sc.copies,
          };
        });
        // console.log(JSON.stringify(scList));

        const r = await this.API.menus.scListEdit(scList);
        this.edit_state = 2;
        console.log(r);
      }
    },
    recipe_sc_list_get: async function () {
      const sc_list = await this.API.menus.getDetailMenu(
        this.org_business_id,
        this.rc_id,
        "",
        "",
        1
      );
      // console.log(sc_list);
      this.sc_list = sc_list.data;
    },
  },
  onLoad(options) {
    this.rc_id = options.rcId;
    this.rc_name_original = options.name;
    this.org_business_id = this.customer.org_business_id;
    // this.org_business_id = "e2247580-1a1c-4685-ab33-74e33914a28d";
    this.recipe_sc_list_get();
  },
};
</script>
<style lang="less" scoped>
.detailContainer {
  height: 100vh;
  background-color: rgba(245, 245, 245, 1);
  //  padding: 18px 24px 0 0;
}
</style>
