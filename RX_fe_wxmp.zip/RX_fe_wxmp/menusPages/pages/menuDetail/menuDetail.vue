<template>
  <view class="detailContainer">
    <view class="varietyMenuTop" v-if="detail.index == '0'">
      <view
        class="varietyMenuTitle1"
        style="
          font-size: 36upx;
          color: #000;
          margin-top: 6px;
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
        "
      >
        <view style="width: 70%">
          <text v-if="detail.name.length < 20">{{ detail.name }}</text>
          <uni-tooltip :content="detail.name" v-else>
            {{ detail.name.slice(0, 20) }}...
          </uni-tooltip>
        </view>
        <view
          style="
            color: rgba(22, 39, 255, 1);
            width: 30%;
            font-size: 26upx;
            text-align: right;
          "
        >
          <picker @change="bindPickerChange" :value="edOpsIndex" :range="edOps">
            <view class="chooseView">编辑</view>
          </picker>
        </view>
      </view>
      <view class="varietyMenuCode" v-if="detail.code">
        菜品编号：{{ detail.code }}
      </view>
      <view class="tags">
        <view
          class="tagContainer"
          v-for="(item, index) in varietyMenuList"
          :key="item.id"
          @tap="changeMenu(varietyMenuList[index], index)"
        >
          <view v-if="item.confine_tag == 1" class="gray">
            {{ item.spec }}g/{{ item.copies }}份
          </view>
          <view v-else-if="item.status == '待审核'" class="red">
            {{ item.spec }}g/{{ item.copies }}份
            <view style="font-size: 20upx; color: red">
              {{ item.status }}
            </view>
          </view>
          <view
            :class="{ tag: tagIndex != index, blue: tagIndex == index }"
            v-else
          >
            {{ item.spec }}g/{{ item.copies }}份
          </view>
        </view>
      </view>
    </view>
    <view class="menuTop" v-if="detail.index == '1'">
      <view class="menuTitle">
        <text v-if="detail.name.length < 10"
          >{{ detail.name }}[{{ detail.spec }}g/{{ detail.copies }}份]</text
        >
        <uni-tooltip :content="detail.name" v-else>
          {{ detail.name.slice(0, 9) }}...[{{ detail.spec }}g/{{
            detail.copies
          }}份]
        </uni-tooltip>
      </view>
      <view class="menuCode" style="margin-top: 6px">
        菜谱编号：{{ detail.id }}
      </view>
    </view>
    <view class="detailTip"> 菜谱基本信息 </view>
    <view class="detail">
      <view class="des" @tap="toDownManage">
        <view class="desTitle"> 菜谱下发记录 </view>
        <view class="desValue">
          <text
            class="iconfont icon-xiangyou"
            style="color: rgba(38, 79, 247, 1)"
          ></text>
        </view>
      </view>
    </view>
    <view class="detail">
      <view class="des" @tap="toApproval">
        <view class="desTitle"> 菜谱审核记录 </view>
        <view class="desValue">
          <text
            class="iconfont icon-xiangyou"
            style="color: rgba(38, 79, 247, 1)"
          ></text>
        </view>
      </view>
      <!-- <view class="des" @tap="toFileDetail">
				<view class="desTitle">
					菜谱配方管理
				</view>
				<view class="desValue">
					<text class="iconfont icon-xiangyou" style="color:rgba(38, 79, 247, 1);"></text>
				</view>
			</view> -->
      <!-- 菜谱文件 -->
      <MenuFile v-if="isShow" :isUpdate="isUpdate" ref="childComponent">
      </MenuFile>
    </view>
  </view>
</template>

<script>
import { mapState, mapMutations } from "vuex";
import MenuFile from "@/menusPages/components/menuFile/menuFile.vue";
export default {
  computed: {
    ...mapState("menus", {
      customer: (state) => state.customer,
      index: (state) => state.index,
    }),
  },
  components: { MenuFile },
  data() {
    return {
      edOps: ["修改名称", "菜谱编辑"],
      menuDetail: {},
      detail: {},
      varietyMenuList: [],
      tagIndex: "0",
      currentMenuInfo: {},
      isShow: false,
      showTabs: false,
      user_id: uni.getStorageSync("userInfo").user_id,
      org_business_id: "",
      account_id: uni.getStorageSync("userInfo").account_id,
      newArr: [],
      fileList: [],
      useFileInfo: {},
    };
  },
  methods: {
    ...mapMutations("menus", ["setMenuInfo", "setMenuIndex"]),
    toDeviceInfo() {
      uni.navigateTo({
        url: "/menusPages/pages/deviceInfo/deviceInfo",
      });
    },
    toShopInfo() {
      uni.navigateTo({
        url: `/menusPages/pages/originShop/originShop`,
      });
    },

    bindPickerChange: function (e) {
      const c = e.detail.value;
    //   console.log("picker", c);
      if (c == "0") {
        uni.navigateTo({
          url: `/menusPages/pages/menuDetail/rcRenameMix?rcId=${this.detail.id}&name=${this.detail.name}`,   
        });
      }else if( c == "1" ) {
        uni.navigateTo({
          url: `/menusPages/pages/menuDetail/rcEdit?rcId=${this.detail.id}&name=${this.detail.name}`,   
        });
      }
    },
    async getVarietyMenuList() {
      uni.showLoading({
        title: "加载中",
      });
      this.varietyMenuList = [];
      const getMenuTab = await this.API.menus.getDetailMenu(
        this.org_business_id,
        this.detail.id,
        1,
        ''
      );
      const getMenuTab2 = await this.API.menus.getDetailMenu(
        this.org_business_id,
        this.detail.id,
        '',
        1
      );
      if (getMenuTab2.code == 0) {
        uni.hideLoading();
        let statusArr = getMenuTab2.data.map((item) => {
          return {
            ...item,
            status: "待审核",
          };
        });
        let allArr = getMenuTab.data;
        statusArr.forEach((itemPic) => {
          allArr = allArr.filter((allItem) => {
            return allItem.code != itemPic.code;
          });
        });
        this.varietyMenuList = [...statusArr, ...allArr];
      }
      this.currentMenuInfo = this.varietyMenuList[0];
      if (this.detail.index == "0") {
        this.setMenuInfo(this.varietyMenuList[0]);
      }
      this.isShow = true;
    },
    isUpdate() {
      this.getVarietyMenuList();
    },
    async changeMenu(row, index) {
      // console.log(row, index,'row, index')
      // uni.showLoading({
      // 	title: '加载中'
      // });
      // this.isShow=false
      // this.useFileInfo = []
      this.tagIndex = index;
      this.setMenuIndex(index);
      // const useFileRes= await this.API.menus.getVarietyDetail(this.org_business_id,row.recipe_category_id,row.spec,row.copies)
      // if(useFileRes.code==0){
      // 	uni.hideLoading();
      this.currentMenuInfo = row;
      this.menuDetail = row;
      if (this.detail.index == "0") {
        this.setMenuInfo(row);
        this.$refs.childComponent.getMenuFileList();
      }
      // }
    },
    toFileList() {
      if (this.detail.index == "0") {
        uni.navigateTo({
          url: `/menusPages/pages/menuFile/menuFile?code=${this.currentMenuInfo.id}&copies=${this.currentMenuInfo.copies}&spec=${this.currentMenuInfo.spec}&recipe_category_id=${this.currentMenuInfo.recipe_category_id}&name=${this.currentMenuInfo.name}`,
        });
      } else {
        uni.navigateTo({
          url: `/menusPages/pages/menuFile/menuFile?code=${this.detail.id}&copies=${this.detail.copies}&spec=${this.detail.spec}&recipe_category_id=${this.detail.recipe_category_id}&name=${this.detail.name}`,
        });
      }
    },
    toApproval() {
      // console.log(this.currentMenuInfo,'this.currentMenuInfo')
      if (this.detail.index == "0") {
        uni.navigateTo({
          url: `/menusPages/pages/recordDetail/recordDetail?recipe_sc_id=${this.currentMenuInfo.sc_id}`,
        });
      } else {
        uni.navigateTo({
          url: `/menusPages/pages/recordDetail/recordDetail?recipe_sc_id=${this.detail.id}`,
        });
      }
    },
    toDownManage() {
      // console.log(this.currentMenuInfo,'this.currentMenuInfo')
      if (this.detail.index == "0") {
        uni.navigateTo({
          url: `/menusPages/pages/menuDownManage/menuDownManage?recipe_id=${this.currentMenuInfo.sc_id}&recipe_category_id=${this.currentMenuInfo.recipe_category_id}&user_id=${this.user_id}&account_id=${this.account_id}&name=${this.currentMenuInfo.recipe_category}&spec=${this.currentMenuInfo.spec}&copies=${this.currentMenuInfo.copies}&code=${this.currentMenuInfo.code}`,
        });
      } else {
        uni.navigateTo({
          url: `/menusPages/pages/menuDownManage/menuDownManage?recipe_id=${this.detail.id}&recipe_category_id=${this.detail.recipe_category_id}&user_id=${this.user_id}&account_id=${this.account_id}&name=${this.detail.name}&spec=${this.detail.spec}&copies=${this.detail.copies}`,
        });
      }
    },
  },
  onLoad(options) {
    this.org_business_id = this.customer.org_business_id
    // DEVVVVV
    // console.log('aaa', options);
    // this.org_business_id = "e2247580-1a1c-4685-ab33-74e33914a28d";
    // console.log('eee', options);
    // options.id = "336e28e4-951d-46af-8c95-cca531ea9e80";
    // console.log(this.customer);
    // console.log(this.index);

    this.detail = options;
    this.tagIndex = "0";
    this.setMenuIndex("0");
    if (options.index == "1") {
      // this.getFileDetail()
      this.setMenuInfo(this.detail);
      this.isShow = true;
    } else {
      this.getVarietyMenuList();
    }
  },
  onReady() {},
  onShow() {
    this.tagIndex = this.index;
    if (this.detail.index == "1") {
      // this.toGetMenuDetail(this.detail.id)
      // console.log(this.detail.index,'hhhh')
    } else {
      // console.log(this.detail.index,'kkkk')
    }
  },
};
</script>

<style lang="less" scoped>
.detailContainer {
  height: 100vh;
  background-color: rgba(245, 245, 245, 1);

  .varietyMenuTop {
    width: 750upx;
    // height: 112upx;
    background-color: #fff;
    padding: 14upx 30upx;
    box-sizing: border-box;
    box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.25);

    .varietyMenuTitle {
      font-size: 36upx;
      color: #000;
    }

    .varietyMenuCode {
      font-size: 24upx;
      color: rgba(166, 166, 166, 1);
    }

    .tags {
      display: flex;
      align-items: center;
      flex-wrap: wrap;

      .tagContainer {
        margin-right: 32upx;
        // width: 160upx;
        // height: 72upx;
        text-align: center;
        // line-height: 72upx;
        margin-top: 20upx;

        .tag {
          width: 100px;
          border-radius: 4px;
          padding: 8upx;
          background-color: rgba(38, 79, 247, 0.2);
        }

        .blue {
          border-radius: 4px;
          color: white;
          padding: 8upx;
          background-color: rgba(14, 60, 238, 1);
        }

        .red {
          border-radius: 4px;
          padding: 8upx;
          // color: white;
          background-color: rgba(255, 205, 194, 1);
        }
        .gray {
          border-radius: 4px;
          padding: 8upx;
          color: rgb(150, 151, 153);
          background-color: rgba(240, 240, 240, 1);
        }
      }
    }
  }

  .menuTop {
    width: 750upx;
    // height: 112upx;
    background-color: #fff;
    padding: 14upx 30upx;
    box-sizing: border-box;
    box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.25);

    .menuTitle {
      font-size: 36upx;
      color: #000;
    }

    .menuCode {
      font-size: 24upx;
      color: rgba(166, 166, 166, 1);
    }
  }

  .detailTip {
    width: 100vw;
    height: 112upx;
    padding: 36upx 34upx;
    color: rgba(166, 166, 166, 1);
    font-size: 28upx;
    box-sizing: border-box;
  }

  .detail {
    .des {
      width: 100vw;
      height: 112upx;
      padding: 36upx 34upx;
      font-size: 28upx;
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: #fff;
      border-bottom: 1px solid #f6f6f6;

      .desTitle {
        color: rgba(166, 166, 166, 1);
      }
    }
  }
}
</style>
