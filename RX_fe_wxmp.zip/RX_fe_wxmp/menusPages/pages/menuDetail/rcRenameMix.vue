<template>
  <view class="detailContainer">
    <view
      style="
        color: rgba(150, 151, 153, 1);
        font-size: 24upx;
        line-height: 40upx;
        margin-left: 24px;
      "
    >
      请输入菜品名字：
    </view>
    <input
      class="uni-input"
      maxlength="12"
      focus
      v-model="rc_new_name"
      @change="rcSearch"
      :placeholder="rc_name_original"
      style="
        font-size: 40upx;
        line-height: 68upx;
        margin-top: 34upx;
        margin-left: 24px;
        color: rgb(22, 93, 255);
        border-bottom: 1px solid rgba(166, 166, 166, 1);
        padding-bottom: 18upx;
      "
    />
    <view style="margin-left: 24px" v-show="rc_reslult_show">
      <view
        v-for="(rc, index) in rc_result"
        :class="{ even_rc_bg: index % 2 != 0 }"
        style="
          height: 96upx;
          border-bottom: 1px solid gray;
          line-height: 96upx;
          padding-left: 16upx;
          font-size: 24upx;
        "
        v-html="rc.text"
        :rc_id="rc.id"
        :rc_name="rc.name"
        @click="rcNewName(rc)"
      >
      </view>
    </view>
    <view style="position: fixed; bottom: 0upx">
      <button
        style="
          width: 100vw;
          background-color: rgba(0, 180, 42, 1);
          color: #ffffff;
        "
        @click="rcRename"
      >
        {{ op_state_text }}
      </button>
    </view>
  </view>
</template>

<script>
import { mapState, mapMutations } from "vuex";
import ajax from '@/uilts/ajax/index.js'
export default {
  computed: {
    ...mapState("menus", {
      customer: (state) => state.customer,
      index: (state) => state.index,
    }),
    op_state_text(){
      let t = '保存'
      switch (this.rename_state) {
        // case 0 : t= "保存"; break;
        case 1 : t= "保存在……稍等"; break;
        case 2 : t= "保存完成"; break;
      }
      return t
    },
    rc_can_op(){
      return this.rc_new_name.trim().length>=2
    }
  },

  data() {
    return {
      rc_id : '',
      org_business_id: "",
      rc_new_name:'',
      rc_name_original: "",
      rc_result: [],    
      rc_reslult_show:false,
      rename_state:0     //就绪/进行中/完成
    };
  },
  methods: {
    rcRename:async function() {
      if (this.rc_can_op && this.rename_state != 1 ) { 
        const r = await ajax.post(`/mam/recipe/recipe_rename/${this.rc_id}`,{
          "rc_target_name":this.rc_new_name
        })
        console.log(r);
        this.rename_state = 2;
        this.rc_name_original = this.rc_new_name
      }
      // console.log(`/mam/recipe/recipe_rename/${this.rc_id}`);
    },
    rcNewName(nv){
      // console.log(nv);
      this.rc_new_name = nv.rd.name
      this.rc_reslult_show = false;
    },
    rcSearch: async function (e) {
      //console.log(e.detail.value);
      const key = e.detail.value.trim();
      // console.log(this.rc_name_original);
      if (this.rc_can_op) {
        // console.log(key, "input key");
        const res = await this.API.menus.getVarietyList(
          1,
          this.org_business_id,
          this.rc_new_name,
          1,
          undefined,
          false
        );
        if (res.data) {
          const d = res.data.map((i)=>{
            return {
              rd:i,
              text:i.name.replace(key, `<span style="color:rgba(22,93,255,1)">${key}</span>`)
            }
          })
          this.rc_result = d;
          this.rc_reslult_show = true;

          // console.log(this.rc_result.length);
        }
      }
    },
  },
  onLoad(options) {
    // console.log(111111);
    // console.log(options);
    this.rc_id = options.rcId;
    this.rc_name_original = options.name;
    this.org_business_id = this.customer.org_business_id;
    // console.log(this.rc_id);
    //DEVVVVVVV
    // this.org_business_id = "e2247580-1a1c-4685-ab33-74e33914a28d";
  },
};
</script>
<style lang="less" scoped>
.detailContainer {
  height: 100vh;
  background-color: rgba(245, 245, 245, 1);
  padding: 18px 24px 0 0;
}
.even_rc_bg {
  background-color: rgba(232, 243, 255, 1);
}
</style>
