<template>
	<view class="recordContainer">
		<view class="recordList" v-if="recordList.length">
			<view class="recordItem" v-for="item in recordList" :key="item.id">
				<view class="recordTop" v-if="item.approval_at">
					采用时间：{{(item.approval_at).replace('T',' ').split('.')[0]}}
				</view>
				<view class="recordTop">
					审核账号：{{item.approval_account}}
				</view>
				<view class="recordInfo">
					<view class="item">菜谱文件：{{item.recipe_category_name}}[{{item.spec}}g/{{item.copies}}份]</view>
					<view class="item">文件编号：{{item.recipe_code}}</view>
					<view class="item">研发账号：{{item.develop_account}}</view>
					<view class="item">研发设备：{{item.device_code}}</view>
					<view class="item">研发门店：{{item.store_name}}</view>
					<view class="item">提交时间{{(item.created_at).replace('T',' ').split('.')[0]}}</view>
					<!-- <view class="item">审核备注：[2023:04:09 22:22:32]辣椒炒肉[400g][1份]</view> -->
				</view>
			</view>
		</view>
		<view class="" v-else style="text-align: center;padding-top: 368upx;">
			<image style="width: 256upx;height: 216upx;" src="../../../static/image/emptyRecord.png" mode=""></image>
			<view style="text-align: center;color: gray;font-size: 32upx;margin-top: 64upx;">
				无审核记录
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				id:'',
				recordList:[]
			}
		},
		methods: {
			async getRecordList(){
				uni.showLoading({
					title: '加载中'
				});
				const res=await this.API.menus.getRecord(this.id)
				if(res.code==0){
					uni.hideLoading();
					this.recordList=res.data
				}
				// console.log(res,'哈哈哈哈哈哈')
			}
		},
		onLoad(options){
			console.log(options,'options信息')
			this.id=options.recipe_sc_id
			this.getRecordList()
		}
	}
</script>

<style lang="less" scoped>
.recordContainer{
	width: 100vw;
	height: 100vh;
	background-color: rgba(245, 245, 245, 1);
	.recordList{
		width:734upx;
		margin: 0 auto;
		margin-top:16upx;
		.recordItem{
			width:734upx;
			// height: 374upx;
			background-color: #fff;
			border-radius: 5px;
			margin-bottom:16upx;
			padding: 32upx 16upx;
			box-sizing: border-box;
			.recordTop{
				font-size: 28upx;
				color: #000;
				margin-bottom:14upx;
			}
			.recordInfo{
				margin-top: 34upx;
				color:rgba(166, 166, 166, 1);
				font-size: 24upx;
				.item{
					margin-bottom: 16upx;
				}
			}
		}
	}
}
</style>
