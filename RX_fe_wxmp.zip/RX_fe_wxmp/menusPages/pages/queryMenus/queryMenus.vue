<template>
	<view class="container">
		<view class="searchContainer">
			<view class="inputBox">
				<view class="boxLeft">
					<image src="../../../static/image/querySearch.png" mode=""
						style="width: 36upx;height: 40upx;margin-right: 16upx;"></image>
					<input v-model="queryName" @input="getName" placeholder-style="font-size:24upx;" type="text"
						:placeholder="placeText">
				</view>
				<image v-if="queryName" @click="clearName" src="../../../static/image/clear.png"
					style="width: 26upx;height: 26upx;margin-right: 26upx;" mode=""></image>
			</view>
		</view>
		<view class="varietyContainer1" v-if="index=='0'">
			
			<view class="varietyContainer" v-if="varietyCount">
				<view class="varietyItem" @tap="toDetail(item)" v-for="item in varietyList" :key=item.id>
					<view class="varietyImage">
						<!-- <view class="varietyTag">
							待审核
						</view> -->
						<view class="varietyName">
							{{item.name}}
						</view>
					</view>
					<view class="varietyInfo">
						<view class="varietyTitle">
							{{item.name}}
						</view>
						<view class="varietyCount">
							菜谱数量：{{item.recipe_num}}
						</view>
						<view class="varietyCount">
							下发次数：{{item.download_times}}
						</view>
					</view>
				</view>
			</view>
			<view class="menuEmpty" v-else>
				<image src="../../../static/image/emptyRecord.png" mode="" style="width: 298upx;height: 250upx;">
				</image>
				<view class="emptyTip">
					{{showEmpty}}
				</view>
			</view>
		</view>
		<view class="" v-if="index=='1'">
			<view class="menuContainer" v-if="menuCount">
				<view class="menuItem" @tap="toDetail(item)" v-for="item in menuList" :key="item.recipe_id">
					<view class="menuImage">
						<!-- <view class="menuTag">
							待审核
						</view> -->
						<view class="menuName">
							{{item.recipe_category}}
						</view>
					</view>
					<view class="menuInfo">
						<view class="menuTitle">
							{{item.recipe_category}}
						</view>
						<view class="menuSpec">
							{{item.spec}}g/{{item.copies}}份
						</view>
						<view class="useCount">
							下发次数：{{item.download_times}}
						</view>
					</view>
				</view>
			</view>
			<view class="menuEmpty" v-else>
				<image src="../../../static/image/emptyRecord.png" mode="" style="width: 298upx;height: 250upx;">
				</image>
				<view class="emptyTip">
					{{showEmpty}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState('menus', {
				customer: state => state.customer,
			})
		},
		data() {
			return {
				statusBarHeight: uni.getStorageSync('menuInfo').statusBarHeight, //状态栏的高度（可以设置为顶部导航条的padding-top）
				menuWidth: uni.getStorageSync('menuInfo').menuWidth,
				menuHeight: uni.getStorageSync('menuInfo').menuHeight,
				menuBorderRadius: uni.getStorageSync('menuInfo').menuBorderRadius,
				menuRight: uni.getStorageSync('menuInfo').menuRight,
				menuTop: uni.getStorageSync('menuInfo').menuTop,
				queryName: '',
				varietyList: [],
				recipe_num: undefined,
				pending_num: undefined,
				user_id: uni.getStorageSync('userInfo').user_id,
				org_business_id: '',
				menuList: [],
				index: '',
				varietyCount: 0,
				menuCount: 0,
				showEmpty: '暂无搜索结果',
				placeText: '搜索菜品名称'
			}
		},
		methods: {
			async getVarietyListData() {
				uni.showLoading({
					title: '加载中'
				});
				const res = await this.API.menus.getVarietyList(1,this.org_business_id, this.queryName, this.recipe_num, this
					.pending_num)
				if (res.code == 0) {
					uni.hideLoading();
					this.varietyList = res.data
					this.varietyCount = res.paging.total_records
				}
			},
			async getMenuListData() {
				uni.showLoading({
					title: '加载中'
				});
				// const res=await this.API.menus.getMenuList(this.user_id,this.queryName)
				const res = await this.API.menus.getRelMenu(this.org_business_id, this.queryName, this.recipe_num, this
					.pending_num)
				if (res.code == 0) {
					uni.hideLoading();
					this.menuList = res.data,
						this.menuCount = res.paging.total_records
				}
			},
			getName(e) {
				this.queryName = e.target.value
				if (this.index == '0') {
					this.getVarietyListData()
				} else {
					this.getMenuListData()
				}
			},
			toDetail(row) {
				if (this.index == '0') {
					uni.navigateTo({
						url: `/menusPages/pages/menuDetail/menuDetail?index=${this.index}&id=${row.id}&name=${row.name}`,
					})
				} else {
					uni.navigateTo({
						url: `/menusPages/pages/menuDetail/menuDetail?index=${this.index}&id=${row.recipe_id}&name=${row.recipe_category}&spec=${row.spec}&copies=${row.copies}&code=${row.recipe_id}&recipe_category_id=${row.recipe_category_id}`,
					})
				}
			},
			clearName() {
				this.queryName = ''
				if (this.index == '0') {
					this.getVarietyListData()
				} else {
					this.getMenuListData()
				}
			}
		},
		onLoad(options) {
			this.index = options.index
			this.org_business_id = this.customer.org_business_id
				if (this.index == '0') {
					this.placeText = '搜索菜品名称'
				} else {
					this.placeText = '搜索菜谱名称'
				}
		}
	}
</script>

<style lang="less" scoped>
	.container {
		width: 100vw;
		height: 100vh;
		background-color: rgba(245, 245, 245, 1);

		.menuEmpty {
			width: 298upx;
			text-align: center;
			margin: 0 auto;
			margin-top: 254upx;

			.emptyTip {
				font-size: 24upx;
				color: rgba(166, 166, 166, 1);
				margin-top: 48upx;
			}
		}

		.searchContainer {
			width: 100%;
			height: 112upx;
			background-color: #fff;
			// margin-top: 88px;
			padding: 24upx 52upx 24upx 30upx;
			box-sizing: border-box;

			.version {
				width: 114upx;
				color: rgba(38, 79, 247, 1);
			}

			.inputBox {
				display: flex;
				align-items: center;
				justify-content: space-between;
				width: 100%;
				height: 64upx;
				border-radius: 16px;
				padding-left: 22upx;
				background-color: rgba(245, 245, 245, 1);

				.boxLeft {
					display: flex;
					align-items: center;
				}
			}
		}

		.varietyContainer {
			width: 100vw;
			height: 100%;
			background-color: whitesmoke;

			.varietyItem {
				width: 734upx;
				min-height: 244upx;
				border-radius: 5px;
				background-color: #fff;
				margin: 0 auto;
				padding: 32upx 16upx;
				box-sizing: border-box;
				display: flex;
				margin-bottom: 16upx;

				.varietyInfo {
					.varietyTitle {
						font-size: 36upx;
					}

					.varietySpec {
						width: 140upx;
						height: 36upx;
						text-align: center;
						line-height: 36upx;
						border-radius: 4px;
						background: rgba(38, 79, 247, 0.1);
						font-size: 24upx;
						color: rgba(38, 79, 247, 1);
						margin-top: 22upx;
						margin-bottom: 30upx;
					}

					.varietyCount {
						color: rgba(166, 166, 166, 1);
						margin-top: 24upx;
						font-size: 28upx;
					}
				}

				.varietyImage {
					width: 320upx;
					overflow: hidden;
					height: 180upx;
					line-height: 180upx;
					text-align: center;
					background-color: rgba(245, 248, 255, 1);
					border-radius: 4px;
					position: relative;
					margin-right: 16upx;

					.varietyTag {
						width: 86upx;
						height: 32upx;
						text-align: center;
						line-height: 32upx;
						font-size: 20upx;
						position: absolute;
						top: 0px;
						left: 0px;
						background-color: rgba(255, 205, 194, 1);
						border-radius: 4px 0px, 4px, 0px;
						color: rgba(255, 87, 51, 1);
					}

					.varietyName {
						width: 98%;
						margin: 0 auto;
						font-size: 48upx;
						color: rgba(38, 79, 247, 1);
					}
				}
			}
		}

		.menuContainer {
			width: 100vw;

			.menuItem {
				width: 734upx;
				height: 244upx;
				overflow: hidden;
				border-radius: 5px;
				background-color: #fff;
				margin: 0 auto;
				padding: 32upx 16upx;
				box-sizing: border-box;
				display: flex;
				margin-bottom: 16upx;

				.menuInfo {
					.menuTitle {
						font-size: 36upx;
					}

					.menuSpec {
						width: 140upx;
						height: 36upx;
						text-align: center;
						line-height: 36upx;
						border-radius: 4px;
						background: rgba(38, 79, 247, 0.1);
						font-size: 24upx;
						color: rgba(38, 79, 247, 1);
						margin-top: 22upx;
						margin-bottom: 30upx;
					}

					.useCount {
						color: rgba(166, 166, 166, 1);
						font-size: 28upx;
					}
				}

				.menuImage {
					width: 320upx;
					height: 180upx;
					line-height: 180upx;
					text-align: center;
					background-color: rgba(245, 248, 255, 1);
					border-radius: 4px;
					position: relative;
					margin-right: 16upx;

					.menuTag {
						width: 86upx;
						height: 32upx;
						text-align: center;
						line-height: 32upx;
						font-size: 20upx;
						position: absolute;
						top: 0px;
						left: 0px;
						background-color: rgba(255, 205, 194, 1);
						border-radius: 4px 0px, 4px, 0px;
						color: rgba(255, 87, 51, 1);
					}

					.menuName {
						width: 98%;
						margin: 0 auto;
						font-size: 48upx;
						// position: absolute;
						// top:50%;
						// left: 50%;
						// transform: translate(-50%, -50%);
						color: rgba(38, 79, 247, 1);
					}
				}
			}
		}
	}
</style>