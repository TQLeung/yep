<template>
  <view class="index-page pageContent">
    <!-- paddingTop不生效可换成marginTop -->
    <view class="tab_title" :style="{ paddingTop: statusBarHeight }">
      <!-- 左上角自定义样式 -->
      <view
        class="menu_btn flex-betwee box-sizing"
        :style="{
          position: 'fixed',
          top: menuTop,
          left: menuRight,
          width: menuWidth,
          height: menuHeight,
          borderRadius: menuBorderRadius,
        }"
      >
        <!-- <image class="logo" src="/static/logo.png" @click="goStepPage"></image> -->
        <view class="tit">我的</view>
      </view>
    </view>
    <view class="accountContent" :style="{ marginTop: contentTop }">
      <view class="contentLeft">
        <view class="userImage">
          <image src="/static/image/userPicture.png" mode="widthFix"></image>
        </view>
        <view class="userInfo">
          <view class="userName">{{ userInfo.name }}</view>
        </view>
      </view>
      <!-- <view class="contentRight">
				{{userInfo.user_type}}
			</view> -->
    </view>
    <view class="actionCard">
      <view class="action" @tap="toChangePassword">
        <view>修改密码</view>
        <view class="actionIcon">
          <text class="iconfont icon-xiangyou"></text>
        </view>
      </view>
      <!-- <view class="action">
				<view>常见问题</view>
				<view class="tip">敬请期待！</view>
				<view class="actionIcon">
					<text class="iconfont icon-xiangyou"></text>
				</view>
			</view>
			<view class="action">
				<view>关于我们</view>
				<view class="tip">敬请期待！</view>
				<view class="actionIcon">
					<text class="iconfont icon-xiangyou"></text>
				</view>
			</view> -->
      <view class="action">
        <view>联系我们</view>
        <view class="phone">
          <text style="color: rgba(38, 79, 247, 1)" @tap="toCall"
            >400-870-7200</text
          >
        </view>
      </view>
    </view>
    <view
      @tap.stop="navigateToCourse()"
      style="
        display: flex;
        justify-content: center;
        border-radius: 16rpx;
        margin-top: 30rpx;
      "
    >
      <img
        style="width: 364px; height: 100px"
        src="/static/course/course_help.png"
        alt="智能机器人课堂"
      />
    </view>

    <view class="layoutBox">
      <button
        @click="toLayout"
        class="btn"
        type="default"
        style="border-color: transparent"
      >
        退出登录
      </button>
    </view>
    <view class="">
      <CustomTabBar
        :items="tabItems"
        :currentIndex="2"
        @item-click="onTabClick"
        :color="color"
        :selectedColor="selectedColor"
      ></CustomTabBar>
    </view>
  </view>
</template>
<script>
import CustomTabBar from "@/uni_modules/niceui-tabBar/components/niceui-tabBar/niceui-tabBar.vue";
import tabbar from "@/uni_modules/niceui-tabBar/common/tabbar.js";
import { mapMutations, mapState } from "vuex";
export default {
  components: {
    CustomTabBar,
  },
  computed: {
    ...mapState("menus", ["customer"]),
    ...mapState("authority", ["authority"]),
  },
  data() {
    return {
      currentTab: 0, // 当前选中的tab索引
      tabItems: [],
      color: tabbar.color,
      selectedColor: tabbar.selectedColor,
      statusBarHeight: uni.getStorageSync("menuInfo").statusBarHeight, //状态栏的高度（可以设置为顶部导航条的padding-top）
      menuWidth: uni.getStorageSync("menuInfo").menuWidth,
      menuHeight: uni.getStorageSync("menuInfo").menuHeight,
      menuBorderRadius: uni.getStorageSync("menuInfo").menuBorderRadius,
      menuRight: uni.getStorageSync("menuInfo").menuRight,
      menuTop: uni.getStorageSync("menuInfo").menuTop,
      contentTop: uni.getStorageSync("menuInfo").contentTop,
      userInfo: {},
    };
  },
  onLoad() {
    // 根据vuex权限设置数据
    if (this.authority.rootMenu) this.tabItems = tabbar.tabItems1;
    else this.tabItems = tabbar.tabItems2;
    this.currentTab = this.authority.currentTab;
    this.userInfo = uni.getStorageSync("userInfo");
    // console.log(this.userInfo)
  },
  methods: {
    ...mapMutations("authority", ["changeTab"]),
    ...mapMutations("menus", ["setCustomer"]),
    navigateToCourse() {
      // uni.navigateTo({url:'/coursePages/pages/help20241014/index'})
      uni.navigateToMiniProgram({
        appId: "wxd45c635d754dbf59",
        path:
          "pages/detail/detail?url=" +
          encodeURIComponent("https://docs.qq.com/doc/p/94f06cab60a70b14c3041988eb25bfc1a3ffd4c0"),
      });
    },
    onTabClick(index) {
      // 切换tab的函数，当选中某个tab时触发
      // if(index!=this.currentTab){
      this.currentTab = index;
      this.changeTab(index);
      // console.log('当前点击0', this.tabItems[index].pagePath,this.currentTab)
      uni.switchTab({
        url: "../../" + this.tabItems[index].pagePath,
      });
      // }
    },
    toChangePassword() {
      uni.navigateTo({
        url: "/pages/password/password",
      });
    },
    toLayout() {
      this.Tools.deleteToken();
      uni.removeStorageSync("userInfo");
      uni.clearStorageSync();
      this.setCustomer({});
      uni.reLaunch({
        url: "/pages/login/login",
      });
    },
    toCall() {
      // console.log('拨打电话')
      uni.makePhoneCall({
        phoneNumber: "400-870-7200",
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.box-sizing {
  box-sizing: border-box;
}
.pageContent {
  width: 100vw;
  height: 100vh;
  background-color: #f5f5f5;
  .layoutBox {
    margin-top: 188upx;
    .btn {
      color: rgba(38, 79, 247, 1);
      width: 368upx;
      height: 80upx;
      background-color: transparent;
      // border-color: transparent !important;
      font-size: 34upx;
    }
  }
  .actionCard {
    background-color: #fff;
    width: 728upx;
    // height: 656upx;
    margin: 0 auto;
    margin-top: 28upx;
    border-radius: 16upx;
    padding: 34upx 40upx;
    box-sizing: border-box;
    .action {
      width: 620upx;
      height: 104upx;
      display: flex;
      font-size: 28upx;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #f9f9f8;
      .tip {
        color: #e5e5e5;
        font-size: 24upx;
      }
      .actionIcon {
        color: #ccd6cb;
      }
      .phone {
        font-size: 22upx;
      }
    }
  }
  .accountContent {
    width: 100%;
    height: 264upx;
    background-color: #264ff7;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
    padding: 0upx 38upx;
    .contentRight {
      color: #b8c6ff;
      font-size: 24upx;
    }
    .contentLeft {
      display: flex;
      align-items: center;
      .userInfo {
        .userName {
          color: #fff;
          font-size: 32upx;
          margin-bottom: 22upx;
        }
        .shopName {
          color: #b8c6ff;
          font-size: 24upx;
        }
      }
      .userImage {
        image {
          width: 140upx;
          height: 140upx;
          margin-right: 20upx;
        }
      }
    }
  }
}
.index-page {
  width: 100vw;
  background-color: rgba(245, 245, 245, 1);
  // height: calc(100vh - 88px); // 解决页面无内容时上下滚动问题 高度默认44px + padding-top 20px
  // padding: 32rpx;
  .tab_title {
    width: 100%;
    height: 44px !important; //这个是固定的44px（所有小程序顶部高度都是 = 44px + 手机系统状态栏高度）
    line-height: 44px;
    text-align: center;
    // background-color: #d00;
    background-color: #264ff7 !important;
    position: fixed;
    top: 0;
    z-index: 9999;
    color: #fff;
    font-weight: 500;

    .menu_btn {
      width: 100upx !important;
      // background-color: #ffffff; //这个是小程序默认的标题栏背景色
      overflow: hidden;

      // position: fixed; //行内式写了固定定位--目的是去掉下划页面一起滚动问题
      .arrowleft {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-160%, -50%) !important;
        -webkit-transform: translate(-160%, -50%) !important;
      }

      .text_box {
        width: 1rpx;
        height: 20px;
        background-color: #ddd;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) !important;
        -webkit-transform: translate(-50%, -50%) !important;
      }

      .home {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(60%, -50%) !important;
        -webkit-transform: translate(60%, -50%) !important;
      }
    }
  }
}
</style>
