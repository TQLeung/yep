<template>
	<view class="container">
		<view class="title">
			客户信息
		</view>
		<view class="infoContainer">
			<view class="infoItem">
				<view class="infoTitle">
					客户名称：
				</view>
				<view class="infoDes">
					{{orderInfo.companyName}}
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					付费账号：
				</view>
				<view class="infoDes">
					{{userInfo.name}}
				</view>
			</view>
		</view>
		<view class="title">
			设备信息
		</view>
		<view class="infoContainer">
			<view class="infoItem">
				<view class="infoTitle">
					设备编号：
				</view>
				<view class="infoDes">
					{{orderInfo.code}}
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					门店名称：
				</view>
				<view class="infoDes">
					-
				</view>
			</view>
			<view class="infoItem">
				<view class="infoTitle">
					门店地址：
				</view>
				<view class="infoDes">
					-
				</view>
			</view>
		</view>
		<view class="title">
			选择付费方式
		</view>
		<view class="infoContainer">
			<view class="commissionContainer">
				<view v-for="item in commissionPlanList" :key="item.id" :class="{commissionItem:true,activeCommission:activeCommission==item.id}" @tap="changeActive(item)">
					<view class="recommend" v-if="item.type=='annual'||item.type=='semiannual'">
						超值推荐
					</view>
					<view class="name">
						<text v-if="item.type=='annual'">年度付</text>
						<text v-if="item.type=='quarter'">季度付</text>
						<text v-if="item.type=='semiannual'">半年付</text>
					</view>
					<view class="price">
						<text style="color:#264FF7;">¥</text>
						<text style="font-size: 52upx;color: #264FF7;">{{item.agent_amount+item.renxin_amount}}</text>
						<text>月</text>
					</view>
					<view class="time">
						付费效期<text style="color:#264FF7;"> 
						 <text v-if="item.type=='annual'">12</text>
						 <text v-if="item.type=='quarter'">3</text>
						 <text v-if="item.type=='semiannual'">6</text>
						 </text>个月
					</view>
				</view>
			</view>
			<view class="commissionTip">
				注：新设备完成付费后，设备激活后才生效计时。
			</view>
		</view>
		<view class="title">
			查看设备付费说明
		</view>
		<view class="pageBottom">
			<view class="pageBottom_Left">
				<view class="totalPrice">
					<text>总计：</text>
					<text style="color:#FE3D2F;">¥<text style="font-size:32upx;color:#FE3D2F;">{{(renxin+agent)*time}}</text></text>
				</view>
				<view class="des">{{type}}，付费效期{{time}}个月</view>
			</view>
			<view class="pageBottom_right">
				<button class="btn" @click="toCreateOrder">立即下单</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				commissionPlanList:[],
				activeCommission:'',
				orderInfo:{},
				payInfo:{},
				renxin:0,
				agent:0,
				time:0,
				type:'',
				userInfo:{},
			}
		},
		methods: {
			async getCommissionPlans(){
				const res=await this.API.order.getCommissionPlan()
				if(res.code==0){
					this.commissionPlanList=res.data
					this.activeCommission=res.data[0].id
					this.renxin=res.data[0].renxin_amount
					this.agent=res.data[0].agent_amount
					if(res.data[0].type=='semiannual'){
						this.time=6
						this.type='半年付'
					}else if(res.data[0].type=='annual'){
						this.time=12
						this.type='年度付'
					}else{
						this.time=3
						this.type='季度付'
					}
				}
				// console.log(this.commissionPlanList)
			},
			changeActive(row){
				this.activeCommission=row.id
				this.renxin=row.renxin_amount
				this.agent=row.agent_amount
				if(row.type=='semiannual'){
					this.time=6
					this.type='半年付'
				}else if(row.type=='annual'){
					this.time=12
					this.type='年度付'
				}else{
					this.time=3
					this.type='季度付'
				}
			},
			async toCreateOrder(){
				const res=await this.API.order.createOrder({
					device_journal_id:this.orderInfo.id,
					commission_plan_id:this.activeCommission
				})
				if(res.code==0){
					const openid=uni.getStorageSync('openId').openid
					const resultPay=await this.API.order.getPayInfo(res.data.id,openid)
					if(resultPay.code==0){
						this.payInfo=resultPay.data
						// 调用微信支付接口
						uni.requestPayment({
							provider:'wxpay',//支付平台
							timeStamp:resultPay.data.timestamp.toString(),//订单生成时间
							nonceStr:resultPay.data.nonce_str,//随机字符串
							package:resultPay.data.package,//统一下单 
							signType:resultPay.data.sign_type,//签名算法
							paySign:resultPay.data.pay_sign,//签名
							success: async (result)=>{
								// console.log(result)
								// requestPayment:ok 支付成功的状态
								const {errMSg}=result
								if(errMSg==='requestPayment:ok'){
									uni.showToast({
										title:'支付成功',
										icon:'success'
									})
								}
								uni.navigateTo({
									url:`/pages/order/detail/detail?status=success&id=${res.data.id}`
								})
							},
							fail:(error)=>{
								// console.log(error,'支付失败')
								uni.showToast({
									title:'支付失败',
									icon:'error',
									duration:2000
								})
								uni.navigateTo({
									url:`/pages/order/detail/detail?status=error&id=${res.data.id}`	
								})
							}
						})
					}
				}else{
					uni.showModal({
						title:'付款说明',
						content:'目前仅支持客户管理员账号进行付款，店长/厨师账号暂不支持。',
						confirmText:'我知道了',
						confirmColor:'rgba(38, 79, 247, 1)',
						cancelText:'',
						showCancel:false,
					})
				}
			}
		},
		onLoad(option) {
			this.orderInfo=option
			this.getCommissionPlans()
			this.userInfo=uni.getStorageSync('userInfo');
		}
	}
</script>

<style scoped lang="less">
	.container{
		width: 100%;
		height: 100vh;
		background-color:#F5F5F5;
		position: relative;
		overflow: auto;
		.pageBottom{
			width: 750upx;
			// height: 198upx;
			background-color: #fff;
			flex:0 0 auto;
			display: flex;
			padding: 36upx;
			box-sizing: border-box;
			justify-content: space-between;
			align-items: center;
			position: fixed;
			bottom: 0upx;
			.pageBottom_Left{
				.totalPrice{
					font-size: 28upx;
					margin-bottom: 18upx;
				}
				.des{
					font-size: 22upx;
					color: #999999;
				}
			}
			.pageBottom_right{
				.btn{
					width: 240upx;
					height: 88upx;
					line-height: 88upx;
					border-radius: 424upx;
					background-color: #264FF7;
					color:#fff;
					font-size: 32upx;
				}
			}
		}
		.toSeeMore{
			display: flex;
			justify-content: space-between;
			align-items: center;
			color:#999999;
			font-size: 24upx;
		}
		.title{
			font-size: 28upx;
			// color:#808080;
			width: 728upx;
			height: 96upx;
			margin: 0 auto;
			padding: 0upx 20upx;
			box-sizing: border-box;
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-bottom: 1px solid #F0F0F0;
		}
		.infoContainer{
			width: 100%;
			background-color: #fff;
			font-size: 24upx;
			overflow-x: scroll;
			.commissionTip{
				font-size: 20upx;
				color: #A6A6A6;
				padding: 32upx 18upx;
			}
			.commissionContainer{
				display: flex;
				justify-content: space-between;
				padding: 46upx 18upx 0upx 18upx;
				overflow-x: scroll;
				.activeCommission{
					border: 1px solid #264FF7;
					background-color: #F0F2F9;
				}
				.commissionItem{
					width: 224upx;
					height: 342upx;
					box-shadow: 0px 0px 6px 0px #999999;
					border-radius: 10upx;
					text-align: center;
					position: relative;
					.recommend{
						position: absolute;
						width: 136upx;
						height: 40upx;
						background: #264FF7;
						color: #fff;
						right: 0upx;
						border-radius: 0upx 20upx, 0upx, 60upx;
					}
					.name{
						font-size: 32upx;
						margin-top: 72upx;
					}
					.price{
						margin-top: 36upx;
						font-size: 20upx;
						color: #A6A6A6;
					}
					.time{
						font-size: 22upx;
						color: #999999;
						margin-top: 38upx;
					}
				}
			}
			.infoItem{
				width: 728upx;
				height: 96upx;
				margin: 0 auto;
				padding: 0upx 20upx;
				box-sizing: border-box;
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-bottom: 1px solid #F0F0F0;
				.infoTitle{
					color:#808080;
				}
			}
		}
	}
</style>
