<template>
	<view class="index-page pageContent">
        <!-- paddingTop不生效可换成marginTop -->
		<view class="tab_title" :style="{ paddingTop: statusBarHeight}">
		  <!-- 左上角自定义样式 -->
		  <view class="menu_btn flex-betwee box-sizing"
			:style="{ position: 'fixed', top: menuTop, left: menuRight, width: menuWidth, height: menuHeight, borderRadius: menuBorderRadius}">
			<!-- <image class="logo" src="/static/logo.png" @click="goStepPage"></image> -->
			<view class="tit">订单</view>
		  </view>
		</view>
		<view class="accountContent" :style="{marginTop:contentTop}">
			<view class="tabList">
				<view :class="{tab:true,activeTab:this.activeValue=='1'}" @tap="changeActiveValue('1')">全部</view>
				<view :class="{tab:true,activeTab:this.activeValue=='2'}" @tap="changeActiveValue('2')">待付款</view>
				<view :class="{tab:true,activeTab:this.activeValue=='3'}" @tap="changeActiveValue('3')">已付款</view>
				<view :class="{tab:true,activeTab:this.activeValue=='4'}" @tap="changeActiveValue('4')">已取消</view>
			</view>
			<scroll-view v-if="true" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y orderList" @scrolltolower="lower">
				<view class="orderItem" v-for="item in orderList" :key="item.id">
					<view class="orderTop" @click="toOrderDetail(item.id)">
						<view class="orderCode">
							订单编号：{{item.code}}
						</view>
						<view class="orderStatus">
							<text v-if="item.status=='pending'">待支付</text>
							<text v-else-if="item.status=='paid'">已付款</text>
							<text v-else>已取消</text>
						</view>
					</view>
					<view class="orderContent" @click="toOrderDetail(item.id)">
						<view class="contentLeft">
							<view class="pic">
								<image style="width: 96upx;height: 88upx;margin-top: 36upx;" src="/static/image/robot.png" mode=""></image>
							</view>
							<view class="content">
								<view class="deviceName" v-if="item.device_info.name">{{item.device_info.name}}</view>
								<view class="deviceName" v-else>暂无名称</view>
								<view class="deviceCode" style="margin-bottom: 40upx;margin-top: 10upx;">SN编号：{{item.device_code}}</view>
								<view class="deviceCode">下单时间：{{(new Date(item.created_at).toJSON().replace('T',' ')).split('.')[0]}}</view>
							</view>
						</view>
						<view class="contentRight">
							<text class="iconfont icon-xiangyou"></text>
						</view>
					</view>
					<view class="orderTotal">
						<view v-if="item.payment_method=='trial'">
							<text style="color:gray;">试用订单（总计）</text>¥ 0
						</view>
						<view v-else>
							<text style="color:gray;">{{item.commission_plan_name}}（总计）</text>
							¥ {{item.total_amount}}
							<!-- <text v-if="item.commission_plan_type=='semiannual'">{{item.total_amount*6}}</text>
							<text v-else-if="item.commission_plan_type=='annual'">{{item.total_amount*12}}</text>
							<text v-else>{{item.total_amount*3}}</text> -->
						</view>
						<view class="btn" v-if="item.status=='pending'" @click="toPay(item.id)">
							<button style="border-radius: 5upx;background-color: #264FF7;height: 54upx;color:#fff;font-size: 28upx;line-height: 54upx;text-align: center;">付款</button>
						</view>
					</view>
				</view>
			</scroll-view>
		</view>
		
	</view>
</template>
<script>
	export default {
    	data() {
			return {	
				activeValue:'1',
				statusBarHeight: uni.getStorageSync('menuInfo').statusBarHeight,//状态栏的高度（可以设置为顶部导航条的padding-top）
				menuWidth: uni.getStorageSync('menuInfo').menuWidth,
				menuHeight: uni.getStorageSync('menuInfo').menuHeight,
				menuBorderRadius: uni.getStorageSync('menuInfo').menuBorderRadius,
				menuRight: uni.getStorageSync('menuInfo').menuRight,
				menuTop: uni.getStorageSync('menuInfo').menuTop,
				contentTop: uni.getStorageSync('menuInfo').contentTop,
				orderList:[],
				page:1,
				orderTotal:10
			}
		},
		methods:{
			changeActiveValue(val){
				this.activeValue=val
				this.orderList=[]
				this.page=1
				this.getOrderList(this.page)
			},
			async getOrderList(page){
				const res=await this.API.order.getOrder(this.page)
				if(res.code==0){
					if(this.activeValue=='3'){
						this.orderList=[...this.orderList.filter((item)=>{
							return item.status=='paid'
						}),...res.data.filter((item)=>{
							return item.status=='paid'
						})]
					}else if(this.activeValue=='4'){
						this.orderList=[...this.orderList.filter((item)=>{
							return item.status=='expired'
						}),...res.data.filter((item)=>{
							return item.status=='expired'
						})]
					}else if(this.activeValue=='1'){
						this.orderTotal=res.paging.total
						this.orderList=[...this.orderList,...res.data]
					}else if(this.activeValue=='2'){
						this.orderList=[...this.orderList.filter((item)=>{
							return item.status=='pending'
						}),...res.data.filter((item)=>{
							return item.status=='pending'
						})]
					}
					
				}
				// console.log(this.orderList)
			},
			toOrderDetail(id){
				uni.navigateTo({
					url:`/pages/order/detail/detail?id=${id}`
				})
			},
			async toPay(id){
				const openid=uni.getStorageSync('openId').openid
				const resultPay=await this.API.order.getPayInfo(id,openid)
				if(resultPay.code==0){
					this.payInfo=resultPay.data
					// 调用微信支付接口
					uni.requestPayment({
						provider:'wxpay',//支付平台
						timeStamp:resultPay.data.timestamp.toString(),//订单生成时间
						nonceStr:resultPay.data.nonce_str,//随机字符串
						package:resultPay.data.package,//统一下单 
						signType:resultPay.data.sign_type,//签名算法
						paySign:resultPay.data.pay_sign,//签名
						success: async (result)=>{
							// console.log(result)
							// requestPayment:ok 支付成功的状态
							const {errMSg}=result
							if(errMSg==='requestPayment:ok'){
								uni.showToast({
									title:'支付成功',
									icon:'success'
								})
								uni.navigateTo({
									url:`/pages/order/detail/detail?status=success&id=${id}`
								})
							}
						},
						fail:(error)=>{
							// console.log(error,'支付失败')
							uni.showToast({
								title:'支付失败',
								icon:'error',
								duration:2000
							})
							uni.navigateTo({
								url:`/pages/order/detail/detail?status=error&id=${id}`	
							})
						}
					})
				}
				// console.log(id)
			},
			lower: function(e) {
				if(this.orderList.length>=this.orderTotal) return
				this.getOrderList(this.page++)
				// console.log("加载数据", e)
			},
			scroll: function(e) {
				// console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
		},
		onLoad() {
			this.getOrderList(this.page)
		}
    }
</script>
 
<style lang="scss" scoped>
	
		.scroll-Y {
			height: calc(100vh - 88px - 92upx );
		}
		.scroll-view_H {
			white-space: nowrap;
			width: 100%;
		}
		.scroll-view-item {
			width: 702upx;
			height: 414upx;
			margin: 0 auto;
			margin-bottom: 24upx;
			border-radius: 10upx;
			background-color: #fff;
			padding: 24upx;
			box-sizing: border-box;
		}
	
        .box-sizing {
	    	box-sizing: border-box;
	    }
		.pageContent{
			width: 100vw;
			height: 100%;
			background-color: #F5F5F5;
			.accountContent{
				.orderList{
					.orderItem{
						width: 702upx;
						height: 414upx;
						margin: 0 auto;
						margin-bottom: 24upx;
						border-radius: 10upx;
						background-color: #fff;
						padding: 24upx;
						box-sizing: border-box;
						.orderContent{
							width: 638upx;
							height: 232upx;
							padding: 32upx 0upx;
							box-sizing: border-box;
							margin: 0 auto;
							display: flex;
							// align-items: center;
							justify-content: space-between;
							border-bottom:1px solid #FAFAFA;
							.contentLeft{
								display: flex;
								align-items: center;
								.pic{
									width: 168upx;
									height: 168upx;
									text-align: center;
									border-radius: 10upx;
									background-color: #CCCCCC;
									margin-right: 20upx;
								}
								.content{
									font-size: 24upx;
									color:#A6A6A6;
									.deviceName{
										font-size: 32upx;
										color: #333;
									}
								}
							}
						}
						.orderTop{
							width: 638upx;
							height: 66upx;
							display: flex;
							color:gray;
							align-items: center;
							justify-content: space-between;
							font-size: 24upx;
							margin: 0 auto;
							border-bottom:1px solid #FAFAFA;
						}
						.orderTotal{
							display: flex;
							height: 54upx;
							margin-top: 22upx;
							align-items: center;
							font-size: 28upx;
							justify-content: space-between;
						}
					}
				}
				.tabList{
					width: 702upx;
					height: 92upx;
					font-size: 32upx;
					color: #333333;
					margin:0 auto;
					display: flex;
					align-items: center;
					box-sizing: border-box;
					.tab{
						margin-right: 68upx;
						padding: 22upx 4upx 22upx 4upx;
						box-sizing: border-box;
					}
					.activeTab{
						border-bottom:2px solid #F05821;
						box-sizing: border-box;
					}
				}
			}
			
		}
    	.index-page {
			width: 100vw;
			background-color: rgba(245, 245, 245, 1);
			// height: calc(100vh - 88px); // 解决页面无内容时上下滚动问题 高度默认44px + padding-top 20px
		// padding: 32rpx;
			.tab_title {
				width: 100%;
				height: 44px !important; //这个是固定的44px（所有小程序顶部高度都是 = 44px + 手机系统状态栏高度）
				line-height: 44px;
				text-align: center;
				// background-color: #d00;
				background-color: #fff !important;
				position: fixed;
				top: 0;
				z-index: 9999;
				color: #000;
				font-weight: 500;
	 
				.menu_btn {
					width: 100upx !important;
					// background-color: #ffffff; //这个是小程序默认的标题栏背景色
					overflow: hidden;
	 
					// position: fixed; //行内式写了固定定位--目的是去掉下划页面一起滚动问题
					.arrowleft {
						position: absolute;
						top: 50%;
						left: 50%;
						transform: translate(-160%, -50%) !important;
						-webkit-transform: translate(-160%, -50%) !important;
					}
	 
					.text_box {
						width: 1rpx;
						height: 20px;
						background-color: #ddd;
						position: absolute;
						top: 50%;
						left: 50%;
						transform: translate(-50%, -50%) !important;
						-webkit-transform: translate(-50%, -50%) !important;
					}
	 
					.home {
						position: absolute;
						top: 50%;
						left: 50%;
						transform: translate(60%, -50%) !important;
						-webkit-transform: translate(60%, -50%) !important;
					}
				}
			}
		}
			
			
</style>