<template>
	<view class="container">
		<view class="cancelOrderBox" v-if="statusText=='待付款'">
			<view class="timeKeepingBox">
				<view class="time">
					0{{min}}:
					<text v-if="sec>=10">{{sec}}</text>
					<text v-else-if="sec<=10">0{{sec}}</text>
					<!-- <text v-else-if="sec<=0">00</text> -->
				</view>
				<!-- <view class="time">
					订单超时取消
				</view> -->
				<view class="tip">
					订单支付剩余时间
				</view>
				<!-- <view class="tip">
					订单超时未支付
				</view> -->
			</view>
		</view>
		<view class="cancelOrderBox" v-if="statusText=='已取消'">
			<view class="timeKeepingBox">
				<view class="time">
					订单超时取消
				</view>
				<view class="tip">
					订单超时未支付
				</view>
			</view>
		</view>
		<view class="orderInfoTop">
			<view class="title">
				订单信息
			</view>
			<view class="status">
				<text v-if="orderDetail.status=='pending'">待付款</text>
				<text v-else-if="orderDetail.status=='paid'">已付款</text>
				<text v-else>已取消</text>
			</view>
		</view>
		<view class="infoContainer">
			<view class="info">
				<view>订单编号</view>
				<view>{{orderDetail.code}}</view>
			</view>
			<view class="info">
				<view>下单时间</view>
				<view>{{newTime}}</view>
			</view>
			<view class="info">
				<view>付费方式</view>
				<view v-if="orderDetail.payment_method=='trial'">
					试用订单
				</view>
				<view v-else>{{orderDetail.commission_plan_name}}</view>
			</view>
			<view class="info">
				<view>每月单价</view>
				<text v-if="orderDetail.commission_plan_type=='semiannual'">{{orderDetail.total_amount/6}}</text>
				<text v-else-if="orderDetail.commission_plan_type=='annual'">{{orderDetail.total_amount/12}}</text>
				<text v-else>{{orderDetail.total_amount/3}}</text>
			</view>
			<view class="info">
				<view>设备数量</view>
				<view>1</view>
			</view>
			<view class="total">
				小计：
				<text style="color:red;">
					¥{{orderDetail.total_amount}}
				</text>
			</view>
		</view>
		<view class="orderInfoTop">
			<view class="title">
				客户信息
			</view>
		</view>
		<view class="infoContainer">
			<view class="info">
				<view>客户名称</view>
				<view>{{orderDetail.user.name}}</view>
			</view>
			<view class="info">
				<view>付款账号</view>
				<view>{{orderDetail.operator}}</view>
			</view>
			<view class="info">
				<view>所属渠道</view>
				<view>{{orderDetail.channel.name}}</view>
			</view>
		</view>
		<view class="orderInfoTop">
			<view class="title">
				设备信息
			</view>
		</view>
		<view class="infoContainer deviceInfo" @tap="toDeviceDetail(orderDetail)">
			<view class="containerLeft">
				<view class="pic"></view>
				<view class="des">
					<view class="name" v-if="orderDetail.deviceInfos.name">{{orderDetail.deviceInfos.name}}</view>
					<view class="name" v-else>暂无名称</view>
					<view class="code">SN编号：{{orderDetail.device_code}}</view>
					<view class="else">
						<view class="elseItem">
							品类：
							<text v-if="orderDetail.deviceInfos.category_code">{{orderDetail.deviceInfos.category_code}}</text>
							<text v-else></text>
						</view>
						<view class="elseItem">
							型号：
							<text v-if="orderDetail.deviceInfos.type_code">{{orderDetail.deviceInfos.type_code}}</text>
							<text v-else></text>
						</view>
						<view class="elseItem">
							版本：
							<text v-if="orderDetail.deviceInfos.version_code">{{orderDetail.deviceInfos.version_code}}</text>
							<text v-else></text>
						</view>
					</view>
				</view>
			</view>
			<view class="containerRight">
				<!-- <view>
					详情
				</view> -->
				<view>
					<text class="iconfont icon-xiangyou" style="color: #264FF7;"></text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				orderId:'',
				orderDetail:{},
				orderStatus:'',
				userInfo:{},
				remainTime:1000,
				end:'',
				now:'',
				msec:0,
				day:0,
				hr:0,
				min:0,
				sec:0,
				newTime:'',
				timer:'',
				statusText:''
			}
		},
		methods: {
			async getOrderDetailInfo(){
				const res=await this.API.order.getOrderDetail(this.orderId)
				if(res.code==0){
					this.orderDetail=res.data
					this.orderDetail.created_at=new Date(this.orderDetail.created_at).toJSON().replace('T',' ')
					this.newTime=this.orderDetail.created_at.split('.')[0]
					this.end = (new Date(this.orderDetail.created_at).getTime())+600000
					this.now = Date.parse(new Date())
					this.msec = this.end - this.now
					if(this.orderDetail.status=='pending'){
						this.statusText='待付款'
						this.countdown(this.msec)
					}else if(this.orderDetail.status=='expired'){
						this.statusText='已取消'
					}else{
						this.statusText='已支付'
					}
				}
			},
			toDeviceDetail(row){
				// uni.setStorageSync('deviceDetail', row)
				if(row.deviceInfos.name){
					uni.navigateTo({
						url:`/homePages/detail/index?deviceId=${row.device_journal_id}&name=${row.deviceInfos.name}`
					})
				}else{
					uni.navigateTo({
						url:`/homePages/pages/detail/index?deviceId=${row.device_journal_id}&name=暂无名称`
					})
				}
				
			},
			//倒计时
			async countdown (val) {
				  // const res=await this.API.order.getOrderDetail(this.orderId)
				  let leave1 = val % (24 * 3600 * 1000)
				  let leave2 = leave1 % (3600 * 1000)
				  this.min=Math.floor(leave2 / (60 * 1000)) 
				  let leave3 = leave2 % (60 * 1000)
				  this.sec = Math.round(leave3 / 1000)
				  this.timer = setTimeout(() => {
					if(val<=0){
						this.statusText='已取消'
						clearTimeout(this.timer)
						this.timer=null
						return
						// this.getOrderDetailInfo()
					}
					val -= 1000
					this.countdown(val)
				  }, 1000)
			      
			}
			
		},
		onLoad(option) {
			this.orderId=option.id
			this.getOrderDetailInfo()
			this.orderStatus=option.status
			// this.userInfo=uni.getStorageSync('userInfo')
			// if(option.status=='error'){
				
			// }
			// console.log(option.status)
		}
	}
</script>

<style lang="less" scoped>
.container{
	width: 100%;
	height: 100vh;
	background-color: #F5F5F5;
	.cancelOrderBox{
		width: 100%;
		text-align: center;
		height: 190upx;
		background-color: #fff;
		.timeKeepingBox{
			.time{
				font-size: 72upx;
				font-weight: bold;
				margin-top: 20upx;
			}
			.tip{
				font-size: 28upx;
				color:#808080;
				margin-top: 20upx;
			}
		}
	}
	.deviceInfo{
		width: 100%;
		background-color: #fff;
		padding: 30upx !important;
		box-sizing: border-box;
		display: flex;
		justify-content: space-between;
		.containerRight{
			font-size: 22upx;
			color: #A6A6A6;
			display: flex;
		}
		.containerLeft{
			display: flex;
			.pic{
				width: 128upx;
				height: 128upx;
				border-radius: 8upx;
				background-color: #EAEDFC;
				margin-right: 32upx;
			}
			.des{
				.name{
					font-size: 32upx;
					color: #333333;
				}
				.code,.else{
					font-size: 24upx;
					color:#A6A6A6;
					margin-top: 16upx;
				}
				.else{
					display: flex;
					flex-wrap: wrap;
					.elseItem{
						margin-right: 10upx;
					}
				}
			}
		}
	}
	.infoContainer{
		width: 100%;
		background-color: #fff;
		padding: 32upx 64upx;
		box-sizing: border-box;
		.info{
			width: 620upx;
			height: 76upx;
			margin: 0 auto;
			display: flex;
			align-items: center;
			justify-content: space-between;
			border-top: 1px solid #FAFAFA;
			font-size: 28upx;
			view:first-child{
				color: gray;
			}
		}
		.total{
			text-align: right;
		}
	}
	.orderInfoTop{
		width: 750upx;
		height: 96upx;
		padding: 28upx 27upx 26upx 48upx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		box-sizing: border-box;
		font-size: 30upx;
		.status{
			font-size: 24upx;
			color: #999999;
		}
	}
}
</style>
