<template>
	<view class="index-page">
		<!-- paddingTop不生效可换成marginTop -->
		<view class="tab_title" :style="{ paddingTop: statusBarHeight}">
			<!-- 左上角自定义样式 -->
			<view class="menu_btn flex-betwee box-sizing"
				:style="{ position: 'fixed', top: menuTop, left: '8px', width: menuWidth, height: menuHeight, borderRadius: menuBorderRadius}">
				<view class="selectShop" @click="changePopup">
					<view class="shopLogo" v-if="customerInfo.logoName">
						{{customerInfo.logoName}}
					</view>
					<view class="shopLogo" v-else>
						选
					</view>
					<view class="shopName" v-if="customerInfo.org_name">
						<text
							v-if="customerInfo.org_name.length<=7">{{customerInfo.org_name.slice(0,7)}}</text>
						<text v-else>{{customerInfo.org_name}}</text>
						<image style="width: 12upx;height: 24upx;margin-left: 10upx;"
							src="../../static/image/channelLeft.png" mode=""></image>
					</view>
					<view class="shopName" v-else>
						<text>选择商户/门店</text>
						<image style="width: 12upx;height: 24upx;margin-left: 10upx;"
							src="../../static/image/channelLeft.png" mode=""></image>
					</view>
				</view>
				<view @click="toDevicePage"
					style="height:108upx;line-height: 108upx;width: 800upx;margin-left: 68upx;display: flex;align-items: center;">
					<text style="font-size: 14px;color:#BEDAFF" v-if="deviceCount">当前设备：{{deviceCount}}台</text>
					<text style="font-size: 14px;color:#BEDAFF" v-else>暂无设备</text>
					<text style="margin-left:32upx;font-size:14px;color:rgba(148, 191, 255, 1);"
						v-if="latest_time!='null'">
						<text v-if="latest_time_total==0">今日{{latest_time}}数据更新</text>
						<text v-else-if="latest_time_total<=15" style="color: rgba(148, 191, 255, 1);font-size: 12px;">
							{{latest_time_total}}天前数据更新
						</text>
						<text v-else>
							
						</text>
						<!-- {{latest_time}}数据更新 -->
						</text>
					<text style="margin-left:32upx;font-size:14px;color:rgba(148, 191, 255, 1);"
						v-else>今日无数据更新</text>
					<image style="width: 12upx;height: 16upx;margin-left: 28upx;"
						src="../../static/image/deviceLeft.png" mode=""></image>
				</view>
			</view>
		</view>
		<view class="operationBox-content">
			<view class="operationBox">
				<view class="operationTitle">
					<view class="titleLeft" style="display: flex;align-items: center;">
						运营数据统计
						<!-- 过度效果 -->
						<view v-if="operationData.loading"
							:class="{menuInfo_second_level: operationData.loading}"
							:style="[operationData.loading ? { height: `40rpx` } : { height: '0rpx' }]">
							<view class="iconfont_loading">
								<uni-icons type="spinner-cycle" color="rgba(150, 151, 153, 1)"
									size="20"></uni-icons>
							</view>
						</view>
					</view>
					<view class="titleRight">
						<view :class="{titleItem:true,activeTitleItem:operationTitleIndex=='2'}"
							@click="changeOperationTitleIndex('2')">今日</view>
						<view :class="{titleItem:true,activeTitleItem:operationTitleIndex=='1'}"
							@click="changeOperationTitleIndex('1')">昨日</view>
						<view :class="{titleItem:true,activeTitleItem:operationTitleIndex=='3'}"
							@click="changeOperationTitleIndex('3')">本周</view>
						<view :class="{titleItem:true,activeTitleItem:operationTitleIndex=='4'}"
							@click="changeOperationTitleIndex('4')">本月</view>
					</view>
				</view>
				<view class="operationCard">
					 
					<view class="cardItem" @click="toCookingDetail('烹饪次数')">
						<view class="cardTitle">
							<view class="">
								烹饪次数
							</view>
							<view style="margin-left: 16upx;"><uni-icons type="right" size="10" color="rgba(200, 201, 204, 1)"></uni-icons></view>
						</view>
						<view class="cardData" v-if="operationData.cur">
							<text class="count" v-if="operationData.cur.cooked_times<10000">{{operationData.cur.cooked_times}}</text>
							<text class="count" v-else-if="operationData.cur.cooked_times>10000">{{formatDecimal(operationData.cur.cooked_times/10000,0)}}</text>
							<text class="count" v-else>0</text>
							<text v-if="operationData.cur.cooked_times<10000" style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;">次</text>
							<text v-else-if="operationData.cur.cooked_times>10000" style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;">万次</text>
							<text class="count" v-else style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;">次</text>
						</view>
						<view class="cardData" v-else>
							<text class="count">0</text>
							<text class="count" style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;">次</text>
						</view>
						<view class="cardCount">
							<image v-if="Number(operationData.timeData)>0"
								style="width: 16upx;height: 20upx;margin-right: 16upx;"
								src="../../static/image/goUp.png" mode=""></image>
							<image v-if="Number(operationData.timeData)<0"
								style="width: 16upx;height: 20upx;margin-right: 16upx;"
								src="../../static/image/comeDown.png" mode=""></image>
							<text style="color: rgba(255, 125, 0, 1);"
								v-if="Number(operationData.timeData)>0">
								{{operationData.timeData}}%
							</text>
							<text style="color: rgba(0, 180, 42, 1);"
								v-else-if="Number(operationData.timeData<0)">
								{{operationData.timeData}}%
							</text>
							<text style="color: rgba(150, 151, 153, 1);" v-else>0.00%</text>
						</view>
						<view class="cardDes" v-if="operationData.timeData>0">比{{operationText}}上升</view>
						<view class="cardDes" v-else-if="operationData.timeData==0">比{{operationText}}持平</view>
						<view class="cardDes" v-else-if="operationData.timeData<0">比{{operationText}}下降</view>
					</view>
					 
					<view class="cardItem" @click="toCookingDetail('烹饪时长')">
						<view class="cardTitle">
							<view class="">
								烹饪时长
							</view>
							<view style="margin-left: 16upx;"><uni-icons type="right" size="10" color="rgba(200, 201, 204, 1)"></uni-icons></view>
						</view>
						<view class="cardData">
							<text class="count" v-if="operationData.cur&&operationData.cur.consumed_minute&&operationData.cur.consumed_minute<60">{{operationData.cur.consumed_minute}}</text>
							<text class="count" v-else-if="operationData.cur&&operationData.cur.consumed_minute&&operationData.cur.consumed_minute>60">
								<text v-if="operationData.cur.consumed_minute>600000">{{formatDecimal(operationData.cur.consumed_minute/60/10000,1)}}</text>
								<text v-else>{{formatDecimal(operationData.cur.consumed_minute/60,1)}}</text>
							</text>
							<text class="count" v-else>0</text>
							<text style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;" v-if="operationData.cur&&operationData.cur.consumed_minute&&operationData.cur.consumed_minute<60">分钟</text>
							<text style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;" v-else-if="operationData.cur&&operationData.cur.consumed_minute&&operationData.cur.consumed_minute>60">
								<text v-if="operationData.cur.consumed_minute>600000">万小时</text>
								<text v-else>时</text>
							</text>
							<text style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;" v-else>分钟</text>
						</view>
						<view class="cardCount">
							<image v-if="Number(operationData.minuteData)>0"
								style="width: 16upx;height: 20upx;margin-right: 16upx;"
								src="../../static/image/goUp.png" mode=""></image>
							<image v-if="Number(operationData.minuteData)<0"
								style="width: 16upx;height: 20upx;margin-right: 16upx;"
								src="../../static/image/comeDown.png" mode=""></image>
							<text style="color: rgba(255, 125, 0, 1);"
								v-if="operationData.minuteData>0">
								{{operationData.minuteData}}%
							</text>
							<text style="color: rgba(0, 180, 42, 1);" v-else-if="operationData.minuteData<0">
								{{operationData.minuteData}}%
							</text>
							<text style="color: rgba(150, 151, 153, 1);"
								v-else>0.00%</text>
						</view>
						<view class="cardDes" v-if="operationData.minuteData>0">比
						<text>{{operationText}}</text>
						上升</view>
						<view class="cardDes" v-else-if="operationData.minuteData<0">比
						<text>{{operationText}}</text>
						下降</view>
						<view class="cardDes" v-else>比
						<text>{{operationText}}</text>
						持平</view>
						
					</view>
					 
					<view class="cardItem" @click="toCookingDetail('能耗电量')">
						<view class="cardTitle">
							<view class="">
								能耗电量
							</view>
							<view style="margin-left: 16upx;"><uni-icons type="right" size="10" color="rgba(200, 201, 204, 1)"></uni-icons></view>
						</view>
						<view class="cardData" v-if="operationData.cur">
							<text class="count" v-if="operationData.cur.consumed_energy<10000">{{operationData.cur.consumed_energy}}</text>
							<text class="count" v-else-if="operationData.cur.consumed_energy>10000">{{formatDecimal(operationData.cur.consumed_energy/10000,1)}}</text>
							<text class="count" v-else>0</text>
							<text
								style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;">
								<text v-if="operationData.cur.consumed_energy>10000">万度</text>
								<text v-else>度</text>
								</text>
						</view>
						<view class="cardData" v-else>
							<text class="count">0</text>
							<text
								style="font-size: 11px;color: rgba(150, 151, 153, 1);margin-left: 20upx;">度</text>
						</view>
						<view class="cardCount">
							<image v-if="operationData.energyData>0"
								style="width: 16upx;height: 20upx;margin-right: 16upx;"
								src="../../static/image/goUp.png" mode=""></image>
							<image v-if="operationData.energyData<0"
								style="width: 16upx;height: 20upx;margin-right: 16upx;"
								src="../../static/image/comeDown.png" mode=""></image>
							<text style="color: rgba(255, 125, 0, 1);"
								v-if="operationData.energyData>0">
								{{operationData.energyData}}%
							</text>
							<text style="color: rgba(0, 180, 42, 1);"
								v-if="operationData.energyData<0">
								{{operationData.energyData}}%
							</text>
							<text style="color: rgba(150, 151, 153, 1);"
								v-if="operationData.energyData==0">0.00%</text>
						</view>
						<view class="cardDes" v-if="operationData.energyData>0">比{{operationText}}上升</view>
						<view class="cardDes" v-if="operationData.energyData==0">比{{operationText}}持平</view>
						<view class="cardDes" v-if="operationData.energyData<0">比{{operationText}}下降</view>
					</view>

				</view>
				<view class="deviceCard">
					<view class="deviceCardItem" @click="toFlavourDetail('调料校准')">
						<view class="cardTop">
							<view class="" style="font-size: 14px;">调料校准</view>
							<view style="margin-left: 16upx;"><uni-icons type="right" size="10" color="rgba(200, 201, 204, 1)"></uni-icons></view>
						</view>
						<view class="">
							<text style="font-size:24px;margin-right: 28upx;color: rgba(255, 125, 0, 1);" v-if="deviceCardData.pump_calibration&&deviceCardData.pump_calibration.need_pump_calibration_red">{{deviceCardData.pump_calibration.need_pump_calibration_red}}</text>
							<text style="font-size:24px;margin-right: 28upx;color: rgba(100, 101, 102, 1);" v-else>0</text>
							<text style="color:rgba(150, 151, 153, 1);font-size: 11px;">台</text>
						</view>
						<view class="" style="margin-top: 16upx;font-size: 12px;">
							<text style="color: rgba(255, 125, 0, 1);" v-if="deviceCardData.pump_calibration&&deviceCardData.pump_calibration.need_pump_calibration_red">待校准</text>
							<text style="color:rgba(150, 151, 153, 1);" v-else>待校准</text>
						</view>
					</view>
					<view class="deviceCardItem" @click="toFlavourDetail('养锅管理')">
						<view class="cardTop">
							<view style="font-size: 14px;">养锅维护</view>
							<view style="margin-left: 16upx;"><uni-icons type="right" size="10" color="rgba(200, 201, 204, 1)"></uni-icons></view>
						</view>
						<view>
							<text style="font-size:24px;margin-right: 28upx;color: rgba(255, 125, 0, 1);" v-if="deviceCardData.pot_maintain&&deviceCardData.pot_maintain.need_pot_maintain_red">{{deviceCardData.pot_maintain.need_pot_maintain_red}}</text>
							<text style="font-size:24px;margin-right: 28upx;color: rgba(100, 101, 102, 1);" v-else>0</text>
							<text style="color:rgba(150, 151, 153, 1);font-size: 11px;">台</text>
						</view>
						<view style="margin-top: 16upx;font-size: 12px;">
							<text style="color: rgba(255, 125, 0, 1);" v-if="deviceCardData.pot_maintain&&deviceCardData.pot_maintain.need_pot_maintain_red">未养锅</text>
							<text style="color:rgba(150, 151, 153, 1);" v-else>未养锅</text>
						</view>
					</view>
					<view class="deviceCardItem" @click="toFlavourDetail('料管清洗')">
						<view class="cardTop">
							<view style="font-size: 14px;">料管清洗</view>
							<view style="margin-left: 16upx;"><uni-icons type="right" size="10" color="rgba(200, 201, 204, 1)"></uni-icons></view>
						</view>
						<view class="">
							<text style="font-size:24px;margin-right: 28upx;color: rgba(255, 125, 0, 1);" v-if="deviceCardData.pump_cleaning&&deviceCardData.pump_cleaning.need_pump_cleaning_red">{{deviceCardData.pump_cleaning.need_pump_cleaning_red}}</text>
							<text style="font-size:24px;margin-right: 28upx;color: rgba(100, 101, 102, 1);" v-else>0</text>
							<text style="color:rgba(150, 151, 153, 1);font-size: 11px;">台</text>
						</view>
						<view class="" style="margin-top: 16upx;font-size: 12px;">
							<text style="color: rgba(255, 125, 0, 1);" v-if="deviceCardData.pump_cleaning&&deviceCardData.pump_cleaning.need_pump_cleaning_red">未清洗</text>
							<text style="color: rgba(150, 151, 153, 1);" v-else>未清洗</text>
						</view>
					</view>
				</view>
				<view class="cookingTimeBox">
					<view class="cookingTimeTitle">
						<view class="titleLeft" style="display: flex;align-items: center;">
							烹饪时段统计
							<view v-if="cookingTimeLoading"
								:class="{menuInfo_second_level: cookingTimeLoading}"
								:style="[cookingTimeLoading ? { height: `40rpx` } : { height: '0rpx' }]">
								<view class="iconfont_loading">
									<uni-icons type="spinner-cycle" color="rgba(150, 151, 153, 1)"
										size="20"></uni-icons>
								</view>
							</view>
						</view>
						<view class="titleRight">
							<view :class="{titleItem:true,activeTitleItem:cookingTimeIndex=='2'}"
								@click="changeCookingTimeIndex('2')">今日</view>
							<view :class="{titleItem:true,activeTitleItem:cookingTimeIndex=='1'}"
								@click="changeCookingTimeIndex('1')">昨日</view>
							<view :class="{titleItem:true,activeTitleItem:cookingTimeIndex=='3'}"
								@click="changeCookingTimeIndex('3')">本周</view>
							<view :class="{titleItem:true,activeTitleItem:cookingTimeIndex=='4'}"
								@click="changeCookingTimeIndex('4')">本月</view>
						</view>
					</view>
					<view class=""
						style="text-align: center;background-color: #fff;border-radius:4px;width: 718upx;margin: 0 auto;height: 170px;">
						<!-- 	  :canvas2d="true" -->
						<qiun-data-charts type="column" canvas2d="false" :loadingType="0" :opts="cookingOpts" :chartData="cookingChartData"
							/>
					</view>
				</view>
			</view>
			<view class="cookingCategoryBox" style="padding-top: 0upx;">
				<view class="cookingTimeTitle">
					<view class="titleLeft" style="display: flex;align-items: center;">
						TOP10烹饪菜品（次）
						<view v-if="cookingCategoryLoading"
							:class="{menuInfo_second_level: cookingCategoryLoading}"
							:style="[cookingCategoryLoading ? { height: `40rpx` } : { height: '0rpx' }]">
							<view class="iconfont_loading">
								<uni-icons type="spinner-cycle" color="rgba(150, 151, 153, 1)"
									size="20"></uni-icons>
							</view>
						</view>
					</view>
					<view class="titleRight">
						<view :class="{titleItem:true,activeTitleItem:menuCategoryIndex=='2'}"
							@click="changemenuCategoryIndex('2')">今日</view>
						<view :class="{titleItem:true,activeTitleItem:menuCategoryIndex=='1'}"
							@click="changemenuCategoryIndex('1')">昨日</view>
						<view :class="{titleItem:true,activeTitleItem:menuCategoryIndex=='3'}"
							@click="changemenuCategoryIndex('3')">本周</view>
						<view :class="{titleItem:true,activeTitleItem:menuCategoryIndex=='4'}"
							@click="changemenuCategoryIndex('4')">本月</view>
					</view>
				</view>
				<view v-if="categoryTotal" class=""
					style="text-align: center;background-color: #fff;border-radius:4px;">
					<view class="charts-box" style="height: 258px;">
						<!-- 	  :canvas2d="true" -->
						<qiun-data-charts :loadingType="0" type="bar"
							canvas2d="false" :opts="opts" :ontouch="true"
							:chartData="chartData" />
					</view>
					<view @click="toSeeAll('菜品烹饪')" style="height:40px;color:rgba(150, 151, 153, 1);border-top:1px solid rgba(240, 240, 240, 1);font-size: 12px;display: flex;align-items: center;justify-content: center;">
						<text>查看全部</text>
						<view style="margin-left: 16upx;"><uni-icons type="right" size="16" color="rgba(200, 201, 204, 1)"></uni-icons></view>
					</view>
				</view>
				<view v-else class=""
					style="height:574upx;background-color: #fff;border-radius:4px;text-align: center;">
					<image style="height: 206upx;width: 292upx;margin-top: 140upx;"
						src="../../static/image/dataEmpty.png" mode=""></image>
					<view class="" style="color:rgba(200, 201, 204, 1);margin-top: 28upx;">
						暂无数据
					</view>
				</view>
			</view>
			<view class="foodBox" style="padding-top: 0upx;">
				<view class="foodTitle">
					<view class="titleLeft" style="display: flex;align-items: center;">食材用量（kg）
						<view v-if="foodLoading"
							:class="{menuInfo_second_level: foodLoading}"
							:style="[foodLoading ? { height: `40rpx` } : { height: '0rpx' }]">
							<view class="iconfont_loading">
								<uni-icons type="spinner-cycle" color="rgba(150, 151, 153, 1)"
									size="20"></uni-icons>
							</view>
						</view>
					</view>
					<view class="titleRight">
						<view :class="{titleItem:true,activeTitleItem:foodIndex=='2'}"
							@click="changeFoodIndex('2')">今日
						</view>
						<view :class="{titleItem:true,activeTitleItem:foodIndex=='1'}"
							@click="changeFoodIndex('1')">昨日
						</view>
						<view :class="{titleItem:true,activeTitleItem:foodIndex=='3'}"
							@click="changeFoodIndex('3')">本周
						</view>
						<view :class="{titleItem:true,activeTitleItem:foodIndex=='4'}"
							@click="changeFoodIndex('4')">本月
						</view>
					</view>
				</view>
				<view v-if="foodTotal" class=""
					style="text-align: center;background-color: #fff;margin-top: 32upx;border-radius:4px;">
					<view class="charts-box" style="height: 258px;">
						<!-- 	  :canvas2d="true" -->
						<qiun-data-charts canvas-id="flavourCharts" id="flavourCharts" type="bar" :loadingType="0" canvas2d="false"
							:opts="opts" :ontouch="true" :chartData="foodChartData" @tap="flavourTap"/>
					</view>
					<view @click="toSeeAll('食材用量')" style="height:40px;color:rgba(150, 151, 153, 1);border-top:1px solid rgba(240, 240, 240, 1);font-size: 12px;display: flex;align-items: center;justify-content: center;">
						<text>查看全部</text>
						<view style="margin-left: 16upx;"><uni-icons type="right" size="16" color="rgba(200, 201, 204, 1)"></uni-icons></view>
					</view>
				</view>
				<view v-else class=""
					style="height:574upx;background-color: #fff;border-radius:4px;text-align: center;margin-top: 32upx;">
					<image style="height: 206upx;width: 292upx;margin-top: 140upx;"
						src="../../static/image/dataEmpty.png" mode=""></image>
					<view class="" style="color:rgba(200, 201, 204, 1);margin-top: 28upx;">
						暂无数据
					</view>
				</view>
			</view>
			<view class="flavourBox" style="padding-top: 0upx;">
				<view class="flavourTitle">
					<view class="titleLeft" style="display: flex;align-items: center;">调料用量（kg）
						<view v-if="flavourLoading"
							:class="{menuInfo_second_level: flavourLoading}"
							:style="[flavourLoading ? { height: `40rpx` } : { height: '0rpx' }]">
							<view class="iconfont_loading">
								<uni-icons type="spinner-cycle" color="rgba(150, 151, 153, 1)"
									size="20"></uni-icons>
							</view>
						</view>
					</view>
					<view class="titleRight">
						<view :class="{titleItem:true,activeTitleItem:flavourIndex=='2'}"
							@click="changeFlavourIndex('2')">今日</view>
						<view :class="{titleItem:true,activeTitleItem:flavourIndex=='1'}"
							@click="changeFlavourIndex('1')">昨日</view>
						<view :class="{titleItem:true,activeTitleItem:flavourIndex=='3'}"
							@click="changeFlavourIndex('3')">本周</view>
						<view :class="{titleItem:true,activeTitleItem:flavourIndex=='4'}"
							@click="changeFlavourIndex('4')">本月</view>
					</view>
				</view>
				<view v-if="flavourTotal" class=""
					style="text-align: center;background-color: #fff;margin-top: 32upx;border-radius:4px;">
					<view class="charts-box" style="height: 151px;">
						<!-- 	  :canvas2d="true" -->
						<qiun-data-charts :loadingType="0" type="bar"
							canvas2d="false" :opts="opts" :ontouch="true"
							:chartData="flavourChartData" />
					</view>
					<view @click="toSeeAll('调料用量')" style="height:40px;color:rgba(150, 151, 153, 1);border-top:1px solid rgba(240, 240, 240, 1);font-size: 12px;display: flex;align-items: center;justify-content: center;">
						<text>查看全部</text>
						<view style="margin-left: 16upx;"><uni-icons type="right" size="16" color="rgba(200, 201, 204, 1)"></uni-icons></view>
					</view>
				</view>
				<view v-else class=""
					style="height:302upx;background-color: #fff;border-radius:4px;text-align: center;margin-top: 32upx;">
					<image style="height: 136upx;width: 192upx;margin-top: 46upx;"
						src="../../static/image/dataEmpty.png" mode=""></image>
					<view class="" style="color:rgba(200, 201, 204, 1);margin-top: 18upx;">
						暂无数据
					</view>
				</view>
			</view>
		</view>
		<uni-popup ref="popup" background-color="#fff">
			<view class="popup-content" v-if="labelAll!='总部'">
				<view class="popup-search" style="padding: 28upx 106upx;text-align: center;">
					<view class="popup-search-title">
						选择商户/门店
					</view>
				</view>
				<uni-collapse accordion>
					<uni-collapse-item v-for="item,index in channelTreeData" :show-arrow="false"
						:name="item.org_business_id" :key="item.org_business_id">
						<template v-slot:title>
							<!-- 渠道 -->
							<view v-if="item.label=='渠道'" @click="clickChannel(index)" 
								style="height: 56px;line-height: 56px;display:flex;align-items: center;width: 100%;overflow-y: scroll;">
								<view class=""
									style="height: 56px;line-height: 56px;display:flex;align-items: center;width: 588upx;">
									<image src="../../static/image/channelLogo.png" mode=""
										style="width: 32upx;height: 24upx;margin-left: 36upx;margin-right: 24upx;">
									</image>
									<view class="chooseName" style="width: 70%;">{{item.org_name}}</view>
								</view>
								<view style="display:flex;align-items: center;margin-left: 28upx;width: 100upx;">
									<text
										v-if="item.device_count"
										style="color: rgba(150, 151, 153, 1);">{{item.device_count}}台</text>
									<text
										v-else
										style="color: rgba(150, 151, 153, 1);">0台</text>
								</view>
								<view style="display:flex;align-items: center;margin-left: 28upx;"
									v-if="item.children_count">
									<image v-if="treeList[index].channelImage"
										style="width: 54upx;height: 48upx;margin-left: 28upx;"
										src="../../static/image/xiangxia.png" mode=""></image>
									<image v-else
										style="width: 54upx;height: 48upx;margin-left: 28upx;"
										src="../../static/image/xiangshang.png" mode=""></image>
								</view>
							</view>

						</template>
						<uni-collapse accordion v-for="child,childIndex in item.children"
							:key="child.org_business_id">
							<uni-collapse-item :name="child.org_business_id" :show-arrow="false"
								:key="child.org_business_id">
								<template v-slot:title>
									<!-- 商户 -->
									<view
										style="height: 56px;line-height: 56px;display:flex;align-items: center;width: 100%;">
										<view @tap="getCurrentInfo(child)"
											style="height: 56px;line-height: 56px;display:flex;align-items: center;">
											<image src="../../static/image/storeLogo.png" mode=""
												style="width: 28upx;height: 24upx;margin-left: 58upx;margin-right: 24upx;">
											</image>
											<view class="chooseName" style="width:440upx;">{{child.org_name}}</view>
										</view>
										<view
											style="width: 100upx;">
											<text
												v-if="child.device_count"
												style="color: rgba(150, 151, 153, 1);">{{child.device_count}}台</text>
											<text
												v-else
												style="color: rgba(150, 151, 153, 1);">0台</text>
										</view>
										<view @click="clickUser(index,childIndex)"
											style="display:flex;align-items: center;margin-left: 28upx;"
											v-if="child.children_count">
											<image v-if="child.userImage"
												style="width: 54upx;height: 48upx;margin-left: 28upx;"
												src="../../static/image/xiangxia.png" mode="">
											</image>
											<image v-else
												style="width: 54upx;height: 48upx;margin-left: 28upx;"
												src="../../static/image/xiangshang.png" mode="">
											</image>
										</view>
									</view>
								</template>
								<!-- 门店 -->
								<view class="content" v-if="child.children">
									<view class="contentBox" v-for="lastChild in child.children"
										:key="lastChild.org_business_id"
										@tap="getCurrentInfo(lastChild)">
										<view class=""
											style="height: 56px;line-height: 56px;display:flex;align-items: center;min-width: 200upx;">
											<image src="../../static/image/storeImg.png" mode=""
												style="width: 20upx;height: 28upx;margin-left: 49px;margin-right: 12px;">
											</image>
											<view class="text" style="width:440upx;">{{lastChild.org_name}}</view>
										</view>
										<view
											style="width: 100upx;">
											<text
												v-if="lastChild.device_count"
												style="color: rgba(150, 151, 153, 1);">{{lastChild.device_count}}台</text>
												<text
													v-else
													style="color: rgba(150, 151, 153, 1);">0台</text>
										</view>
									</view>
								</view>
							</uni-collapse-item>
						</uni-collapse>
					</uni-collapse-item>
				</uni-collapse>
				<uni-collapse accordion>
					<uni-collapse-item v-for="item,index in userTreeData" :name="item.org_business_id"
						:key="item.org_business_id" :show-arrow="false">
						<template v-slot:title>
							<view
								style="height: 56px;line-height: 56px;display:flex;align-items: center;">
								<image src="../../static/image/storeLogo.png" mode=""
									style="width: 28upx;height: 24upx;margin-left: 36upx;margin-right: 24upx;">
								</image>
								<view @tap="getCurrentInfo(item)" class="chooseName" style="width: 80%;">{{item.org_name}}</view>
								<view style="display:flex;align-items: center;margin-left: 28upx;"
									v-if="item.children_count" @click="clickUser(index,childIndex)">
									<image v-if="userTreeData[index].userImage"
										style="width: 54upx;height: 48upx;margin-left: 28upx;"
										src="../../static/image/xiangxia.png" mode=""></image>
									<image v-else
										style="width: 54upx;height: 48upx;margin-left: 28upx;"
										src="../../static/image/xiangshang.png" mode=""></image>
								</view>
							</view>
						</template>
						<uni-collapse accordion v-for="child,childIndex in item.children"
							:key="child.org_business_id">
							<uni-collapse-item :name="child.org_business_id" :show-arrow="false"
								:key="child.org_business_id">
								<template v-slot:title>
									<!-- 商户 -->
									<view
										style="height: 56px;line-height: 56px;display:flex;align-items: center;width: 100%;">
										<view @tap="getCurrentInfo(child)"
											style="height: 56px;line-height: 56px;display:flex;align-items: center;width: 100%;">
											<image src="../../static/image/storeImg.png" mode=""
												style="width: 20upx;height: 28upx;margin-left: 49px;margin-right: 12px;">
											</image>
											<view class="chooseName" style="width: 80%;">{{child.org_name}}</view>
										</view>
										<view
											style="width: 100upx;">
											<text
												v-if="child.device_count"
												style="color: rgba(150, 151, 153, 1);">{{child.device_count}}台</text>
											<text
												v-else
												style="color: rgba(150, 151, 153, 1);">0台</text>
										</view>
										<view @click="clickUser(index,childIndex)"
											v-if="child.children_count"
											style="display:flex;align-items: center;margin-left: 28upx;"
											>
											<image
												v-if="child.storeImage"
												style="width: 54upx;height: 48upx;margin-left: 28upx;"
												src="../../static/image/xiangxia.png" mode="">
											</image>
											<image
												v-else
												style="width: 54upx;height: 48upx;margin-left: 28upx;"
												src="../../static/image/xiangshang.png" mode="">
											</image>
										</view>
									</view>
								</template>
							
							</uni-collapse-item>
						</uni-collapse>
					</uni-collapse-item>
				</uni-collapse>
				<uni-collapse accordion>
					<uni-collapse-item v-for="item,index in storeTreeData" :name="item.org_business_id"
						:key="item.org_business_id" :show-arrow="false">
						<template v-slot:title>
							<view
								@tap="getCurrentInfo(item)"
								style="height: 56px;line-height: 56px;display:flex;align-items: center;">
								<image src="../../static/image/storeImg.png" mode=""
									style="width: 20upx;height: 28upx;margin-left: 36upx;margin-right: 12px;">
								</image>
								<view class="chooseName" style="width: 60%;">{{item.org_name}}</view>
							</view>
						</template>
						
					</uni-collapse-item>
				</uni-collapse>
				<view style="text-align: center;margin-top: 20px;width: 100%;" @tap="colsePopup">
					取消
				</view>
			</view>
			<view class="popup-content" v-else>
				<view class="popup-search" style="padding: 28upx 106upx;text-align: center;">
					<view class="popup-search-title">
						选择商户/门店
					</view>
				</view>
				<uni-collapse accordion>
					<uni-collapse-item v-for="item,index in treeList" :show-arrow="false"
						:name="item.org_business_id" :key="item.org_business_id">
						<template v-slot:title>
							<!-- 渠道 -->
							<view v-if="item.label=='渠道'" @click="clickChannel(index)" 
								style="height: 56px;line-height: 56px;display:flex;align-items: center;width: 100%;">
								<view style="height: 56px;line-height: 56px;display:flex;align-items: center; display: flex; justify-content:flex-start; flex:9 1 0; max-width: 560upx;min-width: 560upx;">
									<image src="../../static/image/channelLogo.png" mode=""
										style="width: 32upx;height: 24upx;margin-left: 36upx;margin-right: 24upx;">
									</image>
									<view style="overflow: hidden; text-overflow: ellipsis; white-space:nowrap;">{{item.org_name}}</view>
								</view>
								<view style="display:flex;align-items: center; flex:2 1 0;justify-content: flex-end;max-width: 100upx;min-width: 100upx;">
									<text
										v-if="item.device_count"
										style="color: rgba(150, 151, 153, 1);">{{item.device_count}}台</text>
									<text
										v-else
										style="color: rgba(150, 151, 153, 1);">0台</text>
								</view>
								<view style="display:flex;align-items: center; justify-content: center; flex:1 1 0;">
									<image v-if="treeList[index].channelImage && item.children_count"
										style="width: 54upx;height: 48upx;"
										src="../../static/image/xiangxia.png" mode=""></image>
									<image v-else-if="item.children_count"
										style="width: 54upx;height: 48upx;"
										src="../../static/image/xiangshang.png" mode=""></image>
								</view>
							</view>
			
						</template>
						<uni-collapse accordion v-for="child,childIndex in item.children"
							:key="child.org_business_id">
							<uni-collapse-item :name="child.org_business_id" :show-arrow="false"
								:key="child.org_business_id">
								<template v-slot:title>
									<!-- 商户 -->
									<view
										style="height: 56px;line-height: 56px;display:flex;align-items: center;width: 100%;">
										<view @tap="getCurrentInfo(child)"
											style="height: 56px;line-height: 56px;display:flex;align-items: center;">
											<image src="../../static/image/storeLogo.png" mode=""
												style="width: 28upx;height: 24upx;margin-left: 58upx;margin-right: 24upx;">
											</image>
											<view class="chooseName" style="width:440upx;">{{child.org_name}}</view>
										</view>
										<view
											style="width: 100upx;">
											<text
												v-if="child.device_count"
												style="color: rgba(150, 151, 153, 1);">{{child.device_count}}台</text>
											<text
												v-else
												style="color: rgba(150, 151, 153, 1);">0台</text>
										</view>
										<view @click="clickUser(index,childIndex)"
											style="display:flex;align-items: center;margin-left: 28upx;"
											v-if="child.children_count">
											<image v-if="child.userImage"
												style="width: 54upx;height: 48upx;margin-left: 28upx;"
												src="../../static/image/xiangxia.png" mode="">
											</image>
											<image v-else
												style="width: 54upx;height: 48upx;margin-left: 28upx;"
												src="../../static/image/xiangshang.png" mode="">
											</image>
										</view>
									</view>
								</template>
								<!-- 门店 -->
								<view class="content" v-if="child.children">
									<view class="contentBox" v-for="lastChild in child.children"
										:key="lastChild.org_business_id"
										@tap="getCurrentInfo(lastChild)">
										<view class=""
											style="height: 56px;line-height: 56px;display:flex;align-items: center;min-width: 200upx;">
											<image src="../../static/image/storeImg.png" mode=""
												style="width: 20upx;height: 28upx;margin-left: 49px;margin-right: 12px;">
											</image>
											<view class="text" style="width:440upx;">{{lastChild.org_name}}</view>
										</view>
										<view
											style="width: 100upx;">
											<text
												v-if="lastChild.device_count"
												style="color: rgba(150, 151, 153, 1);">{{lastChild.device_count}}台</text>
												<text
													v-else
													style="color: rgba(150, 151, 153, 1);">0台</text>
										</view>
										
									</view>
								</view>
							</uni-collapse-item>
						</uni-collapse>
					</uni-collapse-item>
				</uni-collapse>
				
				<view style="text-align: center;margin-top: 20px;width: 100%;" @tap="colsePopup">
					取消
				</view>
			</view>
		</uni-popup>
		<view class="">
			<CustomTabBar :items="tabItems" :currentIndex="0" @item-click="onTabClick"
				:color="color" :selectedColor="selectedColor"></CustomTabBar>
		</view>
	</view>
</template>
<script>
	import CustomTabBar from '@/uni_modules/niceui-tabBar/components/niceui-tabBar/niceui-tabBar.vue';
	import tabbar from '@/uni_modules/niceui-tabBar/common/tabbar.js'
	import {
		mapMutations,
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState('menus', ['customer']),
			...mapState('authority', ['authority'])
		},
		components: {
			CustomTabBar,
		},
		data() {
			return {
				currentTab: 0, // 当前选中的tab索引  
				chartToTop: this.$chartToTop,
				tabItems: [],
				color: tabbar.color,
				selectedColor: tabbar.selectedColor,
				statusBarHeight: uni.getStorageSync('menuInfo')
					.statusBarHeight, //状态栏的高度（可以设置为顶部导航条的padding-top）
				menuWidth: uni.getStorageSync('menuInfo').menuWidth,
				menuHeight: uni.getStorageSync('menuInfo').menuHeight,
				menuBorderRadius: uni.getStorageSync('menuInfo').menuBorderRadius,
				menuRight: uni.getStorageSync('menuInfo').menuRight,
				menuTop: uni.getStorageSync('menuInfo').menuTop,
				contentTop: uni.getStorageSync('menuInfo').contentTop,
				troubleError: 0,
				channelTreeData:[],
				userTreeData:[],
				storeTreeData:[],
				userInfo: {},
				status: '1',
				value: [],
				treeList: [],
				// 组织类型
				treeLabel: '',
				currentDeviceCount: 0,
				customerInfo: {},
				org_business_id: '',
				foodTotal: 0,
				flavourTotal: 0,
				categoryTotal: 0,
				operationText:'上月',
				operationTitleIndex: '4',
				cookingTimeIndex: '4',
				menuCategoryIndex: '4',
				foodIndex: '4',
				flavourIndex: '4',
				// 商户/门店得运营数据
				operationData: {},
				cookingTimeLoading: false,
				cookingCategoryLoading: false,
				foodLoading: false,
				flavourLoading: false,
				chartData: {},
				latest_time: '',
				latest_time_total:0,
				foodChartData: {},
				flavourChartData: {},
				cookingChartData: {},
				// 调料、养锅数据
				deviceCardData:{},
				// 点击类型
				detailTitle:'',
				deviceCount: 0,
				labelAll:'',
				cookingOpts: {
					// height:'58px',
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272",
						"#FC8452", "#9A60B4", "#ea7ccc"
					],
					padding: [16,16,16,16],
					enableScroll: false,
					dataLabel: false,
					legend: {
						show: false,
					},
					xAxis: {
						scrollShow:true,
						disableGrid: true,
						calibration: true,
						fontSize: '12',
						format: 'xAxisDemo3'
					},
					yAxis: {
						disabled:true,
						disableGrid:false,
						data: [{
							min: 0
						}],
						gridType: 'dash',
						dashLength:4,
						gridColor:'#E8E8E8'
					},
					extra: {
						column: {
							type: "group",
							width: 5,
							activeBgColor: "#000000",
							activeBgOpacity: 0.08,
						},
						tooltip: {
							legendShape: 'circle',
							xAxisLabel: true,
							yAxisLabel: true,
							type:'slide',
							color: '#ff0000'
						}
					},
				},
				uChartsInstance:{},
				opts: {
					// color: ["#1890FF","#91CB74","#FAC858","#EE6666","#73C0DE","#3CA272","#FC8452","#9A60B4","#ea7ccc"],
					width: '258px',
					height: '258',
					padding: [8, 50, 8, 5],
					legend: {
						show: false
					},
					xAxis: {
						disabled: true,
						gridColor: "transparent"
					},
					yAxis: {},
					extra: {
						bar: {
							type: "group",
							width: 7,
							meterBorde: 1,
							color: "#000000",
							// meterFillColor: "#FFFFFF",
							activeBgColor: "#000000",
							activeBgOpacity: 0.08,
							linearType: "none",
							barBorderCircle: true,
							seriesGap: 2,
							categoryGap: 7
						},
						tooltip: {
							// horizentalLine: false
							// showBox:false,
							// legendShow:false,
							// legendShow:false,
							boxPadding:0,
							legendShape: 'circle',
							xAxisLabel: true,
							yAxisLabel: true,
							type:'slide'
						}
					},
					
				},
			}
		},
		onShow() {
			//⭐隐藏pages.json里配置的导航栏，使用封装的tabbar组件
			uni.hideTabBar({
				animation: false
			})
		},

		methods: {
			...mapMutations('menus', ['setCustomer']),
			...mapMutations('home', ['setDeviceDetailData']),
			...mapMutations('authority', ['changeTab']),
			onTabClick(index) { // 切换tab的函数，当选中某个tab时触发  
				// if(index!=this.currentTab){
				this.currentTab = index
				this.changeTab(index)
				// console.log('当前点击0', this.tabItems[index].pagePath,this.currentTab)
				uni.switchTab({
					url: '../../' + this.tabItems[index].pagePath
				})
				// }

			},
			// 切换商户或者门店的运营数据
			changeOperationTitleIndex(index) {
				this.operationTitleIndex = index
				if(index=='2'){
					this.operationText='昨日'
				}else if(index=='1'){
					this.operationText='昨日'
				}else if(index=='3'){
					this.operationText='上周'
				}else{
					this.operationText='上月'
				}
				this.getUserDataDetail(this.org_business_id)
				this.getDeviceDetailData(this.org_business_id)
			},
			changeCookingTimeIndex(index) {
				this.cookingTimeIndex = index
				this.getCookCopiesData(this.org_business_id)
			},
			changemenuCategoryIndex(index) {
				this.menuCategoryIndex = index
				this.getServerData(this.org_business_id)
			},
			changeFoodIndex(index) {
				this.foodIndex = index
				this.getFoodData(this.org_business_id)
			},
			// 调料
			changeFlavourIndex(index) {
				this.flavourIndex = index
				this.getFlavourData(this.org_business_id)
			},
			// 获取当前账号组织架构数据
			async getTreeList() {
				uni.showLoading({
					title: '加载中'
				})
				const tree = await this.API.menus.getTree()
				uni.hideLoading()
				if (tree.code == 0) {
					if (tree.data[0].label == '总部') {
						this.labelAll='总部'
						this.treeList = tree.data[0].children
					} else {
						this.treeList = tree.data
					}
					if (this.customer.org_business_id) {
						this.customerInfo = this.customer
					} else {
						if (this.treeList[0].label == '商户') {
							this.customerInfo = this.treeList[0]
						} else {
							this.customerInfo = this.treeList[0].children[0]
						}
					}
					this.customerInfo.logoName = this.customerInfo.org_name.slice(0,1)
					console.log(this.customerInfo.org_name,'this.customerInfo.org_name')
					this.channelTreeData=tree.data.filter((item)=>{return item.label=='渠道'})
					this.channelTreeData=this.channelTreeData.map((item) => {
						return {
							...item,
							channelImage: true,
							children: item.children_count?item.children.map((child) => {
								return {
									...child,
									userImage: true,
								}
							}):[]
						}
					})
					this.userTreeData=tree.data.filter((item)=>{return item.label=='商户'})
					this.userTreeData=this.userTreeData.map((item) => {
						return {
							...item,
							userImage: true
						}
					})
					this.storeTreeData=tree.data.filter((item)=>{return item.label=='门店'})
					// console.log(this.channelTreeData,'channelTreeData获取的组织数据')
					// console.log(this.userTreeData,'userTreeData获取的组织数据')
					// console.log(this.storeTreeData,'storeTreeData获取的组织数据')
					this.setCustomer(this.customerInfo)
					this.org_business_id = this.customer.org_business_id
					this.treeLabel = this.customer.label
					this.deviceCount = this.customer.device_count
					// console.log(this.customer, '获取当前的this.customer1')
					// 请求图表数据
					if(this.org_business_id){
						this.getServerData(this.org_business_id)
						this.getUserDataDetail(this.org_business_id)
						this.getFoodData(this.org_business_id)
						this.getFlavourData(this.org_business_id)
						this.getCookCopiesData(this.org_business_id)
						this.getDeviceDetailData(this.org_business_id)
					}
					
				}
				if(this.treeList[0].label=='渠道'){
					// console.log(this.treeList,'this.treeListthis.treeListthis.treeList')
					this.treeList = this.treeList.map((item) => {
						return {
							...item,
							channelImage: true,
							children: item.children_count?item.children.map((child) => {
								return {
									...child,
									userImage: true,
								}
							}):[]
						}
					})
				}
				
			},
			// 处理小数取值
			formatDecimal(num, decimal) { //num 传入小数, decimal 保留几位小数
				var _num = num.toString()
				var index = _num.indexOf('.')
				if (index !== -1) {
					_num = _num.substring(0, decimal + index + 1)
				} else {
					_num = _num.substring(0)
				}
				return parseFloat(_num).toFixed(decimal)
			},
			getYearMonthDay(value) {
				const date = new Date(value);
				const year = date.getFullYear()
				const month = date.getMonth() + 1
				const day = date.getDate()
				return this.daysFromDate(year, month, day)
			},
			getMidnightTimestamp(date) {
			    if (!(date instanceof Date)) {
			        date = new Date(); // 如果没有提供日期，则默认为当前日期
			    }
			    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0).getTime();
			},
			daysFromDate(year, month, day) {
				// 将参数转换为毫秒
				const startDate = new Date(year, month - 1, day).getTime();
				const currentDate = new Date().getTime();
				const midnightTimestamp2 = this.getMidnightTimestamp();
				var midnight = new Date();
				midnight.setHours(0, 0, 0, 0); 
				var midnightTimestamp = midnight.getTime();
				var diff = (currentDate - startDate) / (1000 * 60 * 60 * 24);
				if(currentDate>midnightTimestamp){
					this.isPlus=true
					return Math.abs(this.formatDecimal(diff,0))
				}else{
					return Math.abs(this.formatDecimal(diff,0))
				}
			},
			// 获取商户运营数据
			async getUserDataDetail(id) {
				this.operationData.loading = true
				let res
				if (this.treeLabel == '商户') {
					res = await this.API.home.getUserData(this.org_business_id, this
						.operationTitleIndex)
				} else {
					res = await this.API.home.getStoreData(this.org_business_id, this
						.operationTitleIndex)
				}
				if (res.code == 200) {
					this.operationData = res.data
					if (!res.data.cur) {
						this.operationData.cur = {
							cooked_times: 0,
							consumed_minute: 0,
							consumed_energy: 0
						}
					}
					if (res.data.latest_time!=null) {
						this.latest_time = res.data.latest_time.replace('T', ' ').split(' ')[1]
						this.latest_time=(this.latest_time.split(':'))[0]+':'+(this.latest_time.split(':'))[1]
						this.latest_time_total=this.getYearMonthDay(res.data.latest_time)
					}else{
						this.latest_time='暂无'
					}
					if (this.operationData.cur && this.operationData.cur.consumed_energy) {
						this.operationData.cur.consumed_energy = this.formatDecimal(this
							.operationData.cur.consumed_energy, 1)
					}
					if (this.operationData.cur && this.operationData.cur.consumed_minute) {
						this.operationData.cur.consumed_minute = this.formatDecimal(this
							.operationData.cur.consumed_minute, 1)
					}
					if (this.operationData.pre && this.operationData.pre.cooked_times) {
						this.operationData.pre.cooked_times = this.formatDecimal(this.operationData
							.pre.cooked_times, 1)
					}
					if (this.operationData.pre && this.operationData.pre.consumed_energy) {
						this.operationData.pre.consumed_energy = this.formatDecimal(this
							.operationData.pre.consumed_energy, 1)
					}
					if (this.operationData.pre && this.operationData.pre.consumed_minute) {
						this.operationData.pre.consumed_minute = this.formatDecimal(this
							.operationData.pre.consumed_minute, 1)
					}
					if (this.operationData.cur && this.operationData.pre && this.operationData.cur
						.cooked_times && Number(this
						.operationData.pre.cooked_times)) {
						this.operationData.pre.cooked_times = this.formatDecimal(this.operationData
							.pre.cooked_times, 1)
						let res=this.operationData.cur.cooked_times - this.operationData.pre.cooked_times
						this.operationData.timeData = this.formatDecimal(res / this.operationData.pre.cooked_times, 2) 
						this.operationData.timeData=this.formatDecimal(this.operationData.timeData*100,1)
						// this.operationData.timeData=Math.abs(this.operationData.timeData)
					} else {
						this.operationData.timeData = 0.00
					}
					if (this.operationData.cur && this.operationData.pre && this.operationData.cur
						.consumed_energy &&
						Number(this.operationData.pre.consumed_energy)) {
						this.operationData.pre.consumed_energy = this.formatDecimal(this
							.operationData.pre.consumed_energy, 1)
						this.operationData.energyData = this.formatDecimal(((this.operationData.cur
								.consumed_energy - this.operationData
								.pre.consumed_energy) / this.operationData.pre
							.consumed_energy), 2) * 100
						this.operationData.energyData=this.formatDecimal(this.operationData.energyData,1)
						// this.operationData.energyData=Math.abs(this.operationData.energyData)
					} else {
						this.operationData.energyData = 0.00
					}
					if (this.operationData.cur && this.operationData.pre && this.operationData.cur
						.consumed_minute &&
						Number(this.operationData.pre.consumed_minute)) {
						this.operationData.pre.consumed_minute = this.formatDecimal(this
							.operationData.pre.consumed_minute, 1)
						this.operationData.minuteData = this.formatDecimal(((this.operationData.cur
								.consumed_minute - this
								.operationData.pre.consumed_minute) / this.operationData
							.pre.consumed_minute), 2) * 100
						this.operationData.minuteData=this.formatDecimal(this.operationData.minuteData,1)
						// this.operationData.minuteData=Math.abs(this.operationData.minuteData)
					} else {
						this.operationData.minuteData = 0.00
					}
					
					this.operationData.loading = false
				}
				// console.log(this.operationData, 'res获取商户运营数据')
			},
			clickChannel(index) {
				this.treeList[index].channelImage = !this.treeList[index].channelImage
				// console.log(this.treeList[index].channelImage,'this.treeList[index].channelImage')
			},
			clickUser(index, childIndex) {
				if(childIndex>=0){
					this.treeList[index].children[childIndex].userImage = !this.treeList[index].children[
						childIndex].userImage
					this.channelTreeData[index].children[childIndex].userImage = !this.channelTreeData[index].children[
						childIndex].userImage
				}
				this.userTreeData[index].userImage = !this.userTreeData[index].userImage
			},
			getCurrentInfo(row) {
				this.deviceList = []
				this.customerInfo = row
				this.customerInfo.logoName = this.customerInfo.org_name.slice(0,1)
				console.log(this.customerInfo,'this.customerInfo22')
				this.setCustomer(this.customerInfo)
				// console.log(this.customer, '获取当前的this.customer2')
				this.org_business_id = this.customer.org_business_id
				this.treeLabel = this.customer.label
				this.deviceCount = this.customer.device_count
				// 请求图表数据
				this.getServerData(this.org_business_id)
				this.getDeviceDetailData(this.org_business_id)
				this.getUserDataDetail(this.org_business_id)
				this.getFoodData(this.org_business_id)
				this.getFlavourData(this.org_business_id)
				this.getCookCopiesData(this.org_business_id)
				this.$refs.popup.close()
			},
			changePopup() {
				this.$refs.popup.open('bottom')
			},
			colsePopup() {
				this.$refs.popup.close()
				this.value = []
			},
			// 获取设备泵、养锅数据
			async getDeviceDetailData(id){
				let res
				if (this.treeLabel == '商户') {
					res = await this.API.home.getDeviceDetail(1,this.org_business_id)
				} else {
					res = await this.API.home.getStoreDeviceDetail(1,this.org_business_id)
				}
				this.deviceCardData=res
			},
			// 获取菜品排行数据并且渲染图
			async getServerData(id) {
				this.chartData =JSON.parse(JSON.stringify({}));
				this.cookingCategoryLoading = true
				let res
				if (this.treeLabel == '商户') {
					res = await this.API.home.getMenuCategoryData(this.org_business_id, this
						.menuCategoryIndex)
				} else {
					res = await this.API.home.getStoreMenuCategoryData(this.org_business_id, this
						.menuCategoryIndex)
				}
				this.categoryTotal = res.paging.total_records
				// 补齐
				const fillArr = Array.from({ length: 10 - this.categoryTotal }, () => ({ c: 0, recipe_category_name: '-' }));
				const result = res.data.concat(fillArr);
				setTimeout(() => {
					let dataDetail = {
						categories: result.map((item) => {
							if(item.recipe_category_name.length>8){
								return item.recipe_category_name.slice(0,8)+'...'
							}else{
								return item.recipe_category_name
							}
							
						}),
						series: [{
							name:'',
							data: result.map((item) => {
								return item.c
							})
						}]
					};
					this.chartData = JSON.parse(JSON.stringify(dataDetail));
					this.cookingCategoryLoading = false
				}, 0);
			},
			// 获取烹饪时段炒至份数
			async getCookCopiesData(id) {
				this.cookingChartData =JSON.parse(JSON.stringify({}));
				this.cookingTimeLoading = true
				let res
				if (this.treeLabel == '商户') {
					res = await this.API.home.getUserCookCopiesData(this.org_business_id, this
						.cookingTimeIndex)
				} else {       
					res = await this.API.home.getStoreCookCopiesData(this.org_business_id, this
						.cookingTimeIndex)
				} 
			
				let arr = []
				for (let key in res.data) {
					//用for循环转换resObj对象
					arr.push(res.data[key]);
				}
				let max = arr[0].copies;
				for (let i = 1; i < arr.length; i++) {
					if (arr[i].copies > max) {
						max = arr[i].copies;
					}
				}
				this.cookingTimeLoading = false
				setTimeout(() => {
					let dataDetail = {
						categories: this.generateTimeAxis(),
						series: [{
							name: "炒制份数",
							data: this.generateRandomArray(arr),
							label: {
								show: false,
								position: 'top',
								formatter: (item) => {
									// 这里的item.data代表当前数据值，item.max代表该系列的最大值
									if (item.data === item.max) {
										return item.value; // 只显示最大值
									} else {
										return ''; // 其他值不显示
									}
								}
							}
						}]
					};
					this.cookingChartData = JSON.parse(JSON.stringify(dataDetail));
				}, 0);
			},
			generateTimeAxis() {
				var axis = [];
				for (var hour = 0; hour < 24; hour++) {
					for (var minute = 0; minute < 60; minute += 30) {
						var timeStr = ('0' + hour).slice(-2) + ':' + ('0' + minute).slice(-2);
						axis.push(timeStr);
					}
				}
				return axis;
			},
			generateRandomArray(arr) {
				let array = arr.map(item=>item.copies)
				return array;
			},
			drawCharts() {
			  uChartsInstance['flavour'] = new uCharts(this.opts);
			},
			flavourTap(e){
				
			},
			// 获取食物用量数据并且渲染图
			async getFoodData(id) {
				this.foodChartData=JSON.parse(JSON.stringify({}));
				this.foodLoading = true
				let res
				if (this.treeLabel == '商户') {
					res = await this.API.home.getUserFoodData(this.org_business_id, this.foodIndex)
				} else {
					res = await this.API.home.getStoreFoodData(this.org_business_id, this
						.foodIndex)
				}
				this.foodLoading = false
				this.foodTotal = res.paging.total_records
				const fillArr = Array.from({ length: 10 - this.foodTotal }, () => ({ c: 0, name: '-' }));
				const result = res.data.concat(fillArr);
				setTimeout(() => {
					//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
					let dataDetail = {
						categories: result.map((item) => {
							if(item.name.length>8){
								return item.name.slice(0,8)+'...'
							}else{
								return item.name
							}
						}),
						series: [{
							name: "食材用量",
							data: result.map((item) => {
								item.c = Number(item.c).toFixed(1)
								return item.c
							})
						}]
					};
					this.foodChartData = JSON.parse(JSON.stringify(dataDetail));
				},0);
			},
			// 获取调料用量数据并且渲染图
			async getFlavourData(id) {
				this.flavourChartData =JSON.parse(JSON.stringify({}));
				this.flavourLoading=true
				let res
				if (this.treeLabel == '商户') {
					res = await this.API.home.getUserFlavourData(this.org_business_id, this
						.flavourIndex)
				} else {
					res = await this.API.home.getStoreFlavourData(this.org_business_id, this
						.flavourIndex)
				}
				this.flavourLoading=false
				this.flavourTotal = res.paging.total_records
				const fillArr = Array.from({ length: 5 - this.flavourTotal }, () => ({ c: 0, name: '-' }));
				const result = res.data.concat(fillArr);
				setTimeout(() => {
					//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
					let dataDetail = {
						categories: result.map((item) => {
							if(item.name.length>8){
								return item.name.slice(0,8)+'...'
							}else{
								return item.name
							}
						}),
						series: [{
							name: "调料用量",
							data: result.map((item) => {
								item.c = Number(item.c).toFixed(1)
								return item.c
							})
						}]
					};
					this.flavourChartData = JSON.parse(JSON.stringify(dataDetail));
				}, 0);
			},
			async toChangeStatus(val) {
				this.status = val
			},
			toDevicePage() {
				uni.navigateTo({
					url: `/homePages/pages/deviceList/deviceList?id=${this.org_business_id}&label=${this.treeLabel}`
				})
			},
			toCookingDetail(value){
				uni.navigateTo({
					url:`/homePages/pages/cookingDataDetail/cookingDetail?org_business_id=${this.org_business_id}&label=${this.treeLabel}&title=${value}`
				})
			},
			toFlavourDetail(value){
				this.setDeviceDetailData(this.deviceCardData)
				uni.navigateTo({
					url:`/homePages/pages/deviceOperationDetail/deviceOperationDetail?title=${value}&org_business_id=${this.org_business_id}&label=${this.treeLabel}`
				})
			},
			toSeeAll(value){
				uni.navigateTo({
					url:`/homePages/pages/rankingOfType/rankingOfType?title=${value}&label=${this.treeLabel}&org_business_id=${this.org_business_id}`
				})
			}
		},

		onPullDownRefresh: function() {
			// console.log('上拉刷新了')
			this.getServerData(this.org_business_id)
			this.getUserDataDetail(this.org_business_id)
			this.getFoodData(this.org_business_id)
			this.getFlavourData(this.org_business_id)
			this.getCookCopiesData(this.org_business_id)
			this.getDeviceDetailData(this.org_business_id)
			uni.stopPullDownRefresh()
			// this.deviceList = []
			// this.page=1
			// this.toSubmit(this.customer.org_business_id, this.page)

		},

		onLoad() {
			// 根据vuex权限设置数据
			if (this.authority.rootMenu) this.tabItems = tabbar.tabItems1
			else this.tabItems = tabbar.tabItems2
			this.currentTab = this.authority.currentTab
			this.getTreeList()
			
		},
		onShow() {
			this.customerInfo = this.customer
			// this.customerInfo.logoName = this.customer.org_name.slice(0,1)
			this.getTreeList()
			console.log(this.customerInfo, 'this.customerInfoonshow')
		},
		onReady() {
			// this.getServerData();
			
		}
	}
</script>

<style lang="scss" scoped>
	/deep/.chartsview{
		// padding-top: 8px !important;
		//padding-bottom: 8px !important;
	}
	uni-collapse {
		overflow-y: scroll;
		.uni-collapse-item__title {
			height: 56px;
			padding: 17px;
			box-sizing: border-box;
			// background-color: rgba(245, 245, 245, 1);
		}

		uni-collapse-item {
			font-size: 16px;
			overflow-y: scroll;
			// background-color: #264FF7;
			.chooseName {
				// width: 60%;
				white-space: nowrap;
				/* 对于溢出的代码进行隐藏 */
				overflow: hidden;
				/* 剪裁后面的代码，并更改为省略号 */
				text-overflow: ellipsis;
			}

			.content {
				.contentBox {
					display: flex;
					align-items: center;
				}

				.text {
					height: 56px;
					line-height: 56px;
					font-size: 16px;
					white-space: nowrap;
					/* 对于溢出的代码进行隐藏 */
					overflow: hidden;
					/* 剪裁后面的代码，并更改为省略号 */
					text-overflow: ellipsis;
				}
			}
		}
	}

	.example-body {
		flex-direction: column;
		flex: 1;
	}

	.popup-content {
		padding: 15px 0px;
		height: 880upx;
		overflow-y: scroll;
		background-color: #fff;
	}


	.box-sizing {
		box-sizing: border-box;
	}

	.operationBox-content {
		overflow-x: hidden;
	}

	.index-page {
		width: 100%;
		// box-sizing: border-box;
		background-color: rgba(245, 245, 245, 1);
		padding-bottom: 60px;
		padding-top: 130px;

		// height: calc(100vh - 200px); // 解决页面无内容时上下滚动问题 高度默认44px + padding-top 20px
		.flavourBox {
			padding: 32upx 18upx;
			width: 718upx;
			margin-bottom: 96upx;
			.flavourTitle {
				display: flex;
				align-items: center;
				justify-content: space-between;

				.titleLeft {
					font-size: 32upx;
					color: rgba(100, 101, 102, 1);
				}

				.titleRight {
					width: 336upx;
					display: flex;
					height: 52upx;
					line-height: 52upx;
					font-size: 24upx;
					color: rgba(150, 151, 153, 1);
					border-radius: 32upx;
					background-color: rgba(255, 255, 255, 1);

					.titleItem {
						width: 25%;
						text-align: center;
					}

					.activeTitleItem {
						width: 44px;
						height: 52upx;
						border-radius: 16px;
						color: rgba(22, 93, 255, 1);
						background-color: rgba(190, 218, 255, 1);
					}
				}
			}
		}



		.foodBox {
			width: 718upx;
			padding: 32upx 18upx;

			.foodTitle {
				display: flex;
				align-items: center;
				justify-content: space-between;

				.titleLeft {
					font-size: 32upx;
					color: rgba(100, 101, 102, 1);
				}

				.titleRight {
					width: 336upx;
					display: flex;
					height: 52upx;
					line-height: 52upx;
					font-size: 24upx;
					color: rgba(150, 151, 153, 1);
					border-radius: 32upx;
					background-color: rgba(255, 255, 255, 1);

					.titleItem {
						width: 25%;
						text-align: center;
					}

					.activeTitleItem {
						width: 44px;
						height: 52upx;
						border-radius: 16px;
						color: rgba(22, 93, 255, 1);
						background-color: rgba(190, 218, 255, 1);
					}
				}
			}
		}

		.cookingCategoryBox {
			width: 718upx;
			padding: 32upx 18upx;

			// margin-top: 18upx;
			.cookingTimeTitle {
				height: 116upx;
				display: flex;
				align-items: center;
				justify-content: space-between;

				.titleLeft {
					font-size: 32upx;
					color: rgba(100, 101, 102, 1);
				}

				.titleRight {
					width: 336upx;
					display: flex;
					height: 52upx;
					line-height: 52upx;
					font-size: 24upx;
					color: rgba(150, 151, 153, 1);
					border-radius: 32upx;
					background-color: rgba(255, 255, 255, 1);

					.titleItem {
						width: 25%;
						text-align: center;
					}

					.activeTitleItem {
						width: 44px;
						height: 52upx;
						border-radius: 16px;
						color: rgba(22, 93, 255, 1);
						background-color: rgba(190, 218, 255, 1);
					}
				}
			}
		}

		.cookingTimeBox {
			// padding: 32upx 18upx;
			width: 718upx;

			// margin-top: 18upx;
			.cookingTimeTitle {
				height: 116upx;
				display: flex;
				align-items: center;
				justify-content: space-between;

				.titleLeft {
					font-size: 32upx;
					color: rgba(100, 101, 102, 1);
				}

				.titleRight {
					width: 336upx;
					display: flex;
					height: 52upx;
					line-height: 52upx;
					font-size: 24upx;
					color: rgba(150, 151, 153, 1);
					border-radius: 32upx;
					background-color: rgba(255, 255, 255, 1);

					.titleItem {
						width: 25%;
						text-align: center;
					}

					.activeTitleItem {
						width: 44px;
						height: 52upx;
						border-radius: 16px;
						color: rgba(22, 93, 255, 1);
						background-color: rgba(190, 218, 255, 1);
					}
				}
			}
		}

		.operationBox {
			// width: 100%;
			// margin-top: 132px;
			// padding: 4upx 18upx;
			padding: 32upx 18upx;
			padding-bottom: 0upx;
			padding-top: 0upx;
			.operationTitle {
				display: flex;
				height: 116upx;
				align-items: center;
				justify-content: space-between;

				.titleLeft {
					font-size: 32upx;
					color: rgba(100, 101, 102, 1);
				}

				.titleRight {
					width: 336upx;
					display: flex;
					height: 52upx;
					line-height: 52upx;
					font-size: 24upx;
					color: rgba(150, 151, 153, 1);
					border-radius: 32upx;
					background-color: rgba(255, 255, 255, 1);

					.titleItem {
						width: 25%;
						text-align: center;
					}

					.activeTitleItem {
						width: 44px;
						height: 52upx;
						border-radius: 16px;
						color: rgba(22, 93, 255, 1);
						background-color: rgba(190, 218, 255, 1);
					}
				}
			}
			.deviceCard{
				display: flex;
				justify-content: space-between;
				margin-top: 32upx;
				.deviceCardItem{
					width: 228upx;
					min-height: 240upx;
					border-radius:4px;
					padding:16upx;
					box-sizing: border-box;
					background-color: rgba(255, 255, 255, 1);
					.cardTop{
						display: flex;
						align-items: center;
						margin-bottom: 32upx;
						color: rgba(150, 151, 153, 1);
					}
				}
			}
			.operationCard {
				display: flex;
				justify-content: space-between;

				// 二级菜单样式
				/deep/ .menuInfo_second_level {
					position: relative;
					width: 100%;
					// height: 320rpx;
					padding: 16upx;
					overflow: hidden;
					transition: .2s all;
					background-color: #fff;

					&.active {
						opacity: 0;
					}

					.menuInfo_second_level_item {
						display: flex;
						align-items: center;
						width: 100%;
						height: 115rpx;
						padding: 0 55rpx;
						box-sizing: border-box;
						margin-bottom: 5rpx;
						background-color: #fff;

						&:last-child {
							margin: 0;
						}

						.menuInfo_item {
							display: flex;
							align-items: center;
						}

						.iconfont_nodata {
							width: 100%;
							display: flex;
							align-items: center;
							justify-content: center;

							>text {
								color: #9a9a9a;
							}
						}
					}

					.iconfont_loading {
						position: absolute;
						left: 0;
						top: 0;
						right: 0;
						bottom: 0;
						margin: auto;
						width: 80rpx;
						height: 80rpx;
						display: flex;
						align-items: center;
						justify-content: center;
						animation: rotate 1s infinite;

						@keyframes rotate {
							0% {
								transform: rotate(0deg);
							}

							100% {
								transform: rotate(360deg);
							}
						}
					}
				}

				.cardItem {
					width: 228upx;
					min-height: 320upx;
					border-radius: 4px;
					background: rgba(255, 255, 255, 1);
					padding: 16upx;
					box-sizing: border-box;

					.cardTitle {
						font-size: 14px;
						font-weight: 400;
						color: #969799;
						display: flex;
						align-items: center;
					}

					.cardDes {
						margin-top: 16upx;
						font-size: 11px;
						height: 36upx;
						line-height: 36upx;
						color: rgba(200, 201, 204, 1);
						text-align: center;
					}

					.cardData {
						margin-top: 44upx;
						margin-bottom: 40upx;

						.count {
							font-size: 48upx;
							font-weight: 500;
							color: rgba(0, 0, 0, 1);
						}
					}
				}
			}
		}

		// padding: 32rpx;
		.tab_title {
			width: 100%;
			height: 78px !important; //这个是固定的44px（所有小程序顶部高度都是 = 44px + 手机系统状态栏高度）
			line-height: 78px;
			text-align: center;
			// background-color: #d00;
			background-color: #264FF7 !important;
			position: fixed;
			top: 0;
			z-index: 9999;
			color: #fff;
			font-weight: 500;

			.menu_btn {

				// width: 100upx !important;
				// background-color: #ffffff; //这个是小程序默认的标题栏背景色
				// overflow: hidden;
				.selectShop {
					min-width: 460upx;
					height: 56upx;
					line-height: 56upx;
					display: flex;
					align-items: center;
					// margin-left: 32upx;
					// padding-top: 12upx;
					color: #fff;

					.shopLogo {
						width: 48upx;
						height: 48upx;
						font-size: 32upx;
						text-align: center;
						line-height: 48upx;
						border-radius: 50%;
						background-color: rgba(163, 182, 255, 1);
						color: #264FF7;
						margin-right: 16upx;
					}

					.shopName {
						width: 80%;
						text-align: left;
						color: #fff;
						font-size: 36upx;
						font-weight: 400;
						white-space: nowrap;
						/* 对于溢出的代码进行隐藏 */
						overflow: hidden;
						/* 剪裁后面的代码，并更改为省略号 */
						text-overflow: ellipsis;
					}
				}

				// position: fixed; //行内式写了固定定位--目的是去掉下划页面一起滚动问题
				.arrowleft {
					position: absolute;
					top: 50%;
					left: 50%;
					transform: translate(-160%, -50%) !important;
					-webkit-transform: translate(-160%, -50%) !important;
				}

				.text_box {
					width: 1rpx;
					height: 20px;
					background-color: #ddd;
					position: absolute;
					top: 50%;
					left: 50%;
					transform: translate(-50%, -50%) !important;
					-webkit-transform: translate(-50%, -50%) !important;
				}

				.home {
					position: absolute;
					top: 50%;
					left: 50%;
					transform: translate(60%, -50%) !important;
					-webkit-transform: translate(60%, -50%) !important;
				}
			}
		}

		.content_box {
			width: 100vw;

			// height: calc(100vh - 88px - 92upx);
			.content_box_top {
				height: 176upx;
				background-color: #264FF7;

				// padding-top: 30upx;
				.tabs {
					width: 558upx;
					height: 116upx;
					margin: 0 auto;
					display: flex;
					justify-content: space-between;
					padding-top: 30upx;

					.tab {
						text-align: center;

						.tabName {
							color: #8399F2;
							font-size: 22upx;
						}

						.tabCount {
							font-size: 48upx;
							margin-top: 8upx;
						}
					}
				}
			}

			.menuEmpty {
				width: 298upx;
				text-align: center;
				margin: 0 auto;
				margin-top: 170upx;
				padding-top: 140px;

				.emptyTip {
					font-size: 24upx;
					color: rgba(166, 166, 166, 1);
					margin-top: 48upx;
				}
			}

			.device_list {

				// height: calc(100vh - 88px - 92upx);
				.device_list_top {
					width: 752upx;
					height: 72upx;
					font-size: 24upx;
					display: flex;
					justify-content: space-between;
					align-items: center;
					color: #999999;

					.shop_name {
						display: flex;
						align-items: center;
						margin-left: 32upx;

						.circle {
							width: 12upx;
							height: 12upx;
							border-radius: 50%;
							background-color: #999999;
							margin-right: 18upx;
						}
					}

					.device_count {
						display: flex;
						align-items: center;
						margin-right: 32upx;

						.count {
							margin-right: 18upx;
						}
					}
				}

				.list {

					// width: 728upx;
					.item {
						width: 728upx;
						min-height: 200upx;
						border-radius: 8upx;
						margin: 0 auto;
						padding: 18upx;
						background-color: #fff;
						margin-top: 16upx;
						box-sizing: border-box;

						.payContainer {
							// width: 690upx;
							height: 72upx;
							display: flex;
							align-items: center;
							margin-top: 16upx;
							// justify-content: space-between;
							font-size: 22upx;
							color: #A6A6A6;

							border-top: 1px solid #FAFAFA;
						}

						.itemTop {
							display: flex;
							justify-content: space-between;

							.itemRight {
								color: #264FF7;
							}

							.itemLeft {
								display: flex;

								.image {
									width: 128upx;
									height: 128upx;
									line-height: 128upx;
									text-align: center;
									margin-top: 10upx;
									border-radius: 8upx;
									background-color: rgba(38, 79, 247, 0.1);
									margin-right: 18upx;
								}

								.deviceInfo {
									.deviceName {
										font-size: 32upx;
										margin-bottom: 16upx;
									}

									.deviceCode {
										color: rgba(166, 166, 166, 1);
										font-size: 24upx;
										margin-bottom: 16upx;
									}

									.status {
										width: 82upx;
										height: 32upx;
										line-height: 32upx;
										text-align: center;
										font-size: 20upx;
										border-radius: 8upx;
									}

									.blue {
										background-color: rgba(38, 79, 247, 0.1);
										color: rgba(38, 79, 247, 1);
									}

									.gray {
										color: #808080;
										background-color: #E5E5E5;
									}

									.red {
										color: #D43030;
										background-color: #F7EAEA;
									}

									.green {
										color: #43CF7C;
										background-color: #F8FFEE;
									}
								}
							}
						}

					}
				}
			}
		}
	}
</style>