<template>
  <!-- <view> <checkbox checked="true"></checkbox><text>Hello</text> </view> -->
  <view
    style="
      display: flex;
      flex-direction: column;
      height: 100vh;
      background-color: beige;
    "
  >
    <label> <checkbox @click="clickAll" :checked="checkAll" /> all </label>
    <template v-for="(item, index) in list">
      <label>
        <checkbox
          :value="item.v"
          :checked="item.checked"
          style="transform: scale(0.7)"
        />
        <text>{{ item.v }}</text>
      </label>
    </template>
  </view>
</template>
<script>
import { mapMutations, mapState } from "vuex";
export default {
  data() {
    return {
      checkAll: true,
      list: [{ v: "@", checked: true }],
    };
  },
  /**
   *
   */
  watch: {
    list: {
      handler(nv, ov) {
        console.log('watch invoke');
      },
      deep: true,
    },
  },
  methods: {
    clickAll() {
      this.checkAll = !this.checkAll;
    //   console.log(this.checkAll);

      // console.log('all', e);
      this.list.forEach((el) => {
        el.checked = this.checkAll;
      });
    },
  },
  onLoad() {
    setTimeout(() => {
      const l_ = "abcdef".split("");
      let ll_ = [];
      for (let i = 0; i < l_.length; i++) {
        //   console.log(l_[i]);

        ll_.push({
          v: l_[i],
          i,
          checked: i % 2 == 0,
        });
      }
      this.list = ll_;
    }, 1);
  },
};
</script>
