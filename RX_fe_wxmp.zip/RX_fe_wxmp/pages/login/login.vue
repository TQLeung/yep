<template>
	<view class="content">
		<view class="content-title">
			<image class="content-title-image" src="../../static/image/wx_title.png" mode=""></image>
		</view>
		<view class="content-text">
			欢迎您
		</view>
		<view class="content-input-all">
			<view class="content-input" style="font-size: 36upx;">
				<input type="text" placeholder-class="placeholder-style" v-model:value.trim="userName"
					placeholder="请输入用户名" maxlength="11" placeholder-style="color:rgba(27, 27, 33, 0.3);"
					auto-focus="true">
			</view>
			<view class="content-input" style="display: flex;justify-content: space-between;">
				<view style="font-size: 36upx;">
					<input v-model:value.trim="password" :password="isOpen" placeholder="请输入密码"
						placeholder-style="color:rgba(27, 27, 33, 0.3);" auto-focus="true">
				</view>
				<view v-if="password">
					<image @tap="changeIsOpen" v-if="!isOpen" style="height: 40upx;width: 48upx;"
						src="../../static/image/open.png" mode=""></image>
					<image @tap="changeIsOpen" v-else style="height: 40upx;width: 48upx;"
						src="../../static/image/hidePassword.png" mode=""></image>
				</view>
			</view>
		</view>
		<view class="content-button">
			<button class="btn" v-if="!userName.length">登录</button>
			<button class="submitBtn" v-else @click="toSubmit">登录</button>
		</view>
		<view class="content-tip">
			忘记密码？请联系售后服务获取账号与密码
		</view>
		<view class="content-contact">
			联系方式：<text style="color:rgba(38, 79, 247, 1) ;" @tap="toCall">400-870-7200</text>
		</view>
	</view>
</template>

<script>
	import {
		mapMutations,
	} from 'vuex'
	export default {
		
		data() {
			return {
				userName: '',
				password: '',
				code: '',
				isOpen: 'false'
			}
		},
		onLoad() {
			if (uni.getStorageSync('token')) {
				uni.switchTab({
					url: '/pages/home/index'
				})
			}
		},
		methods: {
			...mapMutations('authority', ['updateRootMenu']),
			toCall() {
				// console.log('拨打电话')
				uni.makePhoneCall({
					phoneNumber: '400-870-7200'
				});
			},
			async toSubmit() {
				uni.showLoading({
					title: '加载中'
				});
				const resultLogin = await this.API.login.toLogin({
					name: this.userName,
					password: this.password
				})
				if (resultLogin.code == 400) {
					uni.hideLoading();
					uni.showToast({
						title: '账号或密码不对',
						icon: 'error'
					})

				} else {
					// uni.hideLoading();
					uni.login({
						provider: 'weixin',
						success: async ({
							code
						}) => {
							// 这里发送请求获取openid code 码只能使用一次！！！！
							// DEVVVVV 暂时去除微信支付相关功能
							// const openId = await this.API.login.getOpenId(code)
							// uni.setStorageSync('openId', openId.data) // 存储本地
							// openid 获取成功后页面跳转
							// let res=resultLogin.data.menu_ids.split(',').find((item)=>item=='5')
							// uni.setStorageSync('showMenu',res)
							// console.log(res,'res')
							// if(!uni.getStorageSync('showMenu')){
							// 	this.updateRootMenu(false)
							// }else{
							// 	this.updateRootMenu(true)
							// }
							// console.log(res)
							uni.setStorageSync('userInfo', resultLogin.data)
							if(uni.getStorageSync('userInfo').menu_ids){
								let res=uni.getStorageSync('userInfo').menu_ids.split(',').find((item)=>item=='5')
								this.updateRootMenu(res)
								console.log(res,'获取的数据')
							}
							this.Tools.setToken(resultLogin.data.token)
							if (resultLogin.data.token) {
								uni.switchTab({
									url: '../../pages/home/index',
								})
							}
						}
					})
				}

				// console.log(this.code,'popo')
				// console.log(resultLogin)
				// console.log(this.userName,this.password)
			},
			changeIsOpen() {
				this.isOpen = !this.isOpen
			}
		}
	}
</script>

<style lang="less" scoped>
	page {
		height: 100%;
	}

	.content {
		width: 100%;
		height: 100vh;
		background-image: url('../../static/image/loginBg.png');
		background-size: 100% 100%;

		// background-repeat: no-repeat;
		.content-title {
			width: 640upx;
			height: 200upx;
			padding-top: 170upx;
			margin: 0upx 55upx 52upx 55upx;

			.content-title-image {
				width: 100%;
				height: 100%;
			}
		}

		.content-text {
			width: 192upx;
			height: 94upx;
			font-size: 64upx;
			font-weight: bold;
			margin: 0 auto;
			margin-bottom: 116upx;
			color: rgba(38, 79, 247, 1);
		}

		.content-input-all {
			.content-input {
				width: 622upx;
				margin: 0 auto;
				padding-bottom: 24upx;
				border-bottom: 1upx solid rgba(27, 27, 33, 0.15);

				.placeholder-style {
					font-size: 28upx;
				}
			}

			.content-input:last-child {
				margin-top: 88upx;

			}
		}

		.content-button {
			margin-top: 88upx;

			.btn {
				width: 622upx;
				height: 104upx;
				font-size: 36upx;
				border-radius: 274upx;
				border-color: transparent;
				line-height: 104upx;
				color: white;
				background-color: rgba(38, 79, 247, 0.2);
			}

			.submitBtn {
				width: 622upx;
				font-size: 36upx;
				height: 104upx;
				border-radius: 274upx;
				border-color: transparent;
				line-height: 104upx;
				color: white;
				background-color: rgba(38, 79, 247, 1);
			}
		}

		.content-tip {
			width: 532upx;
			height: 36upx;
			margin: 66upx auto 48upx auto;
			font-size: 28upx;
			color: rgba(166, 166, 166, 1);
		}

		.content-contact {
			width: 346upx;
			margin: 0 auto;
			font-size: 28upx;
			color: rgba(166, 166, 166, 1);
		}
	}
</style>