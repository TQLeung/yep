<template>
	<view class="passwordContent">
		<view class="tip">
			修改密码后将在设备/小程序/网页后台管理同步修改，如忘记密码，请联系售后服务！
		</view>
		<view class="inputContent">
			<!-- <input class="uni-input" focus placeholder="自动获得焦点" @input="$forceUpdate()"/> -->
			<view class="input">
				<view class="name">账号</view>
				<view class="">
					<input type="text" style="text-align: right;" v-model:value="userName" disabled="true">
				</view>
			</view>
			<view class="input">
				<view class="name">旧密码</view>
				<view class="">
					<input style="text-align: right;" @input="$forceUpdate()" v-model="oldPassword" placeholder="请输入旧密码" maxlength="11" placeholder-style="color:rgba(27, 27, 33, 0.3);">
				</view>
			</view>
			<view class="input">
				<view class="name">新密码</view>
				<view class="">
					<input style="text-align: right;" password @input="$forceUpdate()" v-model="newPassword" placeholder="请输入新密码" placeholder-style="color:rgba(27, 27, 33, 0.3);">
				</view>
			</view>
			<view class="input">
				<view class="name">确认密码</view>
				<view class="">
					<input style="text-align: right;" password v-model="confirmPassword" @blur="toConfirm" placeholder="再次输入新密码" placeholder-style="color:rgba(27, 27, 33, 0.3);">
				</view>
			</view>
		</view>
		<view class="btnContent">
			<button class="btn" @click="toChange">保存</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userName:uni.getStorageSync('userInfo').name,
				oldPassword:'',
				newPassword:'',
				confirmPassword:'',
				
			}
		},
		onLoad() {
				
		},
		methods: {
			async toChange(){
				const res=await this.API.login.changePassword({
					password_old:this.oldPassword,
					password_new:this.newPassword
				})
				if(res.code==0){
					uni.showToast({
						title:res.data,
						icon:'success'
					})
					this.oldPassword=''
					this.newPassword=''
					this.confirmPassword=''
					this.Tools.deleteToken()
					uni.navigateTo({
						url:'/pages/login/login'
					})
				}
			},
			toConfirm(){
				if(this.confirmPassword!=this.newPassword){
					uni.showToast({
						title:'两次密码请保持一致!',
						icon:'warn'
					})
				}
			}
		}
	}
</script>

<style scoped lang="less">
.passwordContent{
	width: 100%;
	height: 100vh;
	.btnContent{
		margin-top: 514upx;
		.btn{
			width: 686upx;
			height: 80upx;
			line-height: 80upx;
			color: #fff;
			border-radius:1750upx;
			background-color: #264FF7;
		}
	}
	.inputContent{
		width: 620upx;
		margin: 0 auto;
		margin-top: 16upx;
		.input{
			height: 112upx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-bottom: 1px solid #CCD6CB;
			font-size: 28upx;
		}
	}
	.tip{
		width: 634upx;
		height: 63upx;
		margin:0 auto;
		font-size: 24upx;
		margin-top: 38upx;
		color: #808080;
	}
}
</style>
