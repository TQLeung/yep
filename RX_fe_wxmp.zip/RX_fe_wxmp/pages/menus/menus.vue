<template>
	<view class="index-page">
		<!-- paddingTop不生效可换成marginTop -->
		<view class="tab_title" :style="{ paddingTop: statusBarHeight}">
			<!-- 左上角自定义样式 -->
			<view class="menu_btn flex-betwee box-sizing"
				:style="{ position: 'fixed', top: menuTop, left: menuRight, width: menuWidth, height: menuHeight, borderRadius: menuBorderRadius}">
				<!-- <image class="logo" src="/static/logo.png" @click="goStepPage"></image> -->
				<!-- <view class="tit">首页</view> -->
				<view class="selectShop" @click="changePopup">
					<view class="shopLogo" v-if="customerInfo.org_name">
						{{customerInfo.org_name.slice(0,1)}}
					</view>
					<view class="shopName" v-if="customerInfo.org_name">
						<text v-if="customerInfo.org_name.length<=7">{{customerInfo.org_name.slice(0,7)}}</text>
						<text v-else>{{customerInfo.org_name}}</text>
					</view>
				</view>
			</view>
		</view>
		<view class="searchContainer">
			<!-- <picker @change="bindVersionChange" :value="index" :range="versionList">
				<view class="version">
					{{versionList[versionIndex]}}
				</view>
			</picker> -->
			<view class="inputBox" @click="clickInput">
				<image src="../../static/image/searchBox.png" mode="" style="width: 36upx;height: 36upx;"></image>
				<input @input="getName" placeholder-style="font-size:24upx;" type="text" placeholder="搜索">
			</view>
			<view class="menuDown" @tap="toChooseMenu" v-if="showMenuDown">
				菜谱下载
			</view>
		</view>
		<view class="menuTabs">
			<picker @change="bindPickerChange" :value="index" :range="array">
				<view class="chooseView">
					<image style="width: 32upx;height: 32upx;margin-right: 12upx;" src="../../static/image/variety.png"
						mode=""></image>
					<view class="uni-input">{{array[index]}}</view>
				</view>
			</picker>
			<view :class="{'tab':true,'activetab':clickTab=='1'}" @click="selectTab('1')">
				全部
				<text v-if="index=='0'">
					<text v-if="totalInfo.total">（{{totalInfo.total}})</text>
					<text v-else>(0)</text>
				</text>
				<text v-if="index=='1'">
					<text v-if="menuTotal.total">（{{menuTotal.total}})</text>
					<text v-else>(0)</text>
				</text>
			</view>
			<view :class="{'tab':true,'activetab':clickTab=='2'}" @click="selectTab('2')">可下载
				<text v-if="index=='0'">
					<text v-if="totalInfo.can_download">（{{totalInfo.can_download}})</text>
					<text v-else>(0)</text>
				</text>
				<text v-if="index=='1'">
					<text v-if="menuTotal.can_download">（{{menuTotal.can_download}})</text>
					<text v-else>(0)</text>
				</text>
			</view>
			<view :class="{'tab':true,'activetab':clickTab=='3'}" @click="selectTab('3')">待审批
				<text v-if="index=='0'">
					<text v-if="totalInfo.pending">（{{totalInfo.pending}})</text>
					<text v-else>(0)</text>
				</text>
				<text v-if="index=='1'">
					<text v-if="menuTotal.pending">（{{menuTotal.pending}})</text>
					<text v-else>(0)</text>
				</text>
			</view>
			<view :class="{'tab':true,'activetab':clickTab=='4'}" @click="selectTab('4')">已停用
				<text v-if="index=='0'">
					<text v-if="totalInfo.pending">（{{totalInfo.confine}})</text>
					<text v-else>(0)</text>
				</text>
				<text v-if="index=='1'">
					<text v-if="menuTotal.pending">（{{menuTotal.confine}})</text>
					<text v-else>(0)</text>
				</text>
			</view>
		</view>
		<view class="scrollBox" v-if="index=='0'">
			<scroll-view v-if="true" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y list"
				@scrolltolower="lower">
			<view class="varietyContainer" v-if="varietyCount">
				<view class="varietyItem" @tap="toDetail(item)" v-for="item in varietyList" :key=item.id>
					<view class="varietyImage">
						<view class="varietyName">
							{{item.name}}
						</view>
					</view>
					<view class="varietyInfo">
						<view class="varietyTitle">
							<text v-if="item.name.length<10">{{item.name}}</text>
							<uni-tooltip :content="item.name" v-else>
								{{item.name.slice(0,9)}}...
							</uni-tooltip>
						</view>
						<view class="varietyCount">
							菜谱数量：{{item.recipe_num}}
						</view>
						<view class="varietyCount">
							下发次数：{{item.download_times}}
						</view>
					</view>
				</view>
			</view>
			<view class="menuEmpty" v-else>
				<image src="../../static/image/menuEmpty.png" mode="" style="width: 298upx;height: 250upx;"></image>
				<view class="emptyTip">
					{{showEmpty}}
				</view>
			</view>
			</scroll-view>
		</view>
		<view class="scrollBox" v-if="index=='1'">
			<scroll-view v-if="true" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y list"
				@scrolltolower="lower">
			<view class="menuContainer" v-if="menuCount">
				<view class="menuItem" @tap="toDetail(menu)" v-for="(menu,index) in menuList" :key="index">
					<view class="menuImage">
						<!-- <view class="menuTag">
							待审核
						</view> -->
						<view class="menuName">
							{{menu.recipe_category}}
						</view>
					</view>
					<view class="menuInfo">
						<view class="menuTitle">
							<text v-if="menu.recipe_category.length<10">{{menu.recipe_category}}</text>
							<uni-tooltip v-else :content="menu.recipe_category">
								{{menu.recipe_category.slice(0,9)}}...
							</uni-tooltip>
						</view>
						<view class="menuSpec">
							{{menu.spec}}g/{{menu.copies}}份
						</view>
						<view class="useCount">
							下发次数：{{menu.download_times}}
						</view>
					</view>
				</view>
			</view>
			<view class="menuEmpty" v-else>
				<image src="../../static/image/menuEmpty.png" mode="" style="width: 298upx;height: 250upx;"></image>
				<view class="emptyTip">
					{{showEmpty}}
				</view>
			</view>
			</scroll-view>
		</view>
		<uni-popup ref="popup" background-color="#fff">
			<view class="popup-content" v-if="labelAll!='总部'">
				<uni-collapse accordion>
					<uni-collapse-item v-for="item in channelTreeData" :name="item.org_business_id"
						:key="item.org_business_id">
						<template v-slot:title>
							<view style="height: 56px;line-height: 56px;display:flex;align-items: center;">
								<image src="../../static/image/channelLogo.png" mode=""
									style="width: 16px;height: 12px;margin-left: 18px;margin-right: 12px;"></image>
								<view class="chooseName">{{item.org_name}}</view>
							</view>
						</template>
						<view class="content" v-if="item.children&&item.label!='商户'">
							<view class="contentBox" v-for="child in item.children" :key="child.org_business_id"
								@tap="getCurrentInfo(child)">
								<image src="../../static/image/storeLogo.png" mode=""
									style="width: 14px;height: 12px;margin-left: 29px;margin-right: 12px;"></image>
								<view class="text">{{child.org_name}}</view>
							</view>
						</view>
					</uni-collapse-item>
				</uni-collapse>
				<uni-collapse accordion>
					<uni-collapse-item :show-arrow="false" v-for="item in userTreeData" :name="item.org_business_id"
						:key="item.org_business_id" @tap="getCurrentInfo(item)">
						<template v-slot:title>
							<view style="height: 56px;line-height: 56px;display:flex;align-items: center;">
								<image src="../../static/image/storeLogo.png" mode=""
									style="width: 16px;height: 12px;margin-left: 18px;margin-right: 12px;"></image>
								<view class="chooseName">{{item.org_name}}</view>
							</view>
						</template>
					</uni-collapse-item>
				</uni-collapse>
				<view style="text-align: center;margin-top: 20px;width: 100%;" @tap="colsePopup">
					取消
				</view>
			</view>
			<view class="popup-content" v-else>
				<uni-collapse accordion>
					<uni-collapse-item v-for="item in treeList" :name="item.org_business_id"
						:key="item.org_business_id">
						<template v-slot:title>
							<view style="height: 56px;line-height: 56px;display:flex;align-items: center;">
								<image src="../../static/image/channelLogo.png" mode=""
									style="width: 16px;height: 12px;margin-left: 18px;margin-right: 12px;"></image>
								<view class="chooseName">{{item.org_name}}</view>
							</view>
						</template>
						<view class="content" v-if="item.children&&item.label!='商户'">
							<view class="contentBox" v-for="child in item.children" :key="child.org_business_id"
								@tap="getCurrentInfo(child)">
								<image src="../../static/image/storeLogo.png" mode=""
									style="width: 14px;height: 12px;margin-left: 29px;margin-right: 12px;"></image>
								<view class="text">{{child.org_name}}</view>
							</view>
						</view>
					</uni-collapse-item>
				</uni-collapse>
				<view style="text-align: center;margin-top: 20px;width: 100%;" @tap="colsePopup">
					取消
				</view>
			</view>
		</uni-popup>
		<view class="">
			<CustomTabBar :items="tabItems" :currentIndex="1" @item-click="onTabClick"
			        :color="color" :selectedColor="selectedColor"></CustomTabBar>
		</view>
	</view>
</template>

<script>
	import {
		mapMutations,
		mapState
	} from 'vuex'
	import CustomTabBar from '@/uni_modules/niceui-tabBar/components/niceui-tabBar/niceui-tabBar.vue';
	import tabbar from '@/uni_modules/niceui-tabBar/common/tabbar.js'
	export default {
		computed: {
			...mapState('menus', ['customer']),
			...mapState('authority', ['authority'])
		},
		components: {
		   CustomTabBar  
		 },  
		data() {
			return {
				scrollTop: 0,
				currentTab: 0, // 当前选中的tab索引  
				tabItems: [],
				color: tabbar.color,
				selectedColor:tabbar.selectedColor,
				statusBarHeight: uni.getStorageSync('menuInfo').statusBarHeight, //状态栏的高度（可以设置为顶部导航条的padding-top）
				menuWidth: uni.getStorageSync('menuInfo').menuWidth,
				menuHeight: uni.getStorageSync('menuInfo').menuHeight,
				menuBorderRadius: uni.getStorageSync('menuInfo').menuBorderRadius,
				menuRight: uni.getStorageSync('menuInfo').menuRight,
				menuTop: uni.getStorageSync('menuInfo').menuTop,
				contentTop: uni.getStorageSync('menuInfo').contentTop,
				account_id: uni.getStorageSync('userInfo').account_id,
				userInfo: {},
				clickTab: '1',
				menuCount: 0,
				page: 1,
				showMenuDown:false,
				varietyCount: 0,
				array: ['菜品', '菜谱 '],
				index: 0,
				varietyList: [],
				menuList: [],
				channelTreeData:[],
				userTreeData:[],
				// , 'KUKE4.0'
				versionList: ['KUKE5.0'],
				versionIndex: 0,
				queryName: '',
				labelAll: '',
				totalInfo: {
					can_download: 0,
					total: 0,
					pending: 0
				},
				recipe_num: undefined,
				pending_num: undefined,
				confine_num: undefined,
				menuTotal: {
					can_download: 0,
					total: 0,
					pending: 0,
					confine:0
				},
				showEmpty: '暂未上传新菜谱',
				value: [],
				treeList: [],
				customerInfo: {}
			}
		},
		watch: {
			recipe_num: {
				deep: true,
				handler(newValue) {
					if (newValue) {
						this.showEmpty = '暂无搜索结果'
					}
				}
			},
			pending_num: {
				deep: true,
				handler(newValue) {
					if (newValue) {
						this.showEmpty = '暂无搜索结果'
					}
				}
			},
			queryName: {
				deep: true,
				handler(newValue) {
					if (newValue) {
						this.showEmpty = '暂无搜索结果'
					}
				}
			},
		},
		methods: {
			...mapMutations('menus', ['setCustomer']),
			...mapMutations('authority', ['changeTab']),
			onTabClick(index) { // 切换tab的函数，当选中某个tab时触发
					this.changeTab(index)
					this.currentTab=index
					// console.log('当前点击1', this.tabItems[index].pagePath,this.currentTab)
			       // if(index!=this.currentTab){
			            uni.switchTab({
			                url: '../../' + this.tabItems[index].pagePath
			            })
			       // }
				   
			     },
			async getVarietyListData(page,confine='') {
				uni.showLoading({
					title: '加载中'
				});
				const res = await this.API.menus.getVarietyList(this.page,this.customerInfo.org_business_id, this.queryName, this.recipe_num, this.pending_num,false,this.confine_num)
				if (res.code == 0) {
					uni.hideLoading();
					this.varietyCount = res.paging.total_records
					if (this.varietyList.length >= this.varietyCount) {
						return
					} else {
						this.varietyList = [...this.varietyList, ...res.data]
					}
				}
			},
			lower: function(e) {
				if (this.varietyList.length >= this.varietyCount) {
					return
				} else {
					this.getVarietyListData(this.page++)
				}
			},
			selectTab(val) {
				this.clickTab = val		
				this.page=1
				this.varietyList=[]
				if (val == '2') {
					this.recipe_num = 1
					this.pending_num = undefined
					this.confine_num = undefined
					if (this.index == '0') {
						this.getVarietyListData(1, 0)
					} else {
						this.getMenuListData()
					}
				} else if (val == '3') {
					this.recipe_num = undefined
					this.pending_num = 1
					this.confine_num = undefined
					if (this.index == '0') {
						this.getVarietyListData(1, 0)
					} else {
						this.getMenuListData()
					}
				}else if (val == '4') {
					this.recipe_num = undefined
					this.pending_num = undefined
					this.confine_num = 1
					if (this.index == '0') {
						this.getVarietyListData(1, 1)
					} else {
						this.getMenuListData()
					}
				} else {
					this.recipe_num = undefined
					this.pending_num = undefined
					this.confine_num = undefined
					if (this.index == '0') {
						this.getVarietyListData(1,0)
					} else {
						this.getMenuListData()
					}
				}
			},
			async getTreeList() {
				const tree = await this.API.menus.getTree()
				if (tree.code == 0) {
					if(tree.data[0].label=='总部'){
						this.labelAll='总部'
						this.treeList = tree.data[0].children
					}else{
						this.treeList = tree.data
					}
					if(this.customer){
						this.customerInfo =this.customer
					}else{
						if(this.treeList[0].label=='商户'){
							this.customerInfo = this.treeList[0]
						}else{
							this.customerInfo = this.treeList[0].children[0]
						}
					}
					this.channelTreeData=tree.data.filter((item)=>{return item.label=='渠道'})
					this.userTreeData=tree.data.filter((item)=>{return item.label=='商户'})
					this.setCustomer(this.customerInfo)
					// console.log(this.treeList,'this.treeList')
				}
			},
			changePopup() {
				this.$refs.popup.open('bottom')
			},
			colsePopup() {
				this.$refs.popup.close()
				this.value = []
			},
			async getMenuListData() {
				uni.showLoading({
					title: '加载中'
				});
				const res = await this.API.menus.getRelMenu(this.customerInfo.org_business_id, this.queryName, this
					.recipe_num, this.pending_num,this.confine_num)
				if (res.code == 0) {
					uni.hideLoading();
					this.menuList = res.data
					this.menuCount = res.paging.total_records
				}
			},
			async getTotals() {
				const res = await this.API.menus.getTotal(this.customerInfo.org_business_id)
				if (res.code == 0) {
					this.totalInfo = res.data
				}
			},
			async getMenuTotal() {
				const res = await this.API.menus.getMenuTotal(this.customerInfo.org_business_id)
				if (res.code == 0) {
					this.menuTotal = res.data
				}
			},
			toDetail(row) {
				if (this.index == '0') {
					uni.navigateTo({
						url: `/menusPages/pages/menuDetail/menuDetail?index=${this.index}&id=${row.id}&name=${row.name}&code=${row.code}`,
					})
				} else {
					uni.navigateTo({
						url: `/menusPages/pages/menuDetail/menuDetail?index=${this.index}&id=${row.sc_id}&name=${row.recipe_category}&spec=${row.spec}&copies=${row.copies}&recipe_category_id=${row.recipe_category_id}&code=${row.code}`,
					})
				}
			},
			getCurrentInfo(row) {
				this.menuList = []
				this.menuCount = 0
				this.varietyList=[]
				this.varietyCount = 0
				this.customerInfo = row
				this.setCustomer(this.customerInfo)
				this.$refs.popup.close()
				this.getVarietyListData(),
					this.getTotals()
			},
			toChooseMenu() {
				uni.navigateTo({
					url: '/menusPages/pages/recipeListForSendDevice/recipeListForSendDevice',
				})
			},
			bindPickerChange: function(e) {
				this.index = e.detail.value
				this.queryName = ''
				this.recipe_num = 0
				this.pending_num = 0
				this.clickTab = '1'
				this.showEmpty = '暂未上传新菜谱'
				if (this.index == 0) {
					this.getVarietyListData(),
						this.getTotals()
				} else {
					this.getMenuListData()
					this.getMenuTotal()
				}
			},
			bindVersionChange(e) {
				this.versionIndex = e.detail.value
			},
			getName(e) {
				this.queryName = e.target.value
				if (this.index == 0) {
					this.getVarietyListData()
				} else {
					this.getMenuListData()
				}
			},
			clickInput() {
				uni.navigateTo({
					url: `/menusPages/pages/queryMenus/queryMenus?index=${this.index}`
				})
			}
		},
		onLoad() {
			console.log("onLoad!!!");
			
			this.$forceUpdate();
			this.menuList = []
			this.menuCount = 0
			this.varietyList=[]
			this.varietyCount = 0
			this.userInfo = uni.getStorageSync('userInfo')
			if(this.userInfo.menu_ids){
				this.showMenuDown=(this.userInfo.menu_ids.split(',')).includes('6')
			}
			// 根据vuex权限设置数据
			if (this.authority.rootMenu) this.tabItems = tabbar.tabItems1
			else this.tabItems = tabbar.tabItems2
			this.currentTab=this.authority.currentTabss
			this.getTreeList()
			if(this.customerInfo.org_business_id){
				this.getVarietyListData(1, 0)
				this.getTotals()
			}
			
		},
		onShow() {
			console.log("onShow");
			this.menuList = []
			this.menuCount = 0
			this.varietyList=[]
			this.varietyCount = 0
			this.page=1
			this.customerInfo = this.customer
			if(this.customerInfo.org_business_id){
				this.getVarietyListData(1, 0)
				this.getTotals()
			}
			
		}
		// onReady() {
		// 	 uni.hideTabBar({index:1})
		// }
	}
</script>

<style lang="scss" scoped>
	
	@mixin flex {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
	}

	uni-collapse {
		.uni-collapse-item__title {
			height: 56px;
			padding: 17px;
			box-sizing: border-box;
			// background-color: rgba(245, 245, 245, 1);
		}

		uni-collapse-item {
			font-size: 16px;
			.chooseName{
				width:80%;
				white-space: nowrap;
				/* 对于溢出的代码进行隐藏 */
				overflow: hidden;
				/* 剪裁后面的代码，并更改为省略号 */
				text-overflow: ellipsis;
			}

			.content {
				.contentBox {
					display: flex;
					align-items: center;
				}
				.text {
					height: 56px;
					line-height: 56px;
					font-size: 16px;
					// width:90%;
					white-space: nowrap;
					/* 对于溢出的代码进行隐藏 */
					overflow: hidden;
					/* 剪裁后面的代码，并更改为省略号 */
					text-overflow: ellipsis;
				}
			}
		}
	}

	.example-body {
		flex-direction: column;
		flex: 1;
	}

	.popup-content {
		padding: 15px 0px;
		height: 540px;
		overflow-y: scroll;
		background-color: #fff;
	}

	.box-sizing {
		box-sizing: border-box;
	}

	.index-page {
		width: 100vw;
		background-color: rgba(245, 245, 245, 1);
		height: calc(100vh - 88px); // 解决页面无内容时上下滚动问题 高度默认44px + padding-top 20px
		position: relative;
		// padding: 32rpx;
		.menuEmpty {
			width: 298upx;
			text-align: center;
			margin: 0 auto;
			margin-top: 254upx;

			.emptyTip {
				font-size: 24upx;
				color: rgba(166, 166, 166, 1);
				margin-top: 48upx;
			}
		}

		.searchContainer {
			margin-top: 88px;
			width: 100%;
			height: 112upx;
			background-color: #fff;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 24upx;
			box-sizing: border-box;

			// position: fixed;
			// top:0upx;
			.version {
				width: 114upx;
				color: rgba(38, 79, 247, 1);
			}

			.inputBox {
				display: flex;
				align-items: center;
				width: 70%;
				height: 64upx;
				border-radius: 16px;
				padding-left: 22upx;
				background-color: rgba(245, 245, 245, 1);
			}

			.menuDown {
				color: rgba(38, 79, 247, 1);
				font-size: 28upx;
				// margin-left: 26upx;
				width: 112upx;
			}
		}
		.scrollBox{
			height: calc(100vh - 88px - 56px - 120px);
			// position: fixed;
			top: 200;
			z-index: 9999;
		}
		.scroll-Y {
				height: calc(100vh - 88px - 56px - 120px);
			}
		.menuTabs {
			width: 100vw;
			height: 112upx;
			display: flex;
			align-items: center;
			padding: 36upx 24upx;
			box-sizing: border-box;
			white-space: nowrap;
			overflow-x:scroll;
			overflow-y: hidden;
			// position: fixed;
			// top:266upx;
			.chooseView {
				width: 140upx;
				height: 64upx;
				display: flex;
				align-items: center;
				justify-content: center;
				border-radius: 4px;
				background: rgba(38, 79, 247, 0.1);
				margin-right: 20upx;
				color: rgba(128, 128, 128, 1);
			}

			.tab {
				margin-right: 20upx;
			}

			.activetab {
				color: rgba(38, 79, 247, 1);
			}
		}

		.varietyContainer {
			width: 100vw;
			height: 100%;
			// overflow-y: scroll;
			background-color: whitesmoke;

			.varietyItem {
				width: 734upx;
				height: 244upx;
				border-radius: 5px;
				background-color: #fff;
				margin: 0 auto;
				padding: 32upx 16upx;
				box-sizing: border-box;
				display: flex;
				margin-bottom: 16upx;

				.varietyInfo {
					.varietyTitle {
						font-size: 36upx;
					}

					.varietySpec {
						width: 140upx;
						height: 36upx;
						text-align: center;
						line-height: 36upx;
						border-radius: 4px;
						background: rgba(38, 79, 247, 0.1);
						font-size: 24upx;
						color: rgba(38, 79, 247, 1);
						margin-top: 22upx;
						margin-bottom: 30upx;
					}

					.varietyCount {
						color: rgba(166, 166, 166, 1);
						margin-top: 24upx;
						font-size: 28upx;
					}
				}

				.varietyImage {
					width: 320upx;
					overflow: hidden;
					height: 180upx;
					line-height: 180upx;
					text-align: center;
					background-color: rgba(245, 248, 255, 1);
					border-radius: 4px;
					position: relative;
					margin-right: 16upx;

					.varietyTag {
						width: 86upx;
						height: 32upx;
						text-align: center;
						line-height: 32upx;
						font-size: 20upx;
						position: absolute;
						top: 0px;
						left: 0px;
						background-color: rgba(255, 205, 194, 1);
						border-radius: 4px 0px, 4px, 0px;
						color: rgba(255, 87, 51, 1);
					}

					.varietyName {
						width: 98%;
						margin: 0 auto;
						font-size: 48upx;
						color: rgba(38, 79, 247, 1);
					}
				}
			}
		}

		.menuContainer {
			width: 100vw;
			height: 100%;
			background-color: whitesmoke;

			.menuItem {
				width: 734upx;
				height: 244upx;
				overflow: hidden;
				border-radius: 5px;
				background-color: #fff;
				margin: 0 auto;
				padding: 32upx 16upx;
				box-sizing: border-box;
				display: flex;
				margin-bottom: 16upx;

				.menuInfo {
					.menuTitle {
						font-size: 36upx;
					}

					.menuSpec {
						width: 140upx;
						height: 36upx;
						text-align: center;
						line-height: 36upx;
						border-radius: 4px;
						background: rgba(38, 79, 247, 0.1);
						font-size: 24upx;
						color: rgba(38, 79, 247, 1);
						margin-top: 22upx;
						margin-bottom: 30upx;
					}

					.useCount {
						color: rgba(166, 166, 166, 1);
						font-size: 28upx;
					}
				}

				.menuImage {
					width: 320upx;
					height: 180upx;
					line-height: 180upx;
					text-align: center;
					background-color: rgba(245, 248, 255, 1);
					border-radius: 4px;
					position: relative;
					margin-right: 16upx;

					.menuTag {
						width: 86upx;
						height: 32upx;
						text-align: center;
						line-height: 32upx;
						font-size: 20upx;
						position: absolute;
						top: 0px;
						left: 0px;
						background-color: rgba(255, 205, 194, 1);
						border-radius: 4px 0px, 4px, 0px;
						color: rgba(255, 87, 51, 1);
					}

					.menuName {
						width: 98%;
						margin: 0 auto;
						font-size: 48upx;
						// position: absolute;
						// top:50%;
						// left: 50%;
						// transform: translate(-50%, -50%);
						color: rgba(38, 79, 247, 1);
					}
				}
			}
		}

		.tab_title {
			width: 100%;
			height: 44px !important; //这个是固定的44px（所有小程序顶部高度都是 = 44px + 手机系统状态栏高度）
			line-height: 44px;
			text-align: center;
			background-color: #fff !important;
			position: fixed;
			top: 0;
			z-index: 9999;
			color: #fff;
			font-weight: 500;

			.menu_btn {

				// width: 100upx !important;
				// background-color: #ffffff; //这个是小程序默认的标题栏背景色
				// overflow: hidden;
				.selectShop {
					min-width: 460upx;
					height: 56upx;
					line-height: 56upx;
					display: flex;
					margin-left: 32upx;
					// padding-top: 12upx;
					color: #fff;

					.shopLogo {
						width: 28px;
						height: 28px;
						text-align: center;
						line-height: 28px;
						border-radius: 50%;
						background-color: #A3B6FF;
						color: #264FF7;
						margin-right: 20upx;
					}

					.shopName {
						width: 80%;
						text-align: left;
						color: #000;
						white-space: nowrap;
						/* 对于溢出的代码进行隐藏 */
						overflow: hidden;
						/* 剪裁后面的代码，并更改为省略号 */
						text-overflow: ellipsis;
					}
				}

				// position: fixed; //行内式写了固定定位--目的是去掉下划页面一起滚动问题
				.arrowleft {
					position: absolute;
					top: 50%;
					left: 50%;
					transform: translate(-160%, -50%) !important;
					-webkit-transform: translate(-160%, -50%) !important;
				}

				.text_box {
					width: 1rpx;
					height: 20px;
					background-color: #ddd;
					position: absolute;
					top: 50%;
					left: 50%;
					transform: translate(-50%, -50%) !important;
					-webkit-transform: translate(-50%, -50%) !important;
				}

				.home {
					position: absolute;
					top: 50%;
					left: 50%;
					transform: translate(60%, -50%) !important;
					-webkit-transform: translate(60%, -50%) !important;
				}
			}
		}

	}
</style>