<template>
    <view class="tab">
         <view v-for="(item,index) in list" :key="index" class="tab-item" @click="switchTab(item, index)">
            <image class="tab_img" :src="currentIndex == index ? item.selectedIconPath : item.iconPath"></image>
            <view class="tab_text" :style="{color: currentIndex == index ? selectedColor : color}">{{item.text}}</view>
        </view>
    </view>
</template>
 
<script>
    export default {
        props: {
            selectedIndex: { // 当前选中的tab index
                default: 0
            },
        },
        data() {
            return {
                color: "#666666",
                selectedColor: "#00BAB2",
                list: [],
                currentIndex:0,
            }
        },
        created() {
            this.currentIndex = this.selectedIndex;
            
            let _this = this
            
                //角色1
                _this.list = [{
				"pagePath":"pages/home/index",
				"text":"首页",
				// 图标不要超过 40kb &#xe88d 这个 &#xe 替换成 \ue  =》 \ue88d 
				"iconPath": "static/Home.png", // 未选中时的图标  要使用相对路径 建议放在 /static 项目文件下面
				"selectedIconPath": "static/selectHome.png" // 选中时的图标
			},
			{
				"pagePath":"pages/menus/menus",
				"text":"菜谱",
				"iconPath": "static/menu.png",
				"selectedIconPath": "static/selectMenu.png"
			},
			{
				"pagePath":"pages/personCenter/index",
				"text":"我的",
				"iconPath": "static/My.png",
				"selectedIconPath": "static/selectMy.png"
			}
                ]
        },
        methods: {
            switchTab(item, index) {
                this.currentIndex = index;
                let url = item.pagePath;
                uni.redirectTo({url:url})
                
            }
        }
    }
</script>
 
<style lang="scss">
    .tab {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        height: 100rpx;
        background: white;
        display: flex;
        justify-content: center;
        align-items: center;
        padding-bottom: env(safe-area-inset-bottom); // 适配iphoneX的底部
 
        .tab-item {
            flex: 1;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            .tab_img {
                width: 60rpx;
                height: 60rpx;
            }
            .tab_text {
                font-size: 30rpx;
                margin-top: 9rpx;
            }
        }
    }
</style>