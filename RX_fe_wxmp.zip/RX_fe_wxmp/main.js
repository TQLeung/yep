import App from './App'

// #ifndef VUE3
import Vue from 'vue'
Vue.config.productionTip = false
App.mpType = 'app'
// 导入并挂载全局的分享方法
import share from '@/uilts/share.js'
Vue.mixin(share)
// Vue.prototype.$baseUrl = "https://admin.renxin-robot.com"
// Vue.prototype.$baseUrl = "https://rr.renxin-robot.com"
// Vue.prototype.$baseUrl = "https://baichaole.acewill.net"
// Vue.prototype.$baseUrl = "http://192.168.222.145"
Vue.prototype.$baseUrl = "http://120.79.228.2"
// Vue.prototype.$baseUrl="https://x.renxin-robot.com"
Vue.prototype.$chartToTop = false
import api from '@/api/index.js'
Vue.prototype.API = api // 请求集合
import tools from '@/uilts/tools/index.js'
Vue.prototype.Tools = tools // 工具类
import myerror from '@/uilts/error.js'
Vue.prototype.MyError = myerror

// import tabBar from "@/components/tabbar/tabbar.vue"
// Vue.component('tabBar',tabBar)
import store from '@/store/index.js'

try {
  function isPromise(obj) {
    return (
      !!obj &&
      (typeof obj === "object" || typeof obj === "function") &&
      typeof obj.then === "function"
    );
  }

  // 统一 vue2 API Promise 化返回格式与 vue3 保持一致
  uni.addInterceptor({
    returnValue(res) {
      if (!isPromise(res)) {
        return res;
      }
      return new Promise((resolve, reject) => {
        res.then((res) => {
          if (res[0]) {
            reject(res[0]);
          } else {
            resolve(res[1]);
          }
        });
      });
    },
  });
} catch (error) { }
console.log('Vue.version:-_-', Vue.version);
const app = new Vue({
  ...App,
  store
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif