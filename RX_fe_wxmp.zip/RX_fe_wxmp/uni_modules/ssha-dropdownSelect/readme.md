# shas-dropdownselect
# 通过数据渲染的下拉框组件,可输入关键词搜索

 change  选中发生变化触发
 changeItem  选中发生变化触发，返回点击项全部内容

#示例

```html
	<!-- 基础用法 -->
	<ssha-dropdownSelect 
		:search="true" 
		label="label" 
		v-model="select0" 
		:localdata="list"
		@change="change" 
		@changeItem="changeItem" 
		placeholder="请选择">
	</ssha-dropdownSelect>
		
```
数据格式：
list: [{
			"id": 1,
			"label": "新工程1",
			"children": [{
				"id": 11,
				"label": "一期"
			}],
		},
		{
			"id": 2,
			"label": "新工程2",
			"children": [{
					"id": 21,
					"label": "一期"
				},
				{
					"id": 22,
					"label": "二期",
					'disable':true,
				}
			]
		},
		{
			"id": 3,
			"label": "新工程3",
			'disable':true,
			"children": [{
				"id": 31,
				"label": "一期"
			}]
		}
	],
