//pagePath以自己项目的实际路径为准，这里是为了代码聚合在一起
const tabbar = {
	"tabItems1":[
		{
			"pagePath": "pages/home/index",
			"icon": '/static/Home.png', 
			"selectedIcon":'/static/selectHome.png', 
			"text": '首页',
		},
		{
			"pagePath": "pages/menus/menus",
			"icon": '/static/menu.png', 
			"selectedIcon":'/static/selectMenu.png', 
			"text": '菜谱'
		},
		{ 
			"pagePath": "pages/personCenter/index",
			"icon": '/static/My.png', 
			"selectedIcon":'/static/selectMy.png', 
			"text": '我的',
		}
		// {
		// 	"pagePath": "pages/home/testShow/testShow",
		// 	"icon": '/static/My.png', 
		// 	"selectedIcon":'/static/selectMy.png', 
		// 	"text": 'ceshi',
		// }
	],
	"tabItems2":[
		{
			"pagePath": "pages/home/index",
			"icon": '/static/Home.png', 
			"selectedIcon":'/static/selectHome.png', 
			"text": '首页',
		},
		
		{ 
			"pagePath": "pages/personCenter/index",
			"icon": '/static/My.png', 
			"selectedIcon":'/static/selectMy.png', 
			"text": '我的',
		},
		// {
		// 	"pagePath": "pages/home/testShow/testShow",
		// 	"icon": '/static/My.png', 
		// 	"selectedIcon":'/static/selectMy.png', 
		// 	"text": 'ceshi',
		// }
	],
	"color":"#333",
	"selectedColor":"rgba(38, 79, 247, 1)",
}
export default tabbar