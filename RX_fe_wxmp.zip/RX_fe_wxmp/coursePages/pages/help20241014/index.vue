<template>
	<view>
		<web-view src="https://docs.qq.com/doc/p/94f06cab60a70b14c3041988eb25bfc1a3ffd4c0"></web-view>
	</view>
</template>