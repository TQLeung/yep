(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["menusPages/common/vendor"],{

/***/ 503:
/*!***************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/uilts/formdata/index.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(wx) {

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ 4);
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ 18));
var _mimeMap = _interopRequireDefault(__webpack_require__(/*! ./mimeMap */ 504));
function FormData() {
  var fileManager = wx.getFileSystemManager();
  var data = {};
  var files = [];
  this.append = function (name, value) {
    data[name] = value;
    return true;
  };
  this.appendFile = function (name, path) {
    var buffer = fileManager.readFileSync(path);
    if (Object.prototype.toString.call(buffer).indexOf("ArrayBuffer") < 0) {
      return false;
    }
    files.push({
      name: name,
      buffer: buffer,
      fileName: getFileNameFromPath(path)
    });
    return true;
  };
  this.getData = function () {
    return convert(data, files);
  };
}
function getFileNameFromPath(path) {
  var idx = path.lastIndexOf("/");
  return path.substr(idx + 1);
}
function convert(data, files) {
  var boundaryKey = 'wxmpFormBoundary' + randString(); // 数据分割符，一般是随机的字符串
  var boundary = '--' + boundaryKey;
  var endBoundary = boundary + '--';
  var postArray = [];
  //拼接参数
  if (data && Object.prototype.toString.call(data) == "[object Object]") {
    for (var key in data) {
      postArray = postArray.concat(formDataArray(boundary, key, data[key]));
    }
  }
  //拼接文件
  if (files && Object.prototype.toString.call(files) == "[object Array]") {
    for (var _i in files) {
      var file = files[_i];
      postArray = postArray.concat(formDataArray(boundary, file.name, file.buffer, file.fileName));
    }
  }
  //结尾
  var endBoundaryArray = [];
  for (var i = 0; i < endBoundary.length; i++) {
    // 最后取出结束boundary的charCode
    endBoundaryArray.push.apply(endBoundaryArray, (0, _toConsumableArray2.default)(endBoundary.utf8CodeAt(i)));
  }
  postArray = postArray.concat(endBoundaryArray);
  return {
    contentType: 'multipart/form-data; boundary=' + boundaryKey,
    buffer: new Uint8Array(postArray).buffer
  };
}
function randString() {
  var res = "";
  for (var i = 0; i < 17; i++) {
    var n = parseInt(Math.random() * 62);
    if (n <= 9) {
      res += n;
    } else if (n <= 35) {
      res += String.fromCharCode(n + 55);
    } else {
      res += String.fromCharCode(n + 61);
    }
  }
  return res;
}
function formDataArray(boundary, name, value, fileName) {
  var _dataArray2, _dataArray3;
  var dataString = '';
  var isFile = !!fileName;
  dataString += boundary + '\r\n';
  dataString += 'Content-Disposition: form-data; name="' + name + '"';
  if (isFile) {
    dataString += '; filename="' + fileName + '"' + '\r\n';
    dataString += 'Content-Type: ' + getFileMime(fileName) + '\r\n\r\n';
  } else {
    dataString += '\r\n\r\n';
    dataString += value;
  }
  var dataArray = [];
  for (var i = 0; i < dataString.length; i++) {
    var _dataArray;
    // 取出文本的charCode（10进制）
    (_dataArray = dataArray).push.apply(_dataArray, (0, _toConsumableArray2.default)(dataString.utf8CodeAt(i)));
  }
  if (isFile) {
    var fileArray = new Uint8Array(value);
    dataArray = dataArray.concat(Array.prototype.slice.call(fileArray));
  }
  (_dataArray2 = dataArray).push.apply(_dataArray2, (0, _toConsumableArray2.default)("\r".utf8CodeAt()));
  (_dataArray3 = dataArray).push.apply(_dataArray3, (0, _toConsumableArray2.default)("\n".utf8CodeAt()));
  return dataArray;
}
function getFileMime(fileName) {
  var idx = fileName.lastIndexOf(".");
  var mime = _mimeMap.default[fileName.substr(idx)];
  return mime ? mime : "application/octet-stream";
}
String.prototype.utf8CodeAt = function (i) {
  var str = this;
  var out = [],
    p = 0;
  var c = str.charCodeAt(i);
  if (c < 128) {
    out[p++] = c;
  } else if (c < 2048) {
    out[p++] = c >> 6 | 192;
    out[p++] = c & 63 | 128;
  } else if ((c & 0xFC00) == 0xD800 && i + 1 < str.length && (str.charCodeAt(i + 1) & 0xFC00) == 0xDC00) {
    // Surrogate Pair
    c = 0x10000 + ((c & 0x03FF) << 10) + (str.charCodeAt(++i) & 0x03FF);
    out[p++] = c >> 18 | 240;
    out[p++] = c >> 12 & 63 | 128;
    out[p++] = c >> 6 & 63 | 128;
    out[p++] = c & 63 | 128;
  } else {
    out[p++] = c >> 12 | 224;
    out[p++] = c >> 6 & 63 | 128;
    out[p++] = c & 63 | 128;
  }
  return out;
};
var _default = FormData;
exports.default = _default;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ 1)["default"]))

/***/ }),

/***/ 504:
/*!*****************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/uilts/formdata/mimeMap.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ 4);
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ 11));
var _mimeMap;
var mimeMap = (_mimeMap = {
  "0.001": "application/x-001",
  "0.323": "text/h323",
  "0.907": "drawing/907",
  ".acp": "audio/x-mei-aac",
  ".aif": "audio/aiff",
  ".aiff": "audio/aiff",
  ".asa": "text/asa",
  ".asp": "text/asp",
  ".au": "audio/basic",
  ".awf": "application/vnd.adobe.workflow",
  ".bmp": "application/x-bmp",
  ".c4t": "application/x-c4t",
  ".cal": "application/x-cals",
  ".cdf": "application/x-netcdf",
  ".cel": "application/x-cel",
  ".cg4": "application/x-g4",
  ".cit": "application/x-cit",
  ".cml": "text/xml",
  ".cmx": "application/x-cmx",
  ".crl": "application/pkix-crl",
  ".csi": "application/x-csi",
  ".cut": "application/x-cut",
  ".dbm": "application/x-dbm",
  ".dcd": "text/xml",
  ".der": "application/x-x509-ca-cert",
  ".dib": "application/x-dib",
  ".doc": "application/msword",
  ".drw": "application/x-drw",
  ".dwf": "Model/vnd.dwf",
  ".dwg": "application/x-dwg",
  ".dxf": "application/x-dxf",
  ".emf": "application/x-emf",
  ".ent": "text/xml",
  ".eps": "application/x-ps",
  ".etd": "application/x-ebx",
  ".fax": "image/fax",
  ".fif": "application/fractals",
  ".frm": "application/x-frm",
  ".gbr": "application/x-gbr",
  ".gif": "image/gif",
  ".gp4": "application/x-gp4",
  ".hmr": "application/x-hmr",
  ".hpl": "application/x-hpl",
  ".hrf": "application/x-hrf",
  ".htc": "text/x-component",
  ".html": "text/html",
  ".htx": "text/html",
  ".ico": "image/x-icon",
  ".iff": "application/x-iff",
  ".igs": "application/x-igs",
  ".img": "application/x-img",
  ".isp": "application/x-internet-signup",
  ".java": "java/*",
  ".jpe": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".jpg": "application/x-jpg",
  ".jsp": "text/html",
  ".lar": "application/x-laplayer-reg",
  ".lavs": "audio/x-liquid-secure",
  ".lmsff": "audio/x-la-lms",
  ".ltr": "application/x-ltr",
  ".m2v": "video/x-mpeg",
  ".m4e": "video/mpeg4",
  ".man": "application/x-troff-man",
  ".mdb": "application/msaccess",
  ".mfp": "application/x-shockwave-flash",
  ".mhtml": "message/rfc822",
  ".mid": "audio/mid",
  ".mil": "application/x-mil",
  ".mnd": "audio/x-musicnet-download",
  ".mocha": "application/x-javascript",
  ".mp1": "audio/mp1",
  ".mp2v": "video/mpeg",
  ".mp4": "video/mpeg4",
  ".mpd": "application/vnd.ms-project",
  ".mpeg": "video/mpg",
  ".mpga": "audio/rn-mpeg",
  ".mps": "video/x-mpeg",
  ".mpv": "video/mpg",
  ".mpw": "application/vnd.ms-project",
  ".mtx": "text/xml",
  ".net": "image/pnetvue",
  ".nws": "message/rfc822",
  ".out": "application/x-out",
  ".p12": "application/x-pkcs12",
  ".p7c": "application/pkcs7-mime",
  ".p7r": "application/x-pkcs7-certreqresp",
  ".pc5": "application/x-pc5",
  ".pcl": "application/x-pcl",
  ".pdf": "application/pdf",
  ".pdx": "application/vnd.adobe.pdx",
  ".pgl": "application/x-pgl",
  ".pko": "application/vnd.ms-pki.pko",
  ".plg": "text/html",
  ".plt": "application/x-plt",
  ".png": "application/x-png",
  ".ppa": "application/vnd.ms-powerpoint",
  ".pps": "application/vnd.ms-powerpoint",
  ".ppt": "application/x-ppt",
  ".prf": "application/pics-rules",
  ".prt": "application/x-prt",
  ".ps": "application/postscript",
  ".pwz": "application/vnd.ms-powerpoint",
  ".ra": "audio/vnd.rn-realaudio",
  ".ras": "application/x-ras",
  ".rdf": "text/xml",
  ".red": "application/x-red",
  ".rjs": "application/vnd.rn-realsystem-rjs",
  ".rlc": "application/x-rlc",
  ".rm": "application/vnd.rn-realmedia",
  ".rmi": "audio/mid",
  ".rmm": "audio/x-pn-realaudio",
  ".rms": "application/vnd.rn-realmedia-secure",
  ".rmx": "application/vnd.rn-realsystem-rmx",
  ".rp": "image/vnd.rn-realpix",
  ".rsml": "application/vnd.rn-rsml",
  ".rtf": "application/msword",
  ".rv": "video/vnd.rn-realvideo",
  ".sat": "application/x-sat",
  ".sdw": "application/x-sdw",
  ".slb": "application/x-slb",
  ".slk": "drawing/x-slk",
  ".smil": "application/smil",
  ".snd": "audio/basic",
  ".sor": "text/plain",
  ".spl": "application/futuresplash",
  ".ssm": "application/streamingmedia",
  ".stl": "application/vnd.ms-pki.stl",
  ".sty": "application/x-sty",
  ".swf": "application/x-shockwave-flash",
  ".tg4": "application/x-tg4",
  ".tif": "image/tiff",
  ".tiff": "image/tiff",
  ".top": "drawing/x-top",
  ".tsd": "text/xml",
  ".uin": "application/x-icq",
  ".vcf": "text/x-vcard",
  ".vdx": "application/vnd.visio",
  ".vpg": "application/x-vpeg005",
  ".vsd": "application/x-vsd",
  ".vst": "application/vnd.visio",
  ".vsw": "application/vnd.visio",
  ".vtx": "application/vnd.visio",
  ".wav": "audio/wav",
  ".wb1": "application/x-wb1",
  ".wb3": "application/x-wb3",
  ".wiz": "application/msword",
  ".wk4": "application/x-wk4",
  ".wks": "application/x-wks",
  ".wma": "audio/x-ms-wma",
  ".wmf": "application/x-wmf",
  ".wmv": "video/x-ms-wmv",
  ".wmz": "application/x-ms-wmz",
  ".wpd": "application/x-wpd",
  ".wpl": "application/vnd.ms-wpl",
  ".wr1": "application/x-wr1",
  ".wrk": "application/x-wrk",
  ".ws2": "application/x-ws",
  ".wsdl": "text/xml",
  ".xdp": "application/vnd.adobe.xdp",
  ".xfd": "application/vnd.adobe.xfd",
  ".xhtml": "text/html",
  ".xls": "application/x-xls",
  ".xml": "text/xml",
  ".xq": "text/xml",
  ".xquery": "text/xml",
  ".xsl": "text/xml",
  ".xwd": "application/x-xwd",
  ".sis": "application/vnd.symbian.install",
  ".x_t": "application/x-x_t",
  ".apk": "application/vnd.android.package-archive",
  "0.301": "application/x-301",
  "0.906": "application/x-906",
  ".a11": "application/x-a11",
  ".ai": "application/postscript",
  ".aifc": "audio/aiff",
  ".anv": "application/x-anv",
  ".asf": "video/x-ms-asf",
  ".asx": "video/x-ms-asf",
  ".avi": "video/avi",
  ".biz": "text/xml",
  ".bot": "application/x-bot",
  ".c90": "application/x-c90",
  ".cat": "application/vnd.ms-pki.seccat",
  ".cdr": "application/x-cdr",
  ".cer": "application/x-x509-ca-cert",
  ".cgm": "application/x-cgm",
  ".class": "java/*",
  ".cmp": "application/x-cmp",
  ".cot": "application/x-cot",
  ".crt": "application/x-x509-ca-cert",
  ".css": "text/css",
  ".dbf": "application/x-dbf",
  ".dbx": "application/x-dbx",
  ".dcx": "application/x-dcx",
  ".dgn": "application/x-dgn",
  ".dll": "application/x-msdownload",
  ".dot": "application/msword",
  ".dtd": "text/xml"
}, (0, _defineProperty2.default)(_mimeMap, ".dwf", "application/x-dwf"), (0, _defineProperty2.default)(_mimeMap, ".dxb", "application/x-dxb"), (0, _defineProperty2.default)(_mimeMap, ".edn", "application/vnd.adobe.edn"), (0, _defineProperty2.default)(_mimeMap, ".eml", "message/rfc822"), (0, _defineProperty2.default)(_mimeMap, ".epi", "application/x-epi"), (0, _defineProperty2.default)(_mimeMap, ".eps", "application/postscript"), (0, _defineProperty2.default)(_mimeMap, ".exe", "application/x-msdownload"), (0, _defineProperty2.default)(_mimeMap, ".fdf", "application/vnd.fdf"), (0, _defineProperty2.default)(_mimeMap, ".fo", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".g4", "application/x-g4"), (0, _defineProperty2.default)(_mimeMap, ".tif", "image/tiff"), (0, _defineProperty2.default)(_mimeMap, ".gl2", "application/x-gl2"), (0, _defineProperty2.default)(_mimeMap, ".hgl", "application/x-hgl"), (0, _defineProperty2.default)(_mimeMap, ".hpg", "application/x-hpgl"), (0, _defineProperty2.default)(_mimeMap, ".hqx", "application/mac-binhex40"), (0, _defineProperty2.default)(_mimeMap, ".hta", "application/hta"), (0, _defineProperty2.default)(_mimeMap, ".htm", "text/html"), (0, _defineProperty2.default)(_mimeMap, ".htt", "text/webviewhtml"), (0, _defineProperty2.default)(_mimeMap, ".icb", "application/x-icb"), (0, _defineProperty2.default)(_mimeMap, ".ico", "application/x-ico"), (0, _defineProperty2.default)(_mimeMap, ".ig4", "application/x-g4"), (0, _defineProperty2.default)(_mimeMap, ".iii", "application/x-iphone"), (0, _defineProperty2.default)(_mimeMap, ".ins", "application/x-internet-signup"), (0, _defineProperty2.default)(_mimeMap, ".IVF", "video/x-ivf"), (0, _defineProperty2.default)(_mimeMap, ".jfif", "image/jpeg"), (0, _defineProperty2.default)(_mimeMap, ".jpe", "application/x-jpe"), (0, _defineProperty2.default)(_mimeMap, ".jpg", "image/jpeg"), (0, _defineProperty2.default)(_mimeMap, ".js", "application/x-javascript"), (0, _defineProperty2.default)(_mimeMap, ".la1", "audio/x-liquid-file"), (0, _defineProperty2.default)(_mimeMap, ".latex", "application/x-latex"), (0, _defineProperty2.default)(_mimeMap, ".lbm", "application/x-lbm"), (0, _defineProperty2.default)(_mimeMap, ".ls", "application/x-javascript"), (0, _defineProperty2.default)(_mimeMap, ".m1v", "video/x-mpeg"), (0, _defineProperty2.default)(_mimeMap, ".m3u", "audio/mpegurl"), (0, _defineProperty2.default)(_mimeMap, ".mac", "application/x-mac"), (0, _defineProperty2.default)(_mimeMap, ".math", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".mdb", "application/x-mdb"), (0, _defineProperty2.default)(_mimeMap, ".mht", "message/rfc822"), (0, _defineProperty2.default)(_mimeMap, ".mi", "application/x-mi"), (0, _defineProperty2.default)(_mimeMap, ".midi", "audio/mid"), (0, _defineProperty2.default)(_mimeMap, ".mml", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".mns", "audio/x-musicnet-stream"), (0, _defineProperty2.default)(_mimeMap, ".movie", "video/x-sgi-movie"), (0, _defineProperty2.default)(_mimeMap, ".mp2", "audio/mp2"), (0, _defineProperty2.default)(_mimeMap, ".mp3", "audio/mp3"), (0, _defineProperty2.default)(_mimeMap, ".mpa", "video/x-mpg"), (0, _defineProperty2.default)(_mimeMap, ".mpe", "video/x-mpeg"), (0, _defineProperty2.default)(_mimeMap, ".mpg", "video/mpg"), (0, _defineProperty2.default)(_mimeMap, ".mpp", "application/vnd.ms-project"), (0, _defineProperty2.default)(_mimeMap, ".mpt", "application/vnd.ms-project"), (0, _defineProperty2.default)(_mimeMap, ".mpv2", "video/mpeg"), (0, _defineProperty2.default)(_mimeMap, ".mpx", "application/vnd.ms-project"), (0, _defineProperty2.default)(_mimeMap, ".mxp", "application/x-mmxp"), (0, _defineProperty2.default)(_mimeMap, ".nrf", "application/x-nrf"), (0, _defineProperty2.default)(_mimeMap, ".odc", "text/x-ms-odc"), (0, _defineProperty2.default)(_mimeMap, ".p10", "application/pkcs10"), (0, _defineProperty2.default)(_mimeMap, ".p7b", "application/x-pkcs7-certificates"), (0, _defineProperty2.default)(_mimeMap, ".p7m", "application/pkcs7-mime"), (0, _defineProperty2.default)(_mimeMap, ".p7s", "application/pkcs7-signature"), (0, _defineProperty2.default)(_mimeMap, ".pci", "application/x-pci"), (0, _defineProperty2.default)(_mimeMap, ".pcx", "application/x-pcx"), (0, _defineProperty2.default)(_mimeMap, ".pdf", "application/pdf"), (0, _defineProperty2.default)(_mimeMap, ".pfx", "application/x-pkcs12"), (0, _defineProperty2.default)(_mimeMap, ".pic", "application/x-pic"), (0, _defineProperty2.default)(_mimeMap, ".pl", "application/x-perl"), (0, _defineProperty2.default)(_mimeMap, ".pls", "audio/scpls"), (0, _defineProperty2.default)(_mimeMap, ".png", "image/png"), (0, _defineProperty2.default)(_mimeMap, ".pot", "application/vnd.ms-powerpoint"), (0, _defineProperty2.default)(_mimeMap, ".ppm", "application/x-ppm"), (0, _defineProperty2.default)(_mimeMap, ".ppt", "application/vnd.ms-powerpoint"), (0, _defineProperty2.default)(_mimeMap, ".pr", "application/x-pr"), (0, _defineProperty2.default)(_mimeMap, ".prn", "application/x-prn"), (0, _defineProperty2.default)(_mimeMap, ".ps", "application/x-ps"), (0, _defineProperty2.default)(_mimeMap, ".ptn", "application/x-ptn"), (0, _defineProperty2.default)(_mimeMap, ".r3t", "text/vnd.rn-realtext3d"), (0, _defineProperty2.default)(_mimeMap, ".ram", "audio/x-pn-realaudio"), (0, _defineProperty2.default)(_mimeMap, ".rat", "application/rat-file"), (0, _defineProperty2.default)(_mimeMap, ".rec", "application/vnd.rn-recording"), (0, _defineProperty2.default)(_mimeMap, ".rgb", "application/x-rgb"), (0, _defineProperty2.default)(_mimeMap, ".rjt", "application/vnd.rn-realsystem-rjt"), (0, _defineProperty2.default)(_mimeMap, ".rle", "application/x-rle"), (0, _defineProperty2.default)(_mimeMap, ".rmf", "application/vnd.adobe.rmf"), (0, _defineProperty2.default)(_mimeMap, ".rmj", "application/vnd.rn-realsystem-rmj"), (0, _defineProperty2.default)(_mimeMap, ".rmp", "application/vnd.rn-rn_music_package"), (0, _defineProperty2.default)(_mimeMap, ".rmvb", "application/vnd.rn-realmedia-vbr"), (0, _defineProperty2.default)(_mimeMap, ".rnx", "application/vnd.rn-realplayer"), (0, _defineProperty2.default)(_mimeMap, ".rpm", "audio/x-pn-realaudio-plugin"), (0, _defineProperty2.default)(_mimeMap, ".rt", "text/vnd.rn-realtext"), (0, _defineProperty2.default)(_mimeMap, ".rtf", "application/x-rtf"), (0, _defineProperty2.default)(_mimeMap, ".sam", "application/x-sam"), (0, _defineProperty2.default)(_mimeMap, ".sdp", "application/sdp"), (0, _defineProperty2.default)(_mimeMap, ".sit", "application/x-stuffit"), (0, _defineProperty2.default)(_mimeMap, ".sld", "application/x-sld"), (0, _defineProperty2.default)(_mimeMap, ".smi", "application/smil"), (0, _defineProperty2.default)(_mimeMap, ".smk", "application/x-smk"), (0, _defineProperty2.default)(_mimeMap, ".sol", "text/plain"), (0, _defineProperty2.default)(_mimeMap, ".spc", "application/x-pkcs7-certificates"), (0, _defineProperty2.default)(_mimeMap, ".spp", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".sst", "application/vnd.ms-pki.certstore"), (0, _defineProperty2.default)(_mimeMap, ".stm", "text/html"), (0, _defineProperty2.default)(_mimeMap, ".svg", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".tdf", "application/x-tdf"), (0, _defineProperty2.default)(_mimeMap, ".tga", "application/x-tga"), (0, _defineProperty2.default)(_mimeMap, ".tif", "application/x-tif"), (0, _defineProperty2.default)(_mimeMap, ".tld", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".torrent", "application/x-bittorrent"), (0, _defineProperty2.default)(_mimeMap, ".txt", "text/plain"), (0, _defineProperty2.default)(_mimeMap, ".uls", "text/iuls"), (0, _defineProperty2.default)(_mimeMap, ".vda", "application/x-vda"), (0, _defineProperty2.default)(_mimeMap, ".vml", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".vsd", "application/vnd.visio"), (0, _defineProperty2.default)(_mimeMap, ".vss", "application/vnd.visio"), (0, _defineProperty2.default)(_mimeMap, ".vst", "application/x-vst"), (0, _defineProperty2.default)(_mimeMap, ".vsx", "application/vnd.visio"), (0, _defineProperty2.default)(_mimeMap, ".vxml", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".wax", "audio/x-ms-wax"), (0, _defineProperty2.default)(_mimeMap, ".wb2", "application/x-wb2"), (0, _defineProperty2.default)(_mimeMap, ".wbmp", "image/vnd.wap.wbmp"), (0, _defineProperty2.default)(_mimeMap, ".wk3", "application/x-wk3"), (0, _defineProperty2.default)(_mimeMap, ".wkq", "application/x-wkq"), (0, _defineProperty2.default)(_mimeMap, ".wm", "video/x-ms-wm"), (0, _defineProperty2.default)(_mimeMap, ".wmd", "application/x-ms-wmd"), (0, _defineProperty2.default)(_mimeMap, ".wml", "text/vnd.wap.wml"), (0, _defineProperty2.default)(_mimeMap, ".wmx", "video/x-ms-wmx"), (0, _defineProperty2.default)(_mimeMap, ".wp6", "application/x-wp6"), (0, _defineProperty2.default)(_mimeMap, ".wpg", "application/x-wpg"), (0, _defineProperty2.default)(_mimeMap, ".wq1", "application/x-wq1"), (0, _defineProperty2.default)(_mimeMap, ".wri", "application/x-wri"), (0, _defineProperty2.default)(_mimeMap, ".ws", "application/x-ws"), (0, _defineProperty2.default)(_mimeMap, ".wsc", "text/scriptlet"), (0, _defineProperty2.default)(_mimeMap, ".wvx", "video/x-ms-wvx"), (0, _defineProperty2.default)(_mimeMap, ".xdr", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".xfdf", "application/vnd.adobe.xfdf"), (0, _defineProperty2.default)(_mimeMap, ".xls", "application/vnd.ms-excel"), (0, _defineProperty2.default)(_mimeMap, ".xlw", "application/x-xlw"), (0, _defineProperty2.default)(_mimeMap, ".xpl", "audio/scpls"), (0, _defineProperty2.default)(_mimeMap, ".xql", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".xsd", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".xslt", "text/xml"), (0, _defineProperty2.default)(_mimeMap, ".x_b", "application/x-x_b"), (0, _defineProperty2.default)(_mimeMap, ".sisx", "application/vnd.symbian.install"), (0, _defineProperty2.default)(_mimeMap, ".ipa", "application/vnd.iphone"), (0, _defineProperty2.default)(_mimeMap, ".xap", "application/x-silverlight-app"), (0, _defineProperty2.default)(_mimeMap, ".zip", "application/x-zip-compressed"), _mimeMap);
var _default = mimeMap;
exports.default = _default;

/***/ })

}]);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/menusPages/common/vendor.js.map