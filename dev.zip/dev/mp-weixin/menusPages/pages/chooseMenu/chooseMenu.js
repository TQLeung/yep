require('../../common/vendor.js');(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["menusPages/pages/chooseMenu/chooseMenu"],{

/***/ 587:
/*!*******************************************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/main.js?{"page":"menusPages%2Fpages%2FchooseMenu%2FchooseMenu"} ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(wx, createPage) {

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ 4);
__webpack_require__(/*! uni-pages */ 26);
var _vue = _interopRequireDefault(__webpack_require__(/*! vue */ 25));
var _chooseMenu = _interopRequireDefault(__webpack_require__(/*! ./menusPages/pages/chooseMenu/chooseMenu.vue */ 588));
// @ts-ignore
wx.__webpack_require_UNI_MP_PLUGIN__ = __webpack_require__;
createPage(_chooseMenu.default);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ 1)["default"], __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ 2)["createPage"]))

/***/ }),

/***/ 588:
/*!**********************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/menusPages/pages/chooseMenu/chooseMenu.vue ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chooseMenu.vue?vue&type=template&id=dfe6385a&scoped=true& */ 589);
/* harmony import */ var _chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chooseMenu.vue?vue&type=script&lang=js& */ 591);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _chooseMenu_vue_vue_type_style_index_0_id_dfe6385a_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chooseMenu.vue?vue&type=style&index=0&id=dfe6385a&lang=less&scoped=true& */ 593);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ 33);

var renderjs





/* normalize component */

var component = Object(_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "dfe6385a",
  null,
  false,
  _chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"],
  renderjs
)

component.options.__file = "menusPages/pages/chooseMenu/chooseMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 589:
/*!*****************************************************************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/menusPages/pages/chooseMenu/chooseMenu.vue?vue&type=template&id=dfe6385a&scoped=true& ***!
  \*****************************************************************************************************************/
/*! exports provided: render, staticRenderFns, recyclableRender, components */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./chooseMenu.vue?vue&type=template&id=dfe6385a&scoped=true& */ 590);
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "recyclableRender", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["recyclableRender"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "components", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_template_id_dfe6385a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"]; });



/***/ }),

/***/ 590:
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!D:/wp/rx/RX_fe_wxmp/menusPages/pages/chooseMenu/chooseMenu.vue?vue&type=template&id=dfe6385a&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns, recyclableRender, components */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recyclableRender", function() { return recyclableRender; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "components", function() { return components; });
var components
try {
  components = {
    uniIcons: function () {
      return Promise.all(/*! import() | uni_modules/uni-icons/components/uni-icons/uni-icons */[__webpack_require__.e("common/vendor"), __webpack_require__.e("uni_modules/uni-icons/components/uni-icons/uni-icons")]).then(__webpack_require__.bind(null, /*! @/uni_modules/uni-icons/components/uni-icons/uni-icons.vue */ 611))
    },
  }
} catch (e) {
  if (
    e.message.indexOf("Cannot find module") !== -1 &&
    e.message.indexOf(".vue") !== -1
  ) {
    console.error(e.message)
    console.error("1. 排查组件名称拼写是否正确")
    console.error(
      "2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"
    )
    console.error(
      "3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件"
    )
  } else {
    throw e
  }
}
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  var l0 = _vm.menuCount
    ? _vm.__map(_vm.menuList, function (item, index) {
        var $orig = _vm.__get_orig(item)
        var s0 = _vm.__get_style([
          _vm.secondaryControl === index && !item.loading
            ? {
                height: 120 * item.twoChildren.length + "rpx",
              }
            : {
                height: "0rpx",
              },
        ])
        var s1 = _vm.__get_style([
          item.loading
            ? {
                height: "120rpx",
              }
            : {
                height: "0rpx",
              },
        ])
        return {
          $orig: $orig,
          s0: s0,
          s1: s1,
        }
      })
    : null
  _vm.$mp.data = Object.assign(
    {},
    {
      $root: {
        l0: l0,
      },
    }
  )
}
var recyclableRender = false
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ 591:
/*!***********************************************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/menusPages/pages/chooseMenu/chooseMenu.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/babel-loader/lib!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--13-1!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./chooseMenu.vue?vue&type=script&lang=js& */ 592);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ 592:
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--13-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!D:/wp/rx/RX_fe_wxmp/menusPages/pages/chooseMenu/chooseMenu.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(uni) {

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ 4);
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ 212));
var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ 214));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ 11));
var _vuex = __webpack_require__(/*! vuex */ 30);
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var _default = {
  computed: _objectSpread({}, (0, _vuex.mapState)('menus', {
    customer: function customer(state) {
      return state.customer;
    },
    menusListContent: function menusListContent(state) {
      return state.menusListContent;
    },
    allMenus: function allMenus(state) {
      return state.allMenus;
    }
  })),
  data: function data() {
    return {
      menuCount: 0,
      value: ['0'],
      menuList: [],
      checkAll: false,
      org_business_id: '',
      chooseMenuList: [],
      oldChooseMenuList: [],
      chooseMenuCount: 0,
      menuCategoryName: '',
      keyWord: '',
      allMenuCount: 0,
      secondaryControl: '',
      // 二级菜单控件
      loadingTime: null // 过度时间 
    };
  },

  watch: {
    menuList: {
      deep: true,
      handler: function handler(newValue) {
        this.checkAll = newValue.every(function (item) {
          return item.checked;
        });
      }
    }
  },
  methods: _objectSpread(_objectSpread({}, (0, _vuex.mapMutations)('menus', ['setMenusListContent', 'setAllMenus'])), {}, {
    getTotal: function getTotal() {
      var _this = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var res;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this.API.menus.getMenuTotal(_this.org_business_id);
              case 2:
                res = _context.sent;
                _this.menuCount = res.paging.total_records;
                console.log(res, 'res');
              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    getMenuListData: function getMenuListData() {
      var _this2 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4() {
        var res;
        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                uni.showLoading({
                  title: '加载中'
                });
                // if(this.menusListContent.length){
                // 	this.menusListContent.forEach((menu)=>{
                // 		if(this.chooseMenuList.indexOf(menu)==-1){
                // 			this.chooseMenuList.push(menu)
                // 		}
                // 	})
                // }
                // this.setMenusListContent(this.chooseMenuList)
                // console.log(this.menusListContent,'menusListContent')
                // console.log(this.chooseMenuList,'chooseMenuList请求接口')
                _context4.next = 3;
                return _this2.API.menus.getVarietyList(1, _this2.org_business_id, _this2.menuCategoryName, '1', undefined, true);
              case 3:
                res = _context4.sent;
                if (res.code == 0) {
                  // let menuCount = 0
                  _this2.oldChooseMenuList = [];
                  _this2.menuList = res.data.map(function (el) {
                    // menuCount += el.recipe_num;
                    var checked = false;
                    _this2.chooseMenuList.map(function (chooseId) {
                      if (chooseId === el.id) {
                        checked = true;
                        _this2.oldChooseMenuList.push(chooseId);
                      }
                    });
                    return _objectSpread(_objectSpread({}, el), {}, {
                      bringtKeyList: el.name.split('').map(function (item) {
                        return {
                          'value': item,
                          'color': 'rgba(0, 0, 0, 1)'
                        };
                      }),
                      checked: checked,
                      loading: false,
                      // 过度效果
                      twoChildren: [] // 二层数据
                    });
                  });
                  // uni.setStorageSync('allMenuCount', tokenValue)
                  _this2.chooseMenuList.forEach( /*#__PURE__*/function () {
                    var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(choose) {
                      return _regenerator.default.wrap(function _callee3$(_context3) {
                        while (1) {
                          switch (_context3.prev = _context3.next) {
                            case 0:
                              _context3.next = 2;
                              return Promise.all(_this2.menuList.map( /*#__PURE__*/function () {
                                var _ref2 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(menu) {
                                  var menu1, allMatch;
                                  return _regenerator.default.wrap(function _callee2$(_context2) {
                                    while (1) {
                                      switch (_context2.prev = _context2.next) {
                                        case 0:
                                          if (!(menu.id == choose)) {
                                            _context2.next = 4;
                                            break;
                                          }
                                          return _context2.abrupt("return", _objectSpread(_objectSpread({}, menu), {}, {
                                            checked: true
                                          }));
                                        case 4:
                                          _context2.next = 6;
                                          return _this2.API.menus.getRecipeSubdata(menu.id, _this2.org_business_id);
                                        case 6:
                                          menu1 = _context2.sent;
                                          allMatch = menu1.data.every(function (item) {
                                            return _this2.chooseMenuList.includes(item.recipe_id);
                                          });
                                          if (!allMatch) {
                                            _context2.next = 12;
                                            break;
                                          }
                                          return _context2.abrupt("return", _objectSpread(_objectSpread({}, menu), {}, {
                                            checked: true
                                          }));
                                        case 12:
                                          return _context2.abrupt("return", menu);
                                        case 13:
                                        case "end":
                                          return _context2.stop();
                                      }
                                    }
                                  }, _callee2);
                                }));
                                return function (_x2) {
                                  return _ref2.apply(this, arguments);
                                };
                              }()));
                            case 2:
                              _this2.menuList = _context3.sent;
                            case 3:
                            case "end":
                              return _context3.stop();
                          }
                        }
                      }, _callee3);
                    }));
                    return function (_x) {
                      return _ref.apply(this, arguments);
                    };
                  }());
                  console.log(_this2.menuList, 'this.menuList');
                  if (_this2.menuCategoryName) {
                    _this2.menuList.forEach(function (menu) {
                      menu.bringtKeyList.forEach(function (key) {
                        if (_this2.menuCategoryName.indexOf(key.value) != -1) {
                          key.color = 'rgba(255, 125, 0, 1)';
                        } else {
                          key.color = 'rgba(0, 0, 0, 1)';
                        }
                      });
                    });
                  }
                  _this2.setAllMenus(_this2.menuList);
                  uni.hideLoading();
                } else {
                  setTimeout(function () {
                    uni.hideLoading();
                  }, 5000);
                  uni.showModal({
                    content: '搜索失败',
                    success: function success(res) {
                      if (res.confirm) {
                        console.log('确定');
                      } else if (res.cancel) {
                        console.log('取消');
                      }
                    }
                  });
                }
              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    clearIcon: function clearIcon() {
      this.menuCategoryName = '';
      this.getMenuListData();
    },
    queryMenu: function queryMenu(val) {
      this.menuCategoryName = val.detail.value;
      this.keyWord = this.menuCategoryName;
      this.getMenuListData();
    },
    brightenKeyword: function brightenKeyword(val, key) {
      var Reg = new RegExp(key);
      if (val) {
        var res = val.replace(Reg, "<text style=\"color:#D7311E;\">".concat(key, "</text>"));
        console.log(res, ',resresresresres');
        return res;
      }
    },
    upDateChooseMenu: function upDateChooseMenu() {
      var _this3 = this;
      this.chooseMenuList = [];
      this.menuList.forEach(function (item) {
        if (item.checked) {
          if (item.recipe_num > 1) {
            item.recipe_ids.split(',').forEach(function (id) {
              return _this3.chooseMenuList.push(id);
            });
          } else {
            _this3.chooseMenuList.push(item.recipe_ids);
          }
        } else {
          item.twoChildren.forEach(function (child) {
            if (child.checked) _this3.chooseMenuList.push(child.recipe_id);
          });
        }
      });
      // this.setMenusListContent(this.chooseMenuList)
      console.log(this.chooseMenuList, '选中的菜谱');
    },
    upDateChecked: function upDateChecked() {
      // console.log('up新子节点')
      this.menuList.forEach(function (item) {
        item.checked = item['twoChildren'].length ? item['twoChildren'].every(function (subItem) {
          return subItem.checked === true;
        }) : item.checked;
      });
    },
    changeCheckBox: function changeCheckBox(e) {
      var _this4 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee5() {
        var _loop, i, _ret, index, _i, status, j, _iterator, _step, _loop2;
        return _regenerator.default.wrap(function _callee5$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                if (!(_this4.oldChooseMenuList.length > e.detail.value.length)) {
                  _context6.next = 12;
                  break;
                }
                _loop = function _loop(i) {
                  var status = false;
                  e.detail.value.forEach(function (item) {
                    if (_this4.oldChooseMenuList[i] === item) {
                      status = true;
                    }
                  });
                  if (!status) {
                    var index = -1;
                    for (var j = 0; j < _this4.chooseMenuList.length; j++) {
                      if (_this4.chooseMenuList[j] == _this4.oldChooseMenuList[i]) {
                        index = j;
                        _this4.chooseMenuList.splice(j, 1);
                        _this4.oldChooseMenuList.splice(i, 1);
                        break;
                      }
                    }
                    if (index >= 0) {
                      return "break";
                    }
                  }
                };
                i = 0;
              case 3:
                if (!(i < _this4.oldChooseMenuList.length)) {
                  _context6.next = 10;
                  break;
                }
                _ret = _loop(i);
                if (!(_ret === "break")) {
                  _context6.next = 7;
                  break;
                }
                return _context6.abrupt("break", 10);
              case 7:
                i++;
                _context6.next = 3;
                break;
              case 10:
                _context6.next = 32;
                break;
              case 12:
                index = -1;
                _i = 0;
              case 14:
                if (!(_i < e.detail.value.length)) {
                  _context6.next = 32;
                  break;
                }
                status = true;
                j = 0;
              case 17:
                if (!(j < _this4.oldChooseMenuList.length)) {
                  _context6.next = 25;
                  break;
                }
                if (!(e.detail.value[_i] === _this4.oldChooseMenuList[j])) {
                  _context6.next = 22;
                  break;
                }
                status = false;
                index = _i;
                return _context6.abrupt("break", 25);
              case 22:
                j++;
                _context6.next = 17;
                break;
              case 25:
                if (!status) {
                  _context6.next = 29;
                  break;
                }
                _this4.oldChooseMenuList.push(e.detail.value[_i]);
                _this4.chooseMenuList.push(e.detail.value[_i]);
                return _context6.abrupt("break", 32);
              case 29:
                _i++;
                _context6.next = 14;
                break;
              case 32:
                _iterator = _createForOfIteratorHelper(_this4.menuList);
                _context6.prev = 33;
                _loop2 = /*#__PURE__*/_regenerator.default.mark(function _loop2() {
                  var item, sign, menu, _menu, countToAdd;
                  return _regenerator.default.wrap(function _loop2$(_context5) {
                    while (1) {
                      switch (_context5.prev = _context5.next) {
                        case 0:
                          item = _step.value;
                          sign = true;
                          e.detail.value.forEach(function (item_id) {
                            if (item.id === item_id) sign = false;
                          });
                          if (!sign) {
                            _context5.next = 14;
                            break;
                          }
                          if (!(item.checked !== false)) {
                            _context5.next = 12;
                            break;
                          }
                          _context5.next = 7;
                          return _this4.API.menus.getRecipeSubdata(item.id, _this4.org_business_id);
                        case 7:
                          menu = _context5.sent;
                          menu.data.forEach(function (menuItem) {
                            if (_this4.chooseMenuList.includes(menuItem.recipe_id)) {
                              // 从 this.chooseMenuList 中删除已存在的 recipe_id
                              var _index = _this4.chooseMenuList.indexOf(menuItem.recipe_id);
                              if (_index !== -1) {
                                _this4.chooseMenuList.splice(_index, 1);
                              }
                              var index1 = _this4.chooseMenuList.indexOf(item.id);
                              if (index1 !== -1) {
                                _this4.chooseMenuList.splice(index1, 1);
                              }
                            }
                          });
                          _this4.chooseMenuCount -= item.recipe_num;
                          item.checked = false;
                          if (item['twoChildren'].length) {
                            item['twoChildren'].forEach(function (child) {
                              return child.checked = false;
                            });
                          }
                        case 12:
                          _context5.next = 23;
                          break;
                        case 14:
                          if (!(item.checked !== true)) {
                            _context5.next = 23;
                            break;
                          }
                          _context5.next = 17;
                          return _this4.API.menus.getRecipeSubdata(item.id, _this4.org_business_id);
                        case 17:
                          _menu = _context5.sent;
                          countToAdd = item.recipe_num;
                          _menu.data.forEach(function (menuItem) {
                            if (_this4.chooseMenuList.includes(menuItem.recipe_id)) {
                              countToAdd--;
                              // 从 this.chooseMenuList 中删除已存在的 recipe_id
                              var _index2 = _this4.chooseMenuList.indexOf(menuItem.recipe_id);
                              if (_index2 !== -1) {
                                _this4.chooseMenuList.splice(_index2, 1);
                                _this4.chooseMenuList.push(item.id);
                              }
                            }
                          });
                          _this4.chooseMenuCount += countToAdd;
                          item.checked = true;
                          if (item['twoChildren'].length) {
                            item['twoChildren'].forEach(function (child) {
                              return child.checked = true;
                            });
                          }
                        case 23:
                        case "end":
                          return _context5.stop();
                      }
                    }
                  }, _loop2);
                });
                _iterator.s();
              case 36:
                if ((_step = _iterator.n()).done) {
                  _context6.next = 40;
                  break;
                }
                return _context6.delegateYield(_loop2(), "t0", 38);
              case 38:
                _context6.next = 36;
                break;
              case 40:
                _context6.next = 45;
                break;
              case 42:
                _context6.prev = 42;
                _context6.t1 = _context6["catch"](33);
                _iterator.e(_context6.t1);
              case 45:
                _context6.prev = 45;
                _iterator.f();
                return _context6.finish(45);
              case 48:
                console.log(_this4.chooseMenuList);
                console.log(_this4.oldChooseMenuList);
                console.log(e.detail.value);
                console.log(_this4.menuList, '点击一级菜单this.menuList');
              case 52:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee5, null, [[33, 42, 45, 48]]);
      }))();
    },
    changeAll: function changeAll(e) {
      var _this5 = this;
      if (e.detail.value.length) {
        var count = 0;
        this.chooseMenuList = this.menuList.map(function (item) {
          count += item.recipe_num;
          return item.id;
        });
        this.chooseMenuCount = count;
      } else {
        this.chooseMenuList = [];
        this.chooseMenuCount = 0;
      }
      console.log(this.chooseMenuList, 'this.chooseMenuList全选');
      // console.log('时间筛选', e)
      this.checkAll = !this.checkAll;
      // this.setMenusListContent(this.chooseMenuList)
      this.menuList.forEach(function (item) {
        item.checked = _this5.checkAll;
        item['twoChildren'].forEach(function (subItem) {
          subItem.checked = _this5.checkAll;
        });
      });
      // this.upDateChooseMenu()
    },
    toDetail: function toDetail() {
      uni.navigateTo({
        url: '/menusPages/pages/menuDetail/menuDetail'
      });
    },
    toChooseMenu: function toChooseMenu() {
      uni.navigateTo({
        url: '/menusPages/pages/chooseMenu/chooseMenu'
      });
    },
    toChooseDevice: function toChooseDevice() {
      // 数据过滤
      console.log(this.chooseMenuList, '哈哈选择的菜谱');
      var newMenusList = [];
      if (!this.chooseMenuList.length) {
        uni.showToast({
          title: '请选择菜谱',
          icon: 'error'
        });
        return;
      }
      // this.menuList.forEach((item) => {
      // 	this.chooseMenuList.forEach((menu) => {
      // 		if (item.id == menu) {
      // 			newMenusList.push(item.recipe_ids)
      // 		}
      // 	})
      // })
      // console.log(newMenusList, 'newMenusListnewMenusListnewMenusList')
      var arr = Array.from(new Set(this.chooseMenuList));
      console.log(arr, 'arr');
      uni.navigateTo({
        url: "/menusPages/pages/downToDevice/downToDevice?chooseMenu=".concat(arr)
      });
    },
    // 调整控件
    controlAdjustment: function controlAdjustment(index) {
      if (index === this.secondaryControl) this.secondaryControl = '';else this.secondaryControl = index;
      this.secondaryControl !== '' && this.obtainLayerTwodata(); // 请求第二层数据
    },
    // 获取第二层数据
    obtainLayerTwodata: function obtainLayerTwodata() {
      var _this6 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee6() {
        var _this6$menuList$_this;
        var menu;
        return _regenerator.default.wrap(function _callee6$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                // 清除一下所有过度效果避免重复出现
                _this6.colseLoading();
                // 开启过度效果
                _this6.menuList[_this6.secondaryControl].loading = true; // 开启过度效果 

                // 判断是否已有数据
                if (!((_this6$menuList$_this = _this6.menuList[_this6.secondaryControl]['twoChildren'][0]) !== null && _this6$menuList$_this !== void 0 && _this6$menuList$_this.recipe_id && _this6.menuList[_this6.secondaryControl]['twoChildren'].length)) {
                  _context7.next = 5;
                  break;
                }
                setTimeout(function () {}, 500);
                return _context7.abrupt("return");
              case 5:
                _context7.next = 7;
                return _this6.API.menus.getRecipeSubdata(_this6.menuList[_this6.secondaryControl].id, _this6.org_business_id);
              case 7:
                menu = _context7.sent;
                // 这段代码是部数据的 用来测试 后端数据保证没问题后可以删除
                // menu.data.forEach(item => {
                // 	if (!item.recipe_id) item.recipe_id = '3sdsjjads8sdhjahsd8ads'
                // })
                // ---------------------------------------------------------------------------------
                _this6.chooseMenuList.map(function (menu1) {
                  if (_this6.menuList[_this6.secondaryControl].id === menu1) {
                    menu.data.forEach(function (item) {
                      item.checked = true;
                    });
                  } else {
                    menu.data.forEach(function (item) {
                      if (menu1 === item.recipe_id) {
                        item.checked = true;
                      }
                    });
                  }
                });
                _this6.loadingTime = setTimeout(function () {
                  _this6.menuList[_this6.secondaryControl].twoChildren = menu.data.length ? menu.data : [{
                    recipe_id: '',
                    checked: _this6.menuList[_this6.secondaryControl].checked
                  }]; // 二级菜单
                  _this6.menuList[_this6.secondaryControl].loading = false; // 关闭过度效果 
                  _this6.upDateChecked();
                }, 500);
              case 10:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee6);
      }))();
    },
    // 清除所有过度
    colseLoading: function colseLoading() {
      clearTimeout(this.loadingTime); // 清除上一次计时器
      this.menuList.forEach(function (item) {
        item.loading = false;
      });
    },
    // 二级菜单数据变化
    changeCheckBoxItem: function changeCheckBoxItem(e) {
      var _this7 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee7() {
        var value, _iterator2, _step2, item, index, menu, hasChecked, _iterator3, _step3, menuItem, parentIndex;
        return _regenerator.default.wrap(function _callee7$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                value = e.detail.value;
                console.log(value, '点击二级菜单');

                // 遍历当前控制的二级菜单项
                _iterator2 = _createForOfIteratorHelper(_this7.menuList[_this7.secondaryControl]['twoChildren']);
                _context8.prev = 3;
                _iterator2.s();
              case 5:
                if ((_step2 = _iterator2.n()).done) {
                  _context8.next = 45;
                  break;
                }
                item = _step2.value;
                console.log(value.indexOf(item.recipe_id), item.recipe_id);
                if (!(value.indexOf(item.recipe_id) !== -1)) {
                  _context8.next = 13;
                  break;
                }
                console.log(111);
                if (!item.checked) {
                  item.checked = true;
                  _this7.chooseMenuList.push(item.recipe_id); // 添加到 chooseMenuList
                  _this7.chooseMenuCount++;
                }
                _context8.next = 43;
                break;
              case 13:
                console.log(222);
                if (!item.checked) {
                  _context8.next = 43;
                  break;
                }
                item.checked = false;
                _this7.chooseMenuCount--;

                // 从 chooseMenuList 中移除
                index = _this7.chooseMenuList.indexOf(item.recipe_id);
                if (index !== -1) {
                  _this7.chooseMenuList.splice(index, 1);
                }

                // 获取所有同级二级菜单项
                _context8.next = 21;
                return _this7.API.menus.getRecipeSubdata(item.recipe_category_id, _this7.org_business_id);
              case 21:
                menu = _context8.sent;
                console.log(menu.data, 'menu.data');

                // 检查当前一级菜单下是否还有其他已选中的二级菜单项
                hasChecked = false;
                _iterator3 = _createForOfIteratorHelper(menu.data);
                _context8.prev = 25;
                _iterator3.s();
              case 27:
                if ((_step3 = _iterator3.n()).done) {
                  _context8.next = 34;
                  break;
                }
                menuItem = _step3.value;
                if (!(_this7.chooseMenuList.indexOf(menuItem.recipe_id) !== -1)) {
                  _context8.next = 32;
                  break;
                }
                hasChecked = true;
                return _context8.abrupt("break", 34);
              case 32:
                _context8.next = 27;
                break;
              case 34:
                _context8.next = 39;
                break;
              case 36:
                _context8.prev = 36;
                _context8.t0 = _context8["catch"](25);
                _iterator3.e(_context8.t0);
              case 39:
                _context8.prev = 39;
                _iterator3.f();
                return _context8.finish(39);
              case 42:
                // 如果当前一级菜单下没有其他已选中的二级菜单项，则移除一级菜单项的ID
                if (!hasChecked) {
                  parentIndex = _this7.chooseMenuList.indexOf(item.recipe_category_id);
                  if (parentIndex !== -1) {
                    _this7.chooseMenuList.splice(parentIndex, 1);
                  }
                }
              case 43:
                _context8.next = 5;
                break;
              case 45:
                _context8.next = 50;
                break;
              case 47:
                _context8.prev = 47;
                _context8.t1 = _context8["catch"](3);
                _iterator2.e(_context8.t1);
              case 50:
                _context8.prev = 50;
                _iterator2.f();
                return _context8.finish(50);
              case 53:
                console.log(_this7.menuList, '点击二级菜单this.menuList');
                console.log(_this7.chooseMenuList, '点击二级菜单this.chooseMenuList');
                _this7.upDateChecked();
              case 56:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee7, null, [[3, 47, 50, 53], [25, 36, 39, 42]]);
      }))();
    }
  }),
  onLoad: function onLoad() {
    this.org_business_id = this.customer.org_business_id, this.getMenuListData();
    this.getTotal();
    // this.setMenusListContent([])
    // this.setColor('1')
  }
};
exports.default = _default;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ 2)["default"]))

/***/ }),

/***/ 593:
/*!********************************************************************************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/menusPages/pages/chooseMenu/chooseMenu.vue?vue&type=style&index=0&id=dfe6385a&lang=less&scoped=true& ***!
  \********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_10_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_style_index_0_id_dfe6385a_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/mini-css-extract-plugin/dist/loader.js??ref--10-oneOf-1-0!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--10-oneOf-1-2!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/postcss-loader/src??ref--10-oneOf-1-3!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-4!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--10-oneOf-1-5!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./chooseMenu.vue?vue&type=style&index=0&id=dfe6385a&lang=less&scoped=true& */ 594);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_10_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_style_index_0_id_dfe6385a_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_10_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_style_index_0_id_dfe6385a_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_10_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_style_index_0_id_dfe6385a_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_10_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_style_index_0_id_dfe6385a_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_10_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_10_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_chooseMenu_vue_vue_type_style_index_0_id_dfe6385a_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ 594:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--10-oneOf-1-2!./node_modules/postcss-loader/src??ref--10-oneOf-1-3!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--10-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!D:/wp/rx/RX_fe_wxmp/menusPages/pages/chooseMenu/chooseMenu.vue?vue&type=style&index=0&id=dfe6385a&lang=less&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
    if(false) { var cssReload; }
  

/***/ })

},[[587,"common/runtime","common/vendor"]]]);
//# sourceMappingURL=../../../../.sourcemap/mp-weixin/menusPages/pages/chooseMenu/chooseMenu.js.map