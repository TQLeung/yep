(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/home/index"],{

/***/ 223:
/*!*******************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/main.js?{"page":"pages%2Fhome%2Findex"} ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(wx, createPage) {

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ 4);
__webpack_require__(/*! uni-pages */ 26);
var _vue = _interopRequireDefault(__webpack_require__(/*! vue */ 25));
var _index = _interopRequireDefault(__webpack_require__(/*! ./pages/home/index.vue */ 224));
// @ts-ignore
wx.__webpack_require_UNI_MP_PLUGIN__ = __webpack_require__;
createPage(_index.default);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ 1)["default"], __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ 2)["createPage"]))

/***/ }),

/***/ 224:
/*!************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/pages/home/index.vue ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=71e217db&scoped=true& */ 225);
/* harmony import */ var _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&lang=js& */ 227);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _index_vue_vue_type_style_index_0_id_71e217db_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.vue?vue&type=style&index=0&id=71e217db&lang=scss&scoped=true& */ 230);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ 33);

var renderjs





/* normalize component */

var component = Object(_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "71e217db",
  null,
  false,
  _index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"],
  renderjs
)

component.options.__file = "pages/home/index.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 225:
/*!*******************************************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/pages/home/index.vue?vue&type=template&id=71e217db&scoped=true& ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns, recyclableRender, components */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./index.vue?vue&type=template&id=71e217db&scoped=true& */ 226);
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "recyclableRender", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__["recyclableRender"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "components", function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_template_id_71e217db_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"]; });



/***/ }),

/***/ 226:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!D:/wp/rx/RX_fe_wxmp/pages/home/index.vue?vue&type=template&id=71e217db&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns, recyclableRender, components */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recyclableRender", function() { return recyclableRender; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "components", function() { return components; });
var components
try {
  components = {
    uniIcons: function () {
      return Promise.all(/*! import() | uni_modules/uni-icons/components/uni-icons/uni-icons */[__webpack_require__.e("common/vendor"), __webpack_require__.e("uni_modules/uni-icons/components/uni-icons/uni-icons")]).then(__webpack_require__.bind(null, /*! @/uni_modules/uni-icons/components/uni-icons/uni-icons.vue */ 611))
    },
    qiunDataCharts: function () {
      return Promise.all(/*! import() | uni_modules/qiun-data-charts/components/qiun-data-charts/qiun-data-charts */[__webpack_require__.e("common/vendor"), __webpack_require__.e("uni_modules/qiun-data-charts/components/qiun-data-charts/qiun-data-charts")]).then(__webpack_require__.bind(null, /*! @/uni_modules/qiun-data-charts/components/qiun-data-charts/qiun-data-charts.vue */ 619))
    },
    uniPopup: function () {
      return __webpack_require__.e(/*! import() | uni_modules/uni-popup/components/uni-popup/uni-popup */ "uni_modules/uni-popup/components/uni-popup/uni-popup").then(__webpack_require__.bind(null, /*! @/uni_modules/uni-popup/components/uni-popup/uni-popup.vue */ 637))
    },
    uniCollapse: function () {
      return __webpack_require__.e(/*! import() | uni_modules/uni-collapse/components/uni-collapse/uni-collapse */ "uni_modules/uni-collapse/components/uni-collapse/uni-collapse").then(__webpack_require__.bind(null, /*! @/uni_modules/uni-collapse/components/uni-collapse/uni-collapse.vue */ 644))
    },
    uniCollapseItem: function () {
      return __webpack_require__.e(/*! import() | uni_modules/uni-collapse/components/uni-collapse-item/uni-collapse-item */ "uni_modules/uni-collapse/components/uni-collapse-item/uni-collapse-item").then(__webpack_require__.bind(null, /*! @/uni_modules/uni-collapse/components/uni-collapse-item/uni-collapse-item.vue */ 651))
    },
  }
} catch (e) {
  if (
    e.message.indexOf("Cannot find module") !== -1 &&
    e.message.indexOf(".vue") !== -1
  ) {
    console.error(e.message)
    console.error("1. 排查组件名称拼写是否正确")
    console.error(
      "2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"
    )
    console.error(
      "3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件"
    )
  } else {
    throw e
  }
}
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  var g0 = _vm.customerInfo.org_name ? _vm.customerInfo.org_name.length : null
  var g1 =
    _vm.customerInfo.org_name && g0 <= 7
      ? _vm.customerInfo.org_name.slice(0, 7)
      : null
  var s0 = _vm.operationData.loading
    ? _vm.__get_style([
        _vm.operationData.loading
          ? {
              height: "40rpx",
            }
          : {
              height: "0rpx",
            },
      ])
    : null
  var m0 =
    _vm.operationData.cur &&
    !(_vm.operationData.cur.cooked_times < 10000) &&
    _vm.operationData.cur.cooked_times > 10000
      ? _vm.formatDecimal(_vm.operationData.cur.cooked_times / 10000, 0)
      : null
  var m1 = Number(_vm.operationData.timeData)
  var m2 = Number(_vm.operationData.timeData)
  var m3 = Number(_vm.operationData.timeData)
  var m4 = !(m3 > 0) ? Number(_vm.operationData.timeData < 0) : null
  var m5 =
    !(
      _vm.operationData.cur &&
      _vm.operationData.cur.consumed_minute &&
      _vm.operationData.cur.consumed_minute < 60
    ) &&
    _vm.operationData.cur &&
    _vm.operationData.cur.consumed_minute &&
    _vm.operationData.cur.consumed_minute > 60 &&
    _vm.operationData.cur.consumed_minute > 600000
      ? _vm.formatDecimal(_vm.operationData.cur.consumed_minute / 60 / 10000, 1)
      : null
  var m6 =
    !(
      _vm.operationData.cur &&
      _vm.operationData.cur.consumed_minute &&
      _vm.operationData.cur.consumed_minute < 60
    ) &&
    _vm.operationData.cur &&
    _vm.operationData.cur.consumed_minute &&
    _vm.operationData.cur.consumed_minute > 60 &&
    !(_vm.operationData.cur.consumed_minute > 600000)
      ? _vm.formatDecimal(_vm.operationData.cur.consumed_minute / 60, 1)
      : null
  var m7 = Number(_vm.operationData.minuteData)
  var m8 = Number(_vm.operationData.minuteData)
  var m9 =
    _vm.operationData.cur &&
    !(_vm.operationData.cur.consumed_energy < 10000) &&
    _vm.operationData.cur.consumed_energy > 10000
      ? _vm.formatDecimal(_vm.operationData.cur.consumed_energy / 10000, 1)
      : null
  var s1 = _vm.cookingTimeLoading
    ? _vm.__get_style([
        _vm.cookingTimeLoading
          ? {
              height: "40rpx",
            }
          : {
              height: "0rpx",
            },
      ])
    : null
  var s2 = _vm.cookingCategoryLoading
    ? _vm.__get_style([
        _vm.cookingCategoryLoading
          ? {
              height: "40rpx",
            }
          : {
              height: "0rpx",
            },
      ])
    : null
  var s3 = _vm.foodLoading
    ? _vm.__get_style([
        _vm.foodLoading
          ? {
              height: "40rpx",
            }
          : {
              height: "0rpx",
            },
      ])
    : null
  var s4 = _vm.flavourLoading
    ? _vm.__get_style([
        _vm.flavourLoading
          ? {
              height: "40rpx",
            }
          : {
              height: "0rpx",
            },
      ])
    : null
  _vm.$mp.data = Object.assign(
    {},
    {
      $root: {
        g0: g0,
        g1: g1,
        s0: s0,
        m0: m0,
        m1: m1,
        m2: m2,
        m3: m3,
        m4: m4,
        m5: m5,
        m6: m6,
        m7: m7,
        m8: m8,
        m9: m9,
        s1: s1,
        s2: s2,
        s3: s3,
        s4: s4,
      },
    }
  )
}
var recyclableRender = false
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ 227:
/*!*************************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/pages/home/index.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/babel-loader/lib!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--13-1!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./index.vue?vue&type=script&lang=js& */ 228);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_pf_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ 228:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--13-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!D:/wp/rx/RX_fe_wxmp/pages/home/index.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(uni) {

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ 4);
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ 212));
var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ 214));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ 11));
var _tabbar = _interopRequireDefault(__webpack_require__(/*! @/uni_modules/niceui-tabBar/common/tabbar.js */ 229));
var _vuex = __webpack_require__(/*! vuex */ 30);
var _computed$components$;
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var CustomTabBar = function CustomTabBar() {
  __webpack_require__.e(/*! require.ensure | uni_modules/niceui-tabBar/components/niceui-tabBar/niceui-tabBar */ "uni_modules/niceui-tabBar/components/niceui-tabBar/niceui-tabBar").then((function () {
    return resolve(__webpack_require__(/*! @/uni_modules/niceui-tabBar/components/niceui-tabBar/niceui-tabBar.vue */ 658));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var _default = (_computed$components$ = {
  computed: _objectSpread(_objectSpread({}, (0, _vuex.mapState)('menus', ['customer'])), (0, _vuex.mapState)('authority', ['authority'])),
  components: {
    CustomTabBar: CustomTabBar
  },
  data: function data() {
    return {
      currentTab: 0,
      // 当前选中的tab索引  
      chartToTop: this.$chartToTop,
      tabItems: [],
      color: _tabbar.default.color,
      selectedColor: _tabbar.default.selectedColor,
      statusBarHeight: uni.getStorageSync('menuInfo').statusBarHeight,
      //状态栏的高度（可以设置为顶部导航条的padding-top）
      menuWidth: uni.getStorageSync('menuInfo').menuWidth,
      menuHeight: uni.getStorageSync('menuInfo').menuHeight,
      menuBorderRadius: uni.getStorageSync('menuInfo').menuBorderRadius,
      menuRight: uni.getStorageSync('menuInfo').menuRight,
      menuTop: uni.getStorageSync('menuInfo').menuTop,
      contentTop: uni.getStorageSync('menuInfo').contentTop,
      troubleError: 0,
      channelTreeData: [],
      userTreeData: [],
      storeTreeData: [],
      userInfo: {},
      status: '1',
      value: [],
      treeList: [],
      // 组织类型
      treeLabel: '',
      currentDeviceCount: 0,
      customerInfo: {},
      org_business_id: '',
      foodTotal: 0,
      flavourTotal: 0,
      categoryTotal: 0,
      operationText: '上月',
      operationTitleIndex: '4',
      cookingTimeIndex: '4',
      menuCategoryIndex: '4',
      foodIndex: '4',
      flavourIndex: '4',
      // 商户/门店得运营数据
      operationData: {},
      cookingTimeLoading: false,
      cookingCategoryLoading: false,
      foodLoading: false,
      flavourLoading: false,
      chartData: {},
      latest_time: '',
      latest_time_total: 0,
      foodChartData: {},
      flavourChartData: {},
      cookingChartData: {},
      // 调料、养锅数据
      deviceCardData: {},
      // 点击类型
      detailTitle: '',
      deviceCount: 0,
      labelAll: '',
      cookingOpts: {
        // height:'58px',
        color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4", "#ea7ccc"],
        padding: [16, 16, 16, 16],
        enableScroll: false,
        dataLabel: false,
        legend: {
          show: false
        },
        xAxis: {
          scrollShow: true,
          disableGrid: true,
          calibration: true,
          fontSize: '12',
          format: 'xAxisDemo3'
        },
        yAxis: {
          disabled: true,
          disableGrid: false,
          data: [{
            min: 0
          }],
          gridType: 'dash',
          dashLength: 4,
          gridColor: '#E8E8E8'
        },
        extra: {
          column: {
            type: "group",
            width: 5,
            activeBgColor: "#000000",
            activeBgOpacity: 0.08
          },
          tooltip: {
            legendShape: 'circle',
            xAxisLabel: true,
            yAxisLabel: true,
            type: 'slide',
            color: '#ff0000'
          }
        }
      },
      uChartsInstance: {},
      opts: {
        // color: ["#1890FF","#91CB74","#FAC858","#EE6666","#73C0DE","#3CA272","#FC8452","#9A60B4","#ea7ccc"],
        width: '258px',
        height: '258',
        padding: [8, 50, 8, 5],
        legend: {
          show: false
        },
        xAxis: {
          disabled: true,
          gridColor: "transparent"
        },
        yAxis: {},
        extra: {
          bar: {
            type: "group",
            width: 7,
            meterBorde: 1,
            color: "#000000",
            // meterFillColor: "#FFFFFF",
            activeBgColor: "#000000",
            activeBgOpacity: 0.08,
            linearType: "none",
            barBorderCircle: true,
            seriesGap: 2,
            categoryGap: 7
          },
          tooltip: {
            // horizentalLine: false
            // showBox:false,
            // legendShow:false,
            // legendShow:false,
            boxPadding: 0,
            legendShape: 'circle',
            xAxisLabel: true,
            yAxisLabel: true,
            type: 'slide'
          }
        }
      }
    };
  },
  onShow: function onShow() {
    //⭐隐藏pages.json里配置的导航栏，使用封装的tabbar组件
    uni.hideTabBar({
      animation: false
    });
  },
  methods: _objectSpread(_objectSpread(_objectSpread(_objectSpread({}, (0, _vuex.mapMutations)('menus', ['setCustomer'])), (0, _vuex.mapMutations)('home', ['setDeviceDetailData'])), (0, _vuex.mapMutations)('authority', ['changeTab'])), {}, {
    onTabClick: function onTabClick(index) {
      // 切换tab的函数，当选中某个tab时触发  
      // if(index!=this.currentTab){
      this.currentTab = index;
      this.changeTab(index);
      // console.log('当前点击0', this.tabItems[index].pagePath,this.currentTab)
      uni.switchTab({
        url: '../../' + this.tabItems[index].pagePath
      });
      // }
    },
    // 切换商户或者门店的运营数据
    changeOperationTitleIndex: function changeOperationTitleIndex(index) {
      this.operationTitleIndex = index;
      if (index == '2') {
        this.operationText = '昨日';
      } else if (index == '1') {
        this.operationText = '昨日';
      } else if (index == '3') {
        this.operationText = '上周';
      } else {
        this.operationText = '上月';
      }
      this.getUserDataDetail(this.org_business_id);
      this.getDeviceDetailData(this.org_business_id);
    },
    changeCookingTimeIndex: function changeCookingTimeIndex(index) {
      this.cookingTimeIndex = index;
      this.getCookCopiesData(this.org_business_id);
    },
    changemenuCategoryIndex: function changemenuCategoryIndex(index) {
      this.menuCategoryIndex = index;
      this.getServerData(this.org_business_id);
    },
    changeFoodIndex: function changeFoodIndex(index) {
      this.foodIndex = index;
      this.getFoodData(this.org_business_id);
    },
    // 调料
    changeFlavourIndex: function changeFlavourIndex(index) {
      this.flavourIndex = index;
      this.getFlavourData(this.org_business_id);
    },
    // 获取当前账号组织架构数据
    getTreeList: function getTreeList() {
      var _this = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var tree;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                uni.showLoading({
                  title: '加载中'
                });
                _context.next = 3;
                return _this.API.menus.getTree();
              case 3:
                tree = _context.sent;
                uni.hideLoading();
                if (tree.code == 0) {
                  if (tree.data[0].label == '总部') {
                    _this.labelAll = '总部';
                    _this.treeList = tree.data[0].children;
                  } else {
                    _this.treeList = tree.data;
                  }
                  if (_this.customer.org_business_id) {
                    _this.customerInfo = _this.customer;
                  } else {
                    if (_this.treeList[0].label == '商户') {
                      _this.customerInfo = _this.treeList[0];
                    } else {
                      _this.customerInfo = _this.treeList[0].children[0];
                    }
                  }
                  _this.customerInfo.logoName = _this.customerInfo.org_name.slice(0, 1);
                  console.log(_this.customerInfo.org_name, 'this.customerInfo.org_name');
                  _this.channelTreeData = tree.data.filter(function (item) {
                    return item.label == '渠道';
                  });
                  _this.channelTreeData = _this.channelTreeData.map(function (item) {
                    return _objectSpread(_objectSpread({}, item), {}, {
                      channelImage: true,
                      children: item.children_count ? item.children.map(function (child) {
                        return _objectSpread(_objectSpread({}, child), {}, {
                          userImage: true
                        });
                      }) : []
                    });
                  });
                  _this.userTreeData = tree.data.filter(function (item) {
                    return item.label == '商户';
                  });
                  _this.userTreeData = _this.userTreeData.map(function (item) {
                    return _objectSpread(_objectSpread({}, item), {}, {
                      userImage: true
                    });
                  });
                  _this.storeTreeData = tree.data.filter(function (item) {
                    return item.label == '门店';
                  });
                  // console.log(this.channelTreeData,'channelTreeData获取的组织数据')
                  // console.log(this.userTreeData,'userTreeData获取的组织数据')
                  // console.log(this.storeTreeData,'storeTreeData获取的组织数据')
                  _this.setCustomer(_this.customerInfo);
                  _this.org_business_id = _this.customer.org_business_id;
                  _this.treeLabel = _this.customer.label;
                  _this.deviceCount = _this.customer.device_count;
                  // console.log(this.customer, '获取当前的this.customer1')
                  // 请求图表数据
                  if (_this.org_business_id) {
                    _this.getServerData(_this.org_business_id);
                    _this.getUserDataDetail(_this.org_business_id);
                    _this.getFoodData(_this.org_business_id);
                    _this.getFlavourData(_this.org_business_id);
                    _this.getCookCopiesData(_this.org_business_id);
                    _this.getDeviceDetailData(_this.org_business_id);
                  }
                }
                if (_this.treeList[0].label == '渠道') {
                  // console.log(this.treeList,'this.treeListthis.treeListthis.treeList')
                  _this.treeList = _this.treeList.map(function (item) {
                    return _objectSpread(_objectSpread({}, item), {}, {
                      channelImage: true,
                      children: item.children_count ? item.children.map(function (child) {
                        return _objectSpread(_objectSpread({}, child), {}, {
                          userImage: true
                        });
                      }) : []
                    });
                  });
                }
              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // 处理小数取值
    formatDecimal: function formatDecimal(num, decimal) {
      //num 传入小数, decimal 保留几位小数
      var _num = num.toString();
      var index = _num.indexOf('.');
      if (index !== -1) {
        _num = _num.substring(0, decimal + index + 1);
      } else {
        _num = _num.substring(0);
      }
      return parseFloat(_num).toFixed(decimal);
    },
    getYearMonthDay: function getYearMonthDay(value) {
      var date = new Date(value);
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var day = date.getDate();
      return this.daysFromDate(year, month, day);
    },
    getMidnightTimestamp: function getMidnightTimestamp(date) {
      if (!(date instanceof Date)) {
        date = new Date(); // 如果没有提供日期，则默认为当前日期
      }

      return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0).getTime();
    },
    daysFromDate: function daysFromDate(year, month, day) {
      // 将参数转换为毫秒
      var startDate = new Date(year, month - 1, day).getTime();
      var currentDate = new Date().getTime();
      var midnightTimestamp2 = this.getMidnightTimestamp();
      var midnight = new Date();
      midnight.setHours(0, 0, 0, 0);
      var midnightTimestamp = midnight.getTime();
      var diff = (currentDate - startDate) / (1000 * 60 * 60 * 24);
      if (currentDate > midnightTimestamp) {
        this.isPlus = true;
        return Math.abs(this.formatDecimal(diff, 0));
      } else {
        return Math.abs(this.formatDecimal(diff, 0));
      }
    },
    // 获取商户运营数据
    getUserDataDetail: function getUserDataDetail(id) {
      var _this2 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        var res, _res;
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _this2.operationData.loading = true;
                if (!(_this2.treeLabel == '商户')) {
                  _context2.next = 7;
                  break;
                }
                _context2.next = 4;
                return _this2.API.home.getUserData(_this2.org_business_id, _this2.operationTitleIndex);
              case 4:
                res = _context2.sent;
                _context2.next = 10;
                break;
              case 7:
                _context2.next = 9;
                return _this2.API.home.getStoreData(_this2.org_business_id, _this2.operationTitleIndex);
              case 9:
                res = _context2.sent;
              case 10:
                if (res.code == 200) {
                  _this2.operationData = res.data;
                  if (!res.data.cur) {
                    _this2.operationData.cur = {
                      cooked_times: 0,
                      consumed_minute: 0,
                      consumed_energy: 0
                    };
                  }
                  if (res.data.latest_time != null) {
                    _this2.latest_time = res.data.latest_time.replace('T', ' ').split(' ')[1];
                    _this2.latest_time = _this2.latest_time.split(':')[0] + ':' + _this2.latest_time.split(':')[1];
                    _this2.latest_time_total = _this2.getYearMonthDay(res.data.latest_time);
                  } else {
                    _this2.latest_time = '暂无';
                  }
                  if (_this2.operationData.cur && _this2.operationData.cur.consumed_energy) {
                    _this2.operationData.cur.consumed_energy = _this2.formatDecimal(_this2.operationData.cur.consumed_energy, 1);
                  }
                  if (_this2.operationData.cur && _this2.operationData.cur.consumed_minute) {
                    _this2.operationData.cur.consumed_minute = _this2.formatDecimal(_this2.operationData.cur.consumed_minute, 1);
                  }
                  if (_this2.operationData.pre && _this2.operationData.pre.cooked_times) {
                    _this2.operationData.pre.cooked_times = _this2.formatDecimal(_this2.operationData.pre.cooked_times, 1);
                  }
                  if (_this2.operationData.pre && _this2.operationData.pre.consumed_energy) {
                    _this2.operationData.pre.consumed_energy = _this2.formatDecimal(_this2.operationData.pre.consumed_energy, 1);
                  }
                  if (_this2.operationData.pre && _this2.operationData.pre.consumed_minute) {
                    _this2.operationData.pre.consumed_minute = _this2.formatDecimal(_this2.operationData.pre.consumed_minute, 1);
                  }
                  if (_this2.operationData.cur && _this2.operationData.pre && _this2.operationData.cur.cooked_times && Number(_this2.operationData.pre.cooked_times)) {
                    _this2.operationData.pre.cooked_times = _this2.formatDecimal(_this2.operationData.pre.cooked_times, 1);
                    _res = _this2.operationData.cur.cooked_times - _this2.operationData.pre.cooked_times;
                    _this2.operationData.timeData = _this2.formatDecimal(_res / _this2.operationData.pre.cooked_times, 2);
                    _this2.operationData.timeData = _this2.formatDecimal(_this2.operationData.timeData * 100, 1);
                    // this.operationData.timeData=Math.abs(this.operationData.timeData)
                  } else {
                    _this2.operationData.timeData = 0.00;
                  }
                  if (_this2.operationData.cur && _this2.operationData.pre && _this2.operationData.cur.consumed_energy && Number(_this2.operationData.pre.consumed_energy)) {
                    _this2.operationData.pre.consumed_energy = _this2.formatDecimal(_this2.operationData.pre.consumed_energy, 1);
                    _this2.operationData.energyData = _this2.formatDecimal((_this2.operationData.cur.consumed_energy - _this2.operationData.pre.consumed_energy) / _this2.operationData.pre.consumed_energy, 2) * 100;
                    _this2.operationData.energyData = _this2.formatDecimal(_this2.operationData.energyData, 1);
                    // this.operationData.energyData=Math.abs(this.operationData.energyData)
                  } else {
                    _this2.operationData.energyData = 0.00;
                  }
                  if (_this2.operationData.cur && _this2.operationData.pre && _this2.operationData.cur.consumed_minute && Number(_this2.operationData.pre.consumed_minute)) {
                    _this2.operationData.pre.consumed_minute = _this2.formatDecimal(_this2.operationData.pre.consumed_minute, 1);
                    _this2.operationData.minuteData = _this2.formatDecimal((_this2.operationData.cur.consumed_minute - _this2.operationData.pre.consumed_minute) / _this2.operationData.pre.consumed_minute, 2) * 100;
                    _this2.operationData.minuteData = _this2.formatDecimal(_this2.operationData.minuteData, 1);
                    // this.operationData.minuteData=Math.abs(this.operationData.minuteData)
                  } else {
                    _this2.operationData.minuteData = 0.00;
                  }
                  _this2.operationData.loading = false;
                }
                // console.log(this.operationData, 'res获取商户运营数据')
              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    clickChannel: function clickChannel(index) {
      this.treeList[index].channelImage = !this.treeList[index].channelImage;
      // console.log(this.treeList[index].channelImage,'this.treeList[index].channelImage')
    },
    clickUser: function clickUser(index, childIndex) {
      if (childIndex >= 0) {
        this.treeList[index].children[childIndex].userImage = !this.treeList[index].children[childIndex].userImage;
        this.channelTreeData[index].children[childIndex].userImage = !this.channelTreeData[index].children[childIndex].userImage;
      }
      this.userTreeData[index].userImage = !this.userTreeData[index].userImage;
    },
    getCurrentInfo: function getCurrentInfo(row) {
      this.deviceList = [];
      this.customerInfo = row;
      this.customerInfo.logoName = this.customerInfo.org_name.slice(0, 1);
      console.log(this.customerInfo, 'this.customerInfo22');
      this.setCustomer(this.customerInfo);
      // console.log(this.customer, '获取当前的this.customer2')
      this.org_business_id = this.customer.org_business_id;
      this.treeLabel = this.customer.label;
      this.deviceCount = this.customer.device_count;
      // 请求图表数据
      this.getServerData(this.org_business_id);
      this.getDeviceDetailData(this.org_business_id);
      this.getUserDataDetail(this.org_business_id);
      this.getFoodData(this.org_business_id);
      this.getFlavourData(this.org_business_id);
      this.getCookCopiesData(this.org_business_id);
      this.$refs.popup.close();
    },
    changePopup: function changePopup() {
      this.$refs.popup.open('bottom');
    },
    colsePopup: function colsePopup() {
      this.$refs.popup.close();
      this.value = [];
    },
    // 获取设备泵、养锅数据
    getDeviceDetailData: function getDeviceDetailData(id) {
      var _this3 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
        var res;
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(_this3.treeLabel == '商户')) {
                  _context3.next = 6;
                  break;
                }
                _context3.next = 3;
                return _this3.API.home.getDeviceDetail(1, _this3.org_business_id);
              case 3:
                res = _context3.sent;
                _context3.next = 9;
                break;
              case 6:
                _context3.next = 8;
                return _this3.API.home.getStoreDeviceDetail(1, _this3.org_business_id);
              case 8:
                res = _context3.sent;
              case 9:
                _this3.deviceCardData = res;
              case 10:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    // 获取菜品排行数据并且渲染图
    getServerData: function getServerData(id) {
      var _this4 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4() {
        var res, fillArr, result;
        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _this4.chartData = JSON.parse(JSON.stringify({}));
                _this4.cookingCategoryLoading = true;
                if (!(_this4.treeLabel == '商户')) {
                  _context4.next = 8;
                  break;
                }
                _context4.next = 5;
                return _this4.API.home.getMenuCategoryData(_this4.org_business_id, _this4.menuCategoryIndex);
              case 5:
                res = _context4.sent;
                _context4.next = 11;
                break;
              case 8:
                _context4.next = 10;
                return _this4.API.home.getStoreMenuCategoryData(_this4.org_business_id, _this4.menuCategoryIndex);
              case 10:
                res = _context4.sent;
              case 11:
                _this4.categoryTotal = res.paging.total_records;
                // 补齐
                fillArr = Array.from({
                  length: 10 - _this4.categoryTotal
                }, function () {
                  return {
                    c: 0,
                    recipe_category_name: '-'
                  };
                });
                result = res.data.concat(fillArr);
                setTimeout(function () {
                  var dataDetail = {
                    categories: result.map(function (item) {
                      if (item.recipe_category_name.length > 8) {
                        return item.recipe_category_name.slice(0, 8) + '...';
                      } else {
                        return item.recipe_category_name;
                      }
                    }),
                    series: [{
                      name: '',
                      data: result.map(function (item) {
                        return item.c;
                      })
                    }]
                  };
                  _this4.chartData = JSON.parse(JSON.stringify(dataDetail));
                  _this4.cookingCategoryLoading = false;
                }, 0);
              case 15:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    // 获取烹饪时段炒至份数
    getCookCopiesData: function getCookCopiesData(id) {
      var _this5 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee5() {
        var res, arr, key, max, i;
        return _regenerator.default.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _this5.cookingChartData = JSON.parse(JSON.stringify({}));
                _this5.cookingTimeLoading = true;
                if (!(_this5.treeLabel == '商户')) {
                  _context5.next = 8;
                  break;
                }
                _context5.next = 5;
                return _this5.API.home.getUserCookCopiesData(_this5.org_business_id, _this5.cookingTimeIndex);
              case 5:
                res = _context5.sent;
                _context5.next = 11;
                break;
              case 8:
                _context5.next = 10;
                return _this5.API.home.getStoreCookCopiesData(_this5.org_business_id, _this5.cookingTimeIndex);
              case 10:
                res = _context5.sent;
              case 11:
                arr = [];
                for (key in res.data) {
                  //用for循环转换resObj对象
                  arr.push(res.data[key]);
                }
                max = arr[0].copies;
                for (i = 1; i < arr.length; i++) {
                  if (arr[i].copies > max) {
                    max = arr[i].copies;
                  }
                }
                _this5.cookingTimeLoading = false;
                setTimeout(function () {
                  var dataDetail = {
                    categories: _this5.generateTimeAxis(),
                    series: [{
                      name: "炒制份数",
                      data: _this5.generateRandomArray(arr),
                      label: {
                        show: false,
                        position: 'top',
                        formatter: function formatter(item) {
                          // 这里的item.data代表当前数据值，item.max代表该系列的最大值
                          if (item.data === item.max) {
                            return item.value; // 只显示最大值
                          } else {
                            return ''; // 其他值不显示
                          }
                        }
                      }
                    }]
                  };

                  _this5.cookingChartData = JSON.parse(JSON.stringify(dataDetail));
                }, 0);
              case 17:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    generateTimeAxis: function generateTimeAxis() {
      var axis = [];
      for (var hour = 0; hour < 24; hour++) {
        for (var minute = 0; minute < 60; minute += 30) {
          var timeStr = ('0' + hour).slice(-2) + ':' + ('0' + minute).slice(-2);
          axis.push(timeStr);
        }
      }
      return axis;
    },
    generateRandomArray: function generateRandomArray(arr) {
      var array = arr.map(function (item) {
        return item.copies;
      });
      return array;
    },
    drawCharts: function drawCharts() {
      uChartsInstance['flavour'] = new uCharts(this.opts);
    },
    flavourTap: function flavourTap(e) {},
    // 获取食物用量数据并且渲染图
    getFoodData: function getFoodData(id) {
      var _this6 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee6() {
        var res, fillArr, result;
        return _regenerator.default.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _this6.foodChartData = JSON.parse(JSON.stringify({}));
                _this6.foodLoading = true;
                if (!(_this6.treeLabel == '商户')) {
                  _context6.next = 8;
                  break;
                }
                _context6.next = 5;
                return _this6.API.home.getUserFoodData(_this6.org_business_id, _this6.foodIndex);
              case 5:
                res = _context6.sent;
                _context6.next = 11;
                break;
              case 8:
                _context6.next = 10;
                return _this6.API.home.getStoreFoodData(_this6.org_business_id, _this6.foodIndex);
              case 10:
                res = _context6.sent;
              case 11:
                _this6.foodLoading = false;
                _this6.foodTotal = res.paging.total_records;
                fillArr = Array.from({
                  length: 10 - _this6.foodTotal
                }, function () {
                  return {
                    c: 0,
                    name: '-'
                  };
                });
                result = res.data.concat(fillArr);
                setTimeout(function () {
                  //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
                  var dataDetail = {
                    categories: result.map(function (item) {
                      if (item.name.length > 8) {
                        return item.name.slice(0, 8) + '...';
                      } else {
                        return item.name;
                      }
                    }),
                    series: [{
                      name: "食材用量",
                      data: result.map(function (item) {
                        item.c = Number(item.c).toFixed(1);
                        return item.c;
                      })
                    }]
                  };
                  _this6.foodChartData = JSON.parse(JSON.stringify(dataDetail));
                }, 0);
              case 16:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }))();
    },
    // 获取调料用量数据并且渲染图
    getFlavourData: function getFlavourData(id) {
      var _this7 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee7() {
        var res, fillArr, result;
        return _regenerator.default.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _this7.flavourChartData = JSON.parse(JSON.stringify({}));
                _this7.flavourLoading = true;
                if (!(_this7.treeLabel == '商户')) {
                  _context7.next = 8;
                  break;
                }
                _context7.next = 5;
                return _this7.API.home.getUserFlavourData(_this7.org_business_id, _this7.flavourIndex);
              case 5:
                res = _context7.sent;
                _context7.next = 11;
                break;
              case 8:
                _context7.next = 10;
                return _this7.API.home.getStoreFlavourData(_this7.org_business_id, _this7.flavourIndex);
              case 10:
                res = _context7.sent;
              case 11:
                _this7.flavourLoading = false;
                _this7.flavourTotal = res.paging.total_records;
                fillArr = Array.from({
                  length: 5 - _this7.flavourTotal
                }, function () {
                  return {
                    c: 0,
                    name: '-'
                  };
                });
                result = res.data.concat(fillArr);
                setTimeout(function () {
                  //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
                  var dataDetail = {
                    categories: result.map(function (item) {
                      if (item.name.length > 8) {
                        return item.name.slice(0, 8) + '...';
                      } else {
                        return item.name;
                      }
                    }),
                    series: [{
                      name: "调料用量",
                      data: result.map(function (item) {
                        item.c = Number(item.c).toFixed(1);
                        return item.c;
                      })
                    }]
                  };
                  _this7.flavourChartData = JSON.parse(JSON.stringify(dataDetail));
                }, 0);
              case 16:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }))();
    },
    toChangeStatus: function toChangeStatus(val) {
      var _this8 = this;
      return (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee8() {
        return _regenerator.default.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _this8.status = val;
              case 1:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8);
      }))();
    },
    toDevicePage: function toDevicePage() {
      uni.navigateTo({
        url: "/homePages/pages/deviceList/deviceList?id=".concat(this.org_business_id, "&label=").concat(this.treeLabel)
      });
    },
    toCookingDetail: function toCookingDetail(value) {
      uni.navigateTo({
        url: "/homePages/pages/cookingDataDetail/cookingDetail?org_business_id=".concat(this.org_business_id, "&label=").concat(this.treeLabel, "&title=").concat(value)
      });
    },
    toFlavourDetail: function toFlavourDetail(value) {
      this.setDeviceDetailData(this.deviceCardData);
      uni.navigateTo({
        url: "/homePages/pages/deviceOperationDetail/deviceOperationDetail?title=".concat(value, "&org_business_id=").concat(this.org_business_id, "&label=").concat(this.treeLabel)
      });
    },
    toSeeAll: function toSeeAll(value) {
      uni.navigateTo({
        url: "/homePages/pages/rankingOfType/rankingOfType?title=".concat(value, "&label=").concat(this.treeLabel, "&org_business_id=").concat(this.org_business_id)
      });
    }
  }),
  onPullDownRefresh: function onPullDownRefresh() {
    // console.log('上拉刷新了')
    this.getServerData(this.org_business_id);
    this.getUserDataDetail(this.org_business_id);
    this.getFoodData(this.org_business_id);
    this.getFlavourData(this.org_business_id);
    this.getCookCopiesData(this.org_business_id);
    this.getDeviceDetailData(this.org_business_id);
    uni.stopPullDownRefresh();
    // this.deviceList = []
    // this.page=1
    // this.toSubmit(this.customer.org_business_id, this.page)
  },
  onLoad: function onLoad() {
    // 根据vuex权限设置数据
    if (this.authority.rootMenu) this.tabItems = _tabbar.default.tabItems1;else this.tabItems = _tabbar.default.tabItems2;
    this.currentTab = this.authority.currentTab;
    this.getTreeList();
  }
}, (0, _defineProperty2.default)(_computed$components$, "onShow", function onShow() {
  this.customerInfo = this.customer;
  // this.customerInfo.logoName = this.customer.org_name.slice(0,1)
  this.getTreeList();
  console.log(this.customerInfo, 'this.customerInfoonshow');
}), (0, _defineProperty2.default)(_computed$components$, "onReady", function onReady() {
  // this.getServerData();
}), _computed$components$);
exports.default = _default;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ 2)["default"]))

/***/ }),

/***/ 230:
/*!**********************************************************************************************************!*\
  !*** D:/wp/rx/RX_fe_wxmp/pages/home/index.vue?vue&type=style&index=0&id=71e217db&lang=scss&scoped=true& ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_style_index_0_id_71e217db_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/postcss-loader/src??ref--8-oneOf-1-3!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../pf/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./index.vue?vue&type=style&index=0&id=71e217db&lang=scss&scoped=true& */ 231);
/* harmony import */ var _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_style_index_0_id_71e217db_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_style_index_0_id_71e217db_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_style_index_0_id_71e217db_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_style_index_0_id_71e217db_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_pf_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_pf_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_pf_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_pf_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_index_vue_vue_type_style_index_0_id_71e217db_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ 231:
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!D:/wp/rx/RX_fe_wxmp/pages/home/index.vue?vue&type=style&index=0&id=71e217db&lang=scss&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
    if(false) { var cssReload; }
  

/***/ })

},[[223,"common/runtime","common/vendor"]]]);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/home/index.js.map